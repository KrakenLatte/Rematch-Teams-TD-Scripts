
RematchSaved = {
	[150922] = {
		{
			"BattlePet-0-000009E1AD91", -- [1]
			0, -- [2]
			0, -- [3]
			663, -- [4]
			627, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFD7", -- [1]
			118, -- [2]
			1087, -- [3]
			0, -- [4]
			1623, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B07A", -- [1]
			1060, -- [2]
			1087, -- [3]
			0, -- [4]
			2398, -- [5]
		}, -- [3]
		["teamName"] = "Sludge Belcher",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5612\n\nStrategy added by Reilly\nAny pet with Toxic Skin and a direct damage abiliy will work in slots 2 and 3.\n\nTurn 1: Corpse Explosion\nBring in your Leviathan Hatchling\nTurn 1: Toxic Skin\nTurn 2: Water Jet\nTurn 3: Water Jet\nYour Boghopper is swapped in\nTurn 1: Toxic Skin\nTurn 2+: Steam Vent until Sludge Belcher dies\n",
	},
	[116788] = {
		{
			"BattlePet-0-000009E1AF99", -- [1]
			184, -- [2]
			440, -- [3]
			1068, -- [4]
			1701, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/4597\n\nStrategy added by DragonsAfterDark\nPriority 1: Evanescence\nPriority 2: Forboding Curse\nPriority 3: Quills all else\nBring in your next pet\nAny standard attack will finish the fight\n",
		["teamName"] = "Deviate Chomper",
		["minXP"] = 25,
	},
	[162461] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AD9E", -- [1]
			115, -- [2]
			172, -- [3]
			0, -- [4]
			489, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7632\n\nStrategy added by Lazey\n*** 9.0.2 approved ***\n\nDragonkins with <305 Power will need  2x Breath.\n\nTurn 1: Black Claw\nTurns 2-3: Flock (Ikky dies)\nBring in your Spawn of Onyxia\nTurn 4: Scorched Earth\nTurn 5+: Breath\n",
		["teamName"] = "I Am The One Who Whispers",
		["minXP"] = 1,
	},
	[173267] = {
		{
			"BattlePet-0-000009E1B197", -- [1]
			367, -- [2]
			1015, -- [3]
			1679, -- [4]
			2063, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B1A4", -- [1]
			1085, -- [2]
			456, -- [3]
			752, -- [4]
			1601, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B160", -- [1]
			0, -- [2]
			208, -- [3]
			209, -- [4]
			2717, -- [5]
		}, -- [3]
		["teamName"] = "Uncomfortably Undercover",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9404\n\nStrategy added by Lazey\nOnly using Clean-Up here because  (ID: 748) won't stop damaging my front pet on pet swaps instead of the infected pet in the backline. (not something new, but still weird)\n\n(14-15 rounds)\n\nTurn 1: Blinding Powder\nTurn 2: Chomp\nTurn 3: Smoke Bomb\nTurn 4: Chomp\nTurn 5: Blinding Powder\nTurn 6: Chomp\nTurn 7: Swap to your Servant of Demidos (Whirly dies, Stinkdust comes in)\nTurn 8: Magic Sword\nTurn 9: Clean-Up\nTurn 10: Soulrush (Stinkdust dies, Trailblazer comes in)\nTurn 11: Swap to your Microbot XD\nTurn 12: Pass\nTurn 13: Supercharge\nTurn 14: Ion Cannon\nTurn 15: Trailblazer dies while Microbot XD recovers\n",
	},
	[173331] = {
		{
			"BattlePet-0-000009E1B125", -- [1]
			0, -- [2]
			282, -- [3]
			334, -- [4]
			339, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			640, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9933\n\nStrategy added by DragonsAfterDark\nVideo for Fight (https://www.youtube.com/watch?v=mmuOm-zVtaM&t=5s)\n\nTurn 1: Decoy\nTurn 2: Explode\nBring in your Iron Starlette\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up\nTurn 4+: Toxic Smoke\n",
		["teamName"] = "The Mind Games of Addius",
		["minXP"] = 1,
	},
	[150923] = {
		{
			"BattlePet-0-000009E1B17A", -- [1]
			0, -- [2]
			1273, -- [3]
			1966, -- [4]
			2089, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1ADA2", -- [1]
			360, -- [2]
			312, -- [3]
			0, -- [4]
			378, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5591\n\nStrategy added by DragonsAfterDark\nMy Infernal Pyreclaw is an H/B breed and solo'd this. Other breeds may vary, hence the Rabbit to come in and clean up what the Pyreclaw doesn't kill. \n\nPriorty 1: Great Sting on CD\nPriority 2: Cleave all else\nBring in your Rabbit\nPriority 1: Dodge as needed, or to avoid damage on the Undead Rounds\nPriority 2: Flurry to finish off enemy pets\n",
		["teamName"] = "Belchling",
		["minXP"] = 25,
	},
	[72291] = {
		{
			"BattlePet-0-000009E1B26C", -- [1]
			608, -- [2]
			764, -- [3]
			2396, -- [4]
			3053, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "Yu'la, Broodling of Yu'lon",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/13778\n\nStrategy added by Bapomy\nRequires BlizzConline 2021 pet. Strategy identified by SheepyMax on Wowhead (https://www.wowhead.com/npc=72291/yula-broodling-of-yulon#comments:id=3307291). The Moon-Touched Netherwhelp will solo Yu'la without taking damage.\n\nTurn 1: Nether Blast (Yu'la will use Emerald Presence)\nTurn 2: Nether Blast (Yula will use Lift-Off)\nTurn 3: Phase Shift (Yu'la's Lift-Off will be dodged)\nTurn 4: Nether Blast (Yu'la's Jade Breath will be dodged)\nTurn 5: Ashes of Outland (Yu'la will miss with Jade Breath)\nTurn 6: Nether Blast (Yu'la will miss with Jade Breath)\nTurn 7: Repeat until dead.\n",
	},
	[68562] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B176", -- [1]
			115, -- [2]
			0, -- [3]
			282, -- [4]
			844, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/4787\n\nStrategy added by dintho\nTurn 1: Black Claw\nTurn 2: Flock\nTurn 3: Ikky Normally Dies here... Any standard attack if alive\nBring in your Mechanical Pandaren Dragonling\nHP > 560: HP over 560 Breath \nHP < 560: HP under 560 Explode\n",
		["teamName"] = "Ti'un the Wanderer",
		["minXP"] = 10,
	},
	[116789] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE77", -- [1]
			122, -- [2]
			489, -- [3]
			0, -- [4]
			1165, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/4600\n\nStrategy added by DragonsAfterDark\nS/S Foulfeather (2,2,1) is a good alternative to Ikky. I changed the Script so there won't be a conflict between Savage Talon and Peck :)\n\nPriority 1: Black Claw\nPriority 2: Flock\nPriority 3: Savage Talon to finish off an enemy if needed\nBring in your Nexus Whelpling\nTurn 1+: Mana Surge & Tail Sweep to finish fight\n",
		["teamName"] = "Son of Skum",
		["minXP"] = 25,
	},
	[150925] = {
		{
			"BattlePet-0-000009E1B0C9", -- [1]
			393, -- [2]
			218, -- [3]
			172, -- [4]
			2352, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1ADF5", -- [1]
			122, -- [2]
			0, -- [3]
			0, -- [4]
			538, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE91", -- [1]
			122, -- [2]
			0, -- [3]
			0, -- [4]
			1161, -- [5]
		}, -- [3]
		["teamName"] = "Liz the Tormentor",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5974\n\nStrategy added by Threewolves\nTurn 1: Curse of Doom\nTurn 2: Scorched Earth\nTurns 3+: Shadowflame til Baa'l dies.\nBring in your Scourged Whelpling\nTurn 4+: Tail Sweep til done.\n",
	},
	[142096] = {
		{
			"BattlePet-0-000009E1B1C3", -- [1]
			447, -- [2]
			2356, -- [3]
			1954, -- [4]
			2842, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEFC", -- [1]
			1233, -- [2]
			752, -- [3]
			595, -- [4]
			1567, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7734\n\nStrategy added by Shenk\nThanks @Rosqo for the idea.\n\nTurn 1: Void Nova\nTurn 2: Poison Protocol\nTurn 3: Corrosion\nTurn 4: Corrosion. Both pets die (Should your Anomalus already be dead before it can attack just bring in Sentinel's Companion and finish Lazy with [spell=Dark Talon].)\nBring in your Sentinel's Companion\nSpokes comes in\nTurn 1: Soulrush. Spokes dies\nSkeeto comes in\nTurn 1: Moonfire\n",
		["teamName"] = "Critters are Friends, Not Food",
		["minXP"] = 1,
	},
	[66730] = {
		{
			"BattlePet-0-000009E1B000", -- [1]
			525, -- [2]
			1087, -- [3]
			168, -- [4]
			1722, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7598\n\nStrategy added by Shenk\nDidn't bother to test every Dream Whelpling breed since it shouldn't matter.\n\nTurn 1: Toxic Skin\nTurn 2+: Emerald Bite until Skyshaper dies\nFangor comes in\nTurn 1: Emerald Bite\nTurn 2: Healing Flame\nTurn 3+: Emerald Bite until either one of the pets dies\n\nIf Dream Whelpling wins:\nDor the Wall comes in\nTurn 1: Pass. Dream Whelpling dies\nBring in your Level Pet\nTurn 1: Swap to your Ikky\nTurn 2: Black Claw\nTurn 3+: Flock\n\nIf Fangor wins:\nBring in your Ikky\nTurn 1+: Savage Talon until Fangor dies\nDor the Wall comes in\nTurn 1: Savage Talon\nTurn 2: Swap to your Level Pet\nTurn 3: Swap to your Ikky\nTurn 4: Black Claw\nTurn 5+: Flock\n",
		["teamName"] = "Hyuna of the Shrines",
		["minXP"] = 1,
	},
	[154910] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			422, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			0, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"random:6", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5969\n\nStrategy added by nurkka\nThird pet not brought in. I used a Magic pet to assure it would stay alive from the wave attacks.\n\nTurn 1: Shadow Shock\nTurn 2: Curse of Doom\nTurn 3: Haunt\nBring in your Ikky\nTurns 1-3: Flock\n",
		["teamName"] = "Prince Wiggletail",
		["minXP"] = 25,
	},
	[141969] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			210, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AFC9", -- [1]
			1773, -- [2]
			1758, -- [3]
			518, -- [4]
			1975, -- [5]
		}, -- [3]
		["teamName"] = "What Do You Mean, Mind Controlling Plants?",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1673\n\nStrategy added by Gershuun#1131\nTurn 1: Curse of Doom\nTurn 2: Haunt\nBring in your Ikky\nTurn 1: Black Claw\nTurn 2: Flock\nTurn 3: Flock\nTurn 4: Flock\nTurn 5: Pass\nTurn 6: Savage Talon\nTurn 7: Black Claw (Ikky dies)\nBring in your Direbeak Hatchling\nTurn 1: Falcosaur Swarm!\n",
	},
	[116790] = {
		{
			"BattlePet-0-000009E1AFC9", -- [1]
			1773, -- [2]
			1758, -- [3]
			518, -- [4]
			1975, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5693\n\nStrategy added by DragonsAfterDark\nPriority 1: Ironskin on CD\nPriority 2: Predatory Strike on Shattered Defenses\nPriority 3: Falcosaur Swarm! as filler\n",
		["teamName"] = "Vilefang",
		["minXP"] = 25,
	},
	[162465] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			1762, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B161", -- [1]
			921, -- [2]
			0, -- [3]
			919, -- [4]
			1211, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7987\n\nStrategy added by Vulpixie\nWorked well for me when I had to have the Shadowbarb Hatchling in the team.\nIkky with Black Claw and Flock is also an acceptable alternative to the Zandalari.\n\nThank you to DragonsAfterDark for fixing my script.\n\nTurn 1: Blistering Cold\nTurn 2: Chop\nTurn 3: BONESTORM\nTurn 4: Chop until Boneshard dies\nBring in your Zandalari Anklerender\nTurn 1: Black Claw\nTurn 2: Hunting Party\nTurn 8: Zandalari dies, Blistering Cold should finish off the battle with your level pet getting some XP\n",
		["teamName"] = "Dune Buggy",
		["minXP"] = 1,
	},
	[141077] = {
		{
			"BattlePet-0-000009E1AF93", -- [1]
			122, -- [2]
			204, -- [3]
			589, -- [4]
			1721, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B02B", -- [1]
			459, -- [2]
			1921, -- [3]
			282, -- [4]
			2001, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE9D", -- [1]
			0, -- [2]
			204, -- [3]
			208, -- [4]
			116, -- [5]
		}, -- [3]
		["teamName"] = "Not So Bad Down Here",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8601\n\nStrategy added by norng\n11 rounds.\n\nTurn 1: Call Lightning\nTurn 2: Arcane Storm\nTurn 3: Tail Sweep - If Stormborne Whelpling dies, bring in Dibbler and use Drill Charge\nTurn 4: Tail Sweep - Chum dies\nBruce comes in\nTurn 1+: Tail Sweep - Stormborne Whelpling dies\nBring in your Dibbler\nPriority 1: Explode when Bruce has 624 or less health\nPriority 2: Wind-Up*2 when Bruce has 1005 or more health\nPriority 3: Drill Charge\nMaws Jr. comes in, Bring in your Tranquil Mechanical Yeti\nTurn 1: Supercharge\nTurn 2: Call Lightning - Maws Jr. dies\n",
	},
	[154911] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B158", -- [1]
			1002, -- [2]
			0, -- [3]
			0, -- [4]
			1320, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5500\n\nStrategy added by DragonsAfterDark\nI specifically went out and caught a B/B Unborn Val'kyr, made it rare and lvl 25, and unless Chomp crits with Devour X the UBV has enough health to take both hits to use Haunt. \n\n643 + 643 = 1,286\nB/B UBV HP = 1562\n\nTurn 1: Curse of Doom\nTurn 2: Haunt\nBring in your Lil' Bling\nTurn 1: Pass\nTurn 2+: Inflation\n",
		["teamName"] = "Chomp",
		["minXP"] = 25,
	},
	[173303] = {
		{
			"BattlePet-0-000009E1B0AB", -- [1]
			421, -- [2]
			1043, -- [3]
			0, -- [4]
			2420, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9602\n\nStrategy added by Propagate\nTurn 1: Arcane Blast, then follow the priority below\nPriority 1: Drain Blood\nPriority 2: Arcane Blast\n",
		["teamName"] = "Ashes Will Fall",
		["minXP"] = 1,
	},
	[162466] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B158", -- [1]
			1002, -- [2]
			0, -- [3]
			985, -- [4]
			1320, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B176", -- [1]
			115, -- [2]
			779, -- [3]
			334, -- [4]
			844, -- [5]
		}, -- [3]
		["teamName"] = "Watch Where You Step",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7133\n\nStrategy added by DragonsAfterDark\nTurn 1: Curse of Doom\nTurn 2: Haunt\nBring in your Lil' Bling\nTurn 1-3: Inflation\nTurn 4: Make it Rain\nTurn 5+: Inflation\n\nIf needed: \nBring in your Mechanical Pandaren Dragonling\nTurn 1+: Breath\n",
	},
	[141588] = {
		{
			0, -- [1]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			566, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["minHP"] = 113,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1706\n\nStrategy added by Lazey\nBloodtusk:4A8K:ZL:11141BB:ZR0:P:112:1:9::::\n\nElemental level pets maybe need more HP.\nSingle target fight, so don't expect much XP for your Level Pet.\n\nTurn 1: Pass\nTurn 2: Swap to your Iron Starlette\nTurn 3: Wind-Up\n(Turn 4): (1x Powerball if you are not using P/P Iron Starlette)\nTurn 4 (5): Supercharge\nTurn 5 (6): Wind-Up\n",
		["teamName"] = "Crawg in the Bog",
		["minXP"] = 1,
	},
	[154912] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE77", -- [1]
			0, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5567\n\nStrategy added by Lazey\n*** 9.0.2 approved '''\n\nThis Manta Ray has two Beast attacks and an empowered Flyby X which will increase the damage your pet takes by 25% for 5 rounds (classic Flyby does for 3 rounds).\n\nI am using a Black Claw + Swarm ability pet in the first slot to buff attacks of my Dragonkin. The script includes Flock and Swarm because when these 8.2 pet battles go live, the Aquatic pet Chitterspine Skitterling will be available as a wild catch in Nazjatar and it has Black Claw and Swarm. Please do not use Hunting Party pets.\n\nThe Skitterling will take more damage from Flyby X so there's a chance it will die 1 round earlier than Flying pets and you can benefit of 2 rounds Shattered Defenses and Black Claw.\n\nTurn 1: Black Claw\nTurn 2+: Flock / Swarm until your pet dies. (When it does without applying Shattered Defenses, please Forfeit, Revive pets & Restart.)\n\nBring in your Nexus Whelpling\nTurn 1: Arcane Storm\nTurn 2-3: Mana Surge\nWhen your Dragon dies without killing Silence, bring in your third pet\nAny standard attack will finish the fight\n",
		["teamName"] = "Silence",
		["minXP"] = 25,
	},
	[68564] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			0, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF91", -- [1]
			499, -- [2]
			362, -- [3]
			0, -- [4]
			1146, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/952\n\nTurn 1: Wind-Up\nSwap to Stitched Pup.\nTurn 1+: Diseased Bite until your Stitched Pup enters its undead round.\nThen: Howl and Stitched Pup dies.\nSwap back to Iron Starlette.\nTurn 1: Supercharge\nTurn 2: Wind-Up and you over kill Dos-Ryga.\n",
		["teamName"] = "Dos-Ryga",
		["minXP"] = 1,
	},
	[119341] = {
		{
			"BattlePet-0-000009E1ADD1", -- [1]
			455, -- [2]
			0, -- [3]
			459, -- [4]
			471, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AD72", -- [1]
			420, -- [2]
			506, -- [3]
			508, -- [4]
			464, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1ADE4", -- [1]
			420, -- [2]
			506, -- [3]
			508, -- [4]
			753, -- [5]
		}, -- [3]
		["teamName"] = "Mining Monkey",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2736\n\nStrategy added by CrazyFluffy#21258\nThe Deadmines - Moth team\n\nYou can use last moth that was \nused against Angry Geode.\n\nNext: Moth team vs. \"Captain\" Klutz (https://www.wow-petguide.com/index.php?Strategy=2737)\n\nTurns 1+: Wind-Up until Mining Monkey dies\nAn enemy pet comes in\nTurns 1+: Batter until Robo-Chick dies\nBring in your Grey Moth and repeat strategy below until the fight is done\nTurn 1: Moth Dust\nTurn 2: Cocoon Strike\nTurn 3: Slicing Wind\nTurn 4: Slicing Wind\n",
	},
	[71927] = {
		{
			"BattlePet-0-000009E1AE9D", -- [1]
			384, -- [2]
			204, -- [3]
			209, -- [4]
			116, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE24", -- [1]
			111, -- [2]
			0, -- [3]
			124, -- [4]
			1158, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEF8", -- [1]
			276, -- [2]
			564, -- [3]
			779, -- [4]
			1201, -- [5]
		}, -- [3]
		["teamName"] = "Chen Stormstout",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8603\n\nStrategy added by norng\nFlayer Youngling (1.1.2) and Kun-Lai Runt (2.1.1) can replace 2nd pet.\n2nd pet need Power over 260.\n\nTurn 1+: Call Lightning\nTurn 2: Ion Cannon - Tonsa dies\nChirps comes in\nTurn 1+: Metal Fist - Tranquil Mechanical Yeti dies\nBring in your Stunted Yeti\nTurn 1~3: Rampage\nTurn 4+: Punch - Chirps dies\nBrewly comes in\nTurn 1+: Punch - Stunted Yeti dies\nBring in your Spawn of G'nathus\nPriority 1: If you are not affected by Inebriate, then Dive\nPriority 2: If you are not affected by Inebriate, then Thunderbolt\nPriority 3: Swallow You Whole\n",
	},
	[94638] = {
		{
			"BattlePet-0-000009E1AF05", -- [1]
			384, -- [2]
			1105, -- [3]
			209, -- [4]
			1450, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B15F", -- [1]
			406, -- [2]
			453, -- [3]
			490, -- [4]
			1155, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEA2", -- [1]
			525, -- [2]
			597, -- [3]
			598, -- [4]
			1167, -- [5]
		}, -- [3]
		["teamName"] = "Chaos Pup",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/119\n\nTurn 1: Metal Fist\nTurn 2: Reflective Shield\nTurns 3-5: Ion Cannon - This will kill both Chaos Pup and your Micro-Defender.\n\nBring in your Tanaan Backup Pets (ideally Anubisath Idol or Emerald Proto-Whelp) to finish the fight.\n",
	},
	[154913] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFC9", -- [1]
			0, -- [2]
			0, -- [3]
			518, -- [4]
			1975, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5966\n\nStrategy added by Ktjn\nTurn 1: Black Claw\nTurn 2+: Flock\nIkky dies\nTurn 4: Bring in Direbeak Hatchling\nTurn 5: Predatory Strike\n",
		["teamName"] = "Shadowspike Lurker",
		["minXP"] = 1,
	},
	[150929] = {
		{
			"BattlePet-0-000009E1B08E", -- [1]
			119, -- [2]
			163, -- [3]
			513, -- [4]
			2389, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B08F", -- [1]
			119, -- [2]
			572, -- [3]
			0, -- [4]
			2385, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5491\n\nStrategy added by DragonsAfterDark\nTurn 1: Whirlpool\nTurn 2-4: Stampede\nTurn 5+6: Scratch\nAfter that:\n~~: Scratch on Shattered Defenses\n~~: Stampede as filler\nIf needed\nBring in your Barrier Hermit\nTurn 1: Mudslide\nTurn 2+: Scratch\n",
		["teamName"] = "Nefarious Terry",
		["minXP"] = 25,
	},
	[79179] = {
		{
			"BattlePet-0-000009E1AF62", -- [1]
			455, -- [2]
			457, -- [3]
			459, -- [4]
			213, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			649, -- [2]
			1761, -- [3]
			1762, -- [4]
			1963, -- [5]
		}, -- [3]
		["teamName"] = "Deebs, Tyri and Puzzle",
		["notes"] = "Strategy added by Myzou\nTurn 1: Sweep – Puzzle is forced in\nTurn 2: Swap to your Level Pet\nTurn 3: Swap to your Boneshard\nTurn 4: 10% BONESTORM (1st slot one)\nTurn 5: 30% BONESTORM (2nd slot one)\nTurn 6: 50% BONESTORM (3rd slot one)\nTurn 7: Pass – your Boneshard dies\nBring in your Enchanted Broom\nTurn 8-9: Wind-Up x2 – Puzzle dies\nDeebs comes in\nTurn 10: Batter – Deebs dies\nTyri comes in\nTurn 11: Batter – you win\n",
	},
	[162468] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			422, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF51", -- [1]
			648, -- [2]
			0, -- [3]
			1093, -- [4]
			1351, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7144\n\nStrategy added by DragonsAfterDark\nTurn 1: Shadow Shock\nTurn 2: Pass\nTurn 3: Curse of Doom\nTurn 4: Haunt\nBring in your Macabre Marionette\nTurn 1-3: Dead Man's Party\nTurn 4+: Bone Bite\n",
		["teamName"] = "Tiny Madness",
		["minXP"] = 25,
	},
	[140315] = {
		{
			"BattlePet-0-000009E1AF7E", -- [1]
			477, -- [2]
			206, -- [3]
			481, -- [4]
			117, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3307\n\nStrategy added by DragonsAfterDark\nPriority 1: Call Blizzard on CD\nPriority 2: Deep Freeze on CD\nPriority 3: Snowball all else\nPriority 4: Standby when the \"Fixed\" Remote Control Rocket Chicken comes in\nIf needed, bring in next pet to finish the fight. \n",
		["teamName"] = "Automated Chaos",
		["minXP"] = 25,
	},
	[169417] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFAC", -- [1]
			1359, -- [2]
			1357, -- [3]
			1681, -- [4]
			1890, -- [5]
		}, -- [2]
		{
			"random:3", -- [1]
		}, -- [3]
		["notes"] = "Strategy added by DiamondWolf#11934\nTrainer Grrglin Strat EDIT:11/20/2020 The Bark Ability has a new name called Blazeing Yip. This strat still works and just replace Bark with Blazeing YipIkky Moves 1 1 1Corgi Pup Moves 1 1 1Any Level 25 PetThis is somewhat RNG if you Hit the 80% chance on the 2nd Black Claw. Also not as useful as the one @Aranesh provided.Turn 1Black ClawTurn 2FlockAfter 3 rounds of FlockTurn 5Use Black Claw(if not hit restart the fight)Turn 6Swap to CorgiTurn 7Puppy ParadeAfter 3 Rounds of Puppy Parade(if the pet did not die on round 2 of Puppy Parade restart the fight)Turn 8Super BarkTurn 9 (if your Corgi Dies just use the added 25 flying pet to kill off)Bark ( Blazeing Yip now)Battle Done \n\nTurn 1: Black Claw\nTurn 2: Flock\nAn enemy pet comes in\nTurn 5: Black Claw\nBring in your Corgi Pup\nTurn 7: Puppy Parade\nTurn 10: Superbark\nTurn 11: Bark\n",
		["teamName"] = "Trainer Grrglin",
		["minXP"] = 25,
	},
	[154914] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B125", -- [1]
			0, -- [2]
			282, -- [3]
			0, -- [4]
			339, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["minHP"] = 256,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9977\n\nStrategy added by shpungout\n255 aquatic damage for Level pet.\n\nTurn 1: Black Claw\nTurns 2-4: Flock\nTurn 5: Pass\nBring in your Darkmoon Zeppelin\nTurn 1: Explode\n",
		["teamName"] = "Pearlhusk Crawler",
		["minXP"] = 3,
	},
	[68565] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3094\n\nStrategy added by Starrbuck\nBased on the strategy created by CrazyFluffy\n\nTurn 1: Curse of Doom\nTurn 2: Haunt\nBring in your Level Pet\nTurn 1: Swap to your Ikky\nTurn 2: Black Claw\nTurn 3: Flock\nTurn 4: Nitun should be dead by now.\n",
		["teamName"] = "Nitun",
		["minXP"] = 1,
	},
	[119342] = {
		{
			"BattlePet-0-000009E1AF4F", -- [1]
			118, -- [2]
			574, -- [3]
			564, -- [4]
			1568, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6708\n\nStrategy added by Clarx\nTurn 1: Water Jet\nTurn 2: Dive\nTurn 3: Nature's Ward\nTurn 4: Water Jet\nTurn 5: Water Jet\nTurn 6: Water Jet\nTurn 7: Water Jet\nTurn 8: Dive\nAngry Geode dies here (latest) ... \nClean up the rest! (Pudle Terror is able to solo everything, depending on enemy-background pets)\n",
		["teamName"] = "Angry Geode",
		["minXP"] = 1,
	},
	[162469] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			1762, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["minHP"] = 651,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8935\n\nStrategy added by Tinlar#1408\nYour leveling pet will take some minor back-line damage and one standard attack so it needs some HP.\n\nTurn 1: Blistering Cold\nTurn 2: Chop\nEnemy forces pet change to Ikky\nTurn 1: Black Claw\nTurn 2: Flock\nBring in your Level Pet\nTurn 1: Any standard attack will finish the fight\n",
		["teamName"] = "Brain Tickling",
		["minXP"] = 11,
	},
	[160206] = {
		{
			"BattlePet-0-000009E1AE53", -- [1]
			113, -- [2]
			173, -- [3]
			519, -- [4]
			429, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B135", -- [1]
			921, -- [2]
			919, -- [3]
			917, -- [4]
			1180, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B034", -- [1]
			119, -- [2]
			152, -- [3]
			1895, -- [4]
			2057, -- [5]
		}, -- [3]
		["teamName"] = "Alran Heartshade",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7081\n\nStrategy added by Shenk\nAdapted the strategy to the Shadowlands changes.\n\nNote that I excluded the P/P breed from the raptor. In theory every breed can still work but there is a fair chance that the P/P will kill Ruddy too soon and the strategy won't work as described anymore. You can still do it, but you'd have to adapt yourself.\n\nTurn 1: Apocalypse\nTurn 2: Swap to your Tricorne\nTurn 3: Sniff Out\nRuddy comes in\nTurn 1: Poison Fang\nTurn 2: Swap to your Zandalari Kneebiter\nTurn 3: Black Claw\nTurn 4+5: Hunting Party\nTurn 6: Bloodfang. Ruddy dies\nThere is a very small chance that your Zandalari Kneebiter dies before it can use Bloodfang. In that case just finish Ruddy with Scratch of your Tricorne.\nFrill comes in\nTurn 1: Swap to your Tricorne\nTurn 2: Poison Fang\nTurn 3: Sniff Out\nWanderer comes in\nTurn 1+: Pass until Tricorne dies (2-3 times)\nBring in your Lava Beetle\nTurn 1: Cauterize\nTurn 2: Pass. Apocalypse comes down. Wanderer dies (Skip this turn if Wanderer is already dead.)\nShould your Zandalari Kneebiter still be alive bring it in and use Black Claw+Hunting Party. Otherwise procede with the following priority list:\nPrio 1: Cauterize below 1000 health\nPrio 2: Burn\n",
	},
	[154915] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			218, -- [3]
			321, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6070\n\nStrategy added by Farmacitron#2190\nTurn 1: Curse of Doom\nTurn 2: Unholy Ascension\nTurn 3: Ikky Black Claw\nTurn 4: Flock\nTurn 5: GG WP\n",
		["teamName"] = "Elderspawn of Nalaada",
		["minXP"] = 1,
	},
	[162470] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF51", -- [1]
			648, -- [2]
			0, -- [3]
			1093, -- [4]
			1351, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7134\n\nStrategy added by DragonsAfterDark\nShadowbarb Hatchling Quest\n\nReplace the third slot with the Shadowbarb Hatchling. Your Hatchling doesn't have to fight, it just has to be in the party. \n\nTurn 1: Curse of Doom\nTurn 2: Haunt\nBring in your Macabre Marionette\nTurns 1-3: Dead Man's Party\n",
		["teamName"] = "Living Statues Are Tough",
		["minXP"] = 25,
	},
	[160207] = {
		{
			"BattlePet-0-000009E1B0DB", -- [1]
			1056, -- [2]
			1123, -- [3]
			277, -- [4]
			2590, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF7E", -- [1]
			477, -- [2]
			206, -- [3]
			120, -- [4]
			117, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B15A", -- [1]
			113, -- [2]
			178, -- [3]
			179, -- [4]
			175, -- [5]
		}, -- [3]
		["teamName"] = "Therin Skysong",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8013\n\nStrategy added by ghostpets\nFight time:  2:15-2:20 on 17-18 rounds\n\nTurn 1: Disruption\nTurn 2: Life Exchange\nTurn 3: Swap to your Tiny Snowman\nTurn 4: Call Blizzard\nTurn 5: Howling Blast\nTurn 6: Snowball\nTurn 7: Snowball\nTurn 8: Call Blizzard\nTurn 9: Howling Blast to finish off Logic if your Tiny Snowman is still alive.  Otherwise, bring in your Phoenix Hatchling and use Conflagrate to finish off Logic.\nLogic dies.  Math comes in.\n\nTurn 1: Snowball until dead (if your Tiny Snowman is still alive)\nBring in your Phoenix Hatchling (if not already active)\nTurn 2: Immolate until...\nYour Ravenous Prideling is forcefully swapped in from Math's Whirling Gears.\nTurn 3: Life Exchange\nTurn 4+: Seethe until Ravenous Prideling dies\nBring in your Phoenix Hatchling to finish off Math\nTurn 1: Immolate\nTurn 2: Conflagrate (if necessary)\nTurn 3+: Burn until Math dies (if necessary)\n",
	},
	[141879] = {
		{
			"BattlePet-0-00000A0B4F37", -- [1]
			421, -- [2]
			277, -- [3]
			595, -- [4]
			87, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			566, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/4568\n\nStrategy added by Phacoid\nA new strategy which no longer deploys a leveling pet since the 8.1 XP nerf. Made this to not have a useless swap in the middle of the fight.\n\nTurn 1: Moonfire\nTurn 2+: Arcane Blast until Buzzbeak dies\nTikka comes in\nTurn 1: Life Exchange\nTurn 2+: Arcane Blast until Sprite Darter Hatchling dies\nBring in Iron Starlette\nTurn 1+: Powerball until Tikka dies\nMilo comes in\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up\nTurn 4+: Powerball until Milo dies\n",
		["teamName"] = "Keeyo's Champions of Vol'dun",
		["minXP"] = 25,
	},
	[154916] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B149", -- [1]
			504, -- [2]
			0, -- [3]
			0, -- [4]
			1416, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6022\n\nStrategy added by bios\nTurn 1: Black Claw\nTurn 2: Flock\nTurn 3: Swap to your Teroclaw Hatchling\nTurn 4: Alpha Strike\nAny standard attack will finish the fight\n",
		["teamName"] = "Ravenous Scalespawn",
		["minXP"] = 1,
	},
	[68566] = {
		{
			"BattlePet-0-000009E1B161", -- [1]
			921, -- [2]
			920, -- [3]
			919, -- [4]
			1211, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			0, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/4632\n\nStrategy added by Kurasu#2861\nI use Ikky as the base as it tends to be a common pet for people to have (as it's easily available and powerful), but almost any fast 'Flock' pet (I.E. most fliers) will do in a pinch. \n\nBy using the 'sacrificial play' in this way, your 'Flock' has the benefit of the armor break and Black Claw both, wiping the floor with him. Swapping to Ikky would require an extra turn, thus losing on the benefits of broken armor.\n\nTurn 1: Primal Cry\nTurn 2: Black Claw\nTurn 3: Hunting Party. Zandalari Anklerender will die.\nBring in your Ikky\nTurn 1: Flock. Skitterer Xi'a dies.\n",
		["teamName"] = "Skitterer Xi'a",
		["minXP"] = 1,
	},
	[173372] = {
		{
			"BattlePet-0-000009E1AE77", -- [1]
			122, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFDB", -- [1]
			459, -- [2]
			208, -- [3]
			204, -- [4]
			1957, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			0, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [3]
		["teamName"] = "Natural Defenders",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/11489\n\nStrategy added by Mutanis\nBreed recommendation Nexus Whelpling:\nP/P >> P/B > P/S\n\nUpdated the Strategy (8.3.2021). It's safer now. Chrominius can't die anymore.\n\nTurn 1: Tail Sweep\nTurn 2: Arcane Storm\nTurns 3+: Mana Surge until Nexus Whelpling dies\nBring in your Runeforged Servitor\nif Slugger isn't dead then Wind-Up (2x) until Slugger dies\nRunehoof comes in\nTurn 1: Supercharge\nTurn 2: Call Lightning (Runehoof dies)\nDuster comes in\nTurn 1+: Wind-Up until Runeforged Servitor dies\nBring in your Chrominius\nPrio 1: if Duster health > 1110 then Howl\nPrio 2: Surge of Power\n",
	},
	[141529] = {
		{
			"BattlePet-0-000009E1AF94", -- [1]
			1773, -- [2]
			165, -- [3]
			518, -- [4]
			1974, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE77", -- [1]
			122, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AF93", -- [1]
			122, -- [2]
			489, -- [3]
			589, -- [4]
			1721, -- [5]
		}, -- [3]
		["teamName"] = "Marshdwellers",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7895\n\nStrategy added by Orpartlu\nTurn 1: Falcosaur Swarm!\nTurn 2: Falcosaur Swarm! Continues.\nTurn 3: Predatory Strike\nLilly Dies.\nTurn 4: Falcosaur Swarm!\nSnowfeather Hatchling gets swapped out for Nexus Whelpling by Molaze.\nTurn 5: Arcane Storm\nTurn 6: Mana Surge\nMolaze Dies.\nTurn 7: Mana Surge continues.\nTicker may die here. If not finish with anything.\n",
	},
	[162471] = {
		{
			"BattlePet-0-000009E1B000", -- [1]
			525, -- [2]
			1087, -- [3]
			598, -- [4]
			1722, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8497\n\nStrategy added by norng\n7~10 rounds.\n\nTurn 1: Toxic Skin\nTurns 2-4: Emerald Dream\nTurn 5: Emerald Bite\nTurn 6: Emerald Bite\nTurn 7: Repeat Turn 1~6\n",
		["teamName"] = "Flight of the Vil'thik",
		["minXP"] = 25,
	},
	[160208] = {
		{
			"BattlePet-0-000009E1AFBE", -- [1]
			0, -- [2]
			268, -- [3]
			404, -- [4]
			1777, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF4F", -- [1]
			0, -- [2]
			574, -- [3]
			404, -- [4]
			1568, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1ADDD", -- [1]
			0, -- [2]
			283, -- [3]
			519, -- [4]
			744, -- [5]
		}, -- [3]
		["teamName"] = "Zuna Skullcrush",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7775\n\nStrategy added by Esotic\nLONG encounter, but completely resilient to any RNG.\n\nUse Sunlight to whittle down the enemy backline, and Apocalypse to kill Crushface. The pets in your first two slots will out-heal any damage from Crushface and can tank him infinitely.\n\nSinging Sunflower and Fozling work as good replacement pets for either of the first two slots, but the fight can take slightly longer. In fact, any pet that has at least Nature's Ward or Photosynthesis can be used for one slot; however, without the usage of Sunlight on both pets, the fight would take twice as long!\n\nModification of Snarl5150's strategy (https://www.wowhead.com/npc=160208/zuna-skullcrush#comments:id=3182505), but changed to be more flexible with what pets are used.\n\nTurn 1: Ironbark\n\nPriority 1: Sunlight (should always replace his Toxic Gas)\nPriority 2: Photosynthesis\nPriority 3: Swap to your second pet\nPriority 4: Sunlight\nPriority 5: Nature's Ward OR Photosynthesis\nSwap back to your first pet, then repeat priority until the enemy backline pets have less than ~285 health points\nBackline Low: Refresh Photosynthesis or Nature's Ward, then bring in your Apocalypse pet\nApocalypse\nSwap to your first pet, then repeat priority above until Apocalypse has 1 round left\nSwap back to your Apocalypse pet. Win\n",
	},
	[154917] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			1762, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B161", -- [1]
			921, -- [2]
			0, -- [3]
			919, -- [4]
			1211, -- [5]
		}, -- [2]
		{
			"random:10", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5572\n\nStrategy added by Lazey\n*** 9.0.2 approved ***\n\nIllusional Barrier X with only 3 rounds cooldown, Psionic Storm dealing AoE damage and changing the weather to Arcane Winds to give Psychic Blast an additional attack. Looks dangerous but my answer is... Blistering Cold :-)\n\nTo get as much Frostbite applications as possible on Mindshackle I use Blistering Cold two times before I force my Boneshard to die. To make it even worse for the opponent I also add a Bleeding effect. Black Claw and Shattered Defenses applied by Hunting Party, Flock or Swarm will then buff Frostbite/Bleeding damage.\n\nYou can replace Zandalari Raptors with Foulfeather, Ikky or Chitterspine Skitterling (8.2 Nazjatar wild catch), the script can handle them all and will also bring your third pet to pass the last turn if your birdies die.\n\nTurn 1: Blistering Cold\nTurn 2: Chop\nTurn 3: BONESTORM\nTurn 4: Blistering Cold (Boneshard dies)\nBring in your Black Claw + Swarm ability pet\nTurn 1: Black Claw\nTurn 2+: Hunting Party, Flock or Swarm\n\nWhen your Mech comes in (while using vulnerable Flying pets with Black Claw)\nPass turn\n",
		["teamName"] = "Mindshackle",
		["minXP"] = 25,
	},
	[72009] = {
		{
			"BattlePet-0-000009E1AE55", -- [1]
			901, -- [2]
			392, -- [3]
			204, -- [4]
			1178, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B158", -- [1]
			1002, -- [2]
			392, -- [3]
			985, -- [4]
			1320, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B10E", -- [1]
			777, -- [2]
			646, -- [3]
			209, -- [4]
			338, -- [5]
		}, -- [3]
		["teamName"] = "Xu-Fu, Cub of Xuen",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/228\n\nTurn 1: Call Lightning\nTurn 2: Swap to your Lil' Bling\nTurn 3: Make it Rain\nTurn 4+5: Inflation until Lil' Bling is dead\nBring in your Darkmoon Tonk\nTurn 1: Shock and Awe\nTurn 2: Ion Cannon\n",
	},
	[160209] = {
		{
			"BattlePet-0-000009E1AF51", -- [1]
			1094, -- [2]
			0, -- [3]
			1093, -- [4]
			1351, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B0BF", -- [1]
			116, -- [2]
			938, -- [3]
			640, -- [4]
			2530, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B10E", -- [1]
			0, -- [2]
			646, -- [3]
			209, -- [4]
			338, -- [5]
		}, -- [3]
		["teamName"] = "Horu Cloudwatcher",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7070\n\nStrategy added by DragonsAfterDark\nTurn 1-3: Dead Man's Party\nTurn 4+5: Macabre Maraca\nBeta comes in\nTurn 1+: Dead Man's Party until dead\nBring in your Mechantula\nTurn 1: Interrupting Jolt\nTurn 2: Toxic Smoke\nTurn 3: Zap\nAlpha comes in\nTurn 1: Toxic Smoke\nTurn 2: Zap\nTurn 3: Interrupting Jolt -- // -- Pre-Shadowlands use Interrupting Jolt on CD\nTurn 4: Toxic Smoke\nTurn 5+: Zap until Mechantula or Alpha dies\nBring in your Darkmoon Tonk\nHP < 550: Ion Cannon\nHP > 549: Shock and Awe > Ion Cannon\n",
	},
	[66734] = {
		{
			"BattlePet-0-000009E1B0FC", -- [1]
			118, -- [2]
			934, -- [3]
			230, -- [4]
			1478, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["minHP"] = 251,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7959\n\nStrategy added by Bösendorfer\nThis is a wonderful strategy I found on wowhead, published by Thulsadoom on April 6 2017 (link) (https://www.wowhead.com/npc=66734/farmer-nishi#comments). With this you can level two pets, assuming they have more than 250hp. It works every time and I think it should be shared here too. I also made a script for it (my first!), hope it works out for you!\n\nTurn 1: Cleansing Rain\nTurn 2: Bubble\nTurn 3: Spam Water Jet till Siren dies\nToothbreaker comes in\nTurn 1: Swap to Level Pet #1\nTurn 2: Swap to Level Pet #2\nTurn 3: Swap to your Syd the Squid\nTurn 4: Water Jet\nTurn 5: Water Jet\nTurn 6: Water Jet\nTurn 7: Cleansing Rain\nTurn 8: Spam Water Jet till Toothbreaker dies\nBrood of Mothallus comes in\nTurn 1: Water Jet\nTurn 2: Bubble\nSpam Water Jet till Brood of Mothallus dies\n",
		["teamName"] = "Farmer Nishi",
		["minXP"] = 2,
	},
	[154918] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			1762, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AD59", -- [1]
			0, -- [2]
			0, -- [3]
			581, -- [4]
			646, -- [5]
		}, -- [3]
		["teamName"] = "Kelpstone",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5555\n\nStrategy added by Lazey\n*** 9.0.2 approved ***\n\nHits like a truck, massive heal, and roots pets with Mudslide, so once again... DoTs!\n\nLooks like you can use every combination of Black Claw and a swarm ability that applies Shattered Defenses (Hunting Party, Flock, Swarm). It's even possible to use these swarm abilities with Exposed Wounds instead of Black Claw. (Script is prepared for a combination of these 5 abilities)\n\nTurn 1: Blistering Cold\nTurn 2: Chop\n(Turn 3): BONESTORM (Boneshard dies)\nBring in your Ikky\nTurn 1: Black Claw\nTurn 2+: Flock with your remaining pets\n",
	},
	[141945] = {
		{
			0, -- [1]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B17A", -- [1]
			0, -- [2]
			1273, -- [3]
			1966, -- [4]
			2089, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2135\n\nStrategy added by morazor#2212\nThe second leveling pet must have less HP that the Pyreclaw!\nCan be done with a SB Pyreclaw, but gets quite unreliable.\n\nTurn 1: Pass\nYour other leveling pet will be swapped in\nTurn 2: Swap to your Infernal Pyreclaw\nTurn 3: Great Sting\nTurn 4: Cleave\nTurn 5: Cleave\nTurn 6: Cleave\nTurn 7: Cleave\nTurn 8: Great Sting\nCleave until everything dies\n",
		["teamName"] = "Snakes on a Terrace",
		["minXP"] = 1,
	},
	[119344] = {
		{
			"BattlePet-0-000009E1AE77", -- [1]
			122, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEA2", -- [1]
			525, -- [2]
			597, -- [3]
			598, -- [4]
			1167, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "Klutz's Battle Bird",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1236\n\nStrategy added by Aranesh\nTurn 1: Arcane Storm\nTurns 2-4: Mana Surge - Klutz's Battle Bird dies\nAn enemy pet comes in\nTurns 1+: Continue using Arcane Storm and Mana Surge when available, otherwise Tail Sweep until your Nexus Whelpling dies\n\nIf you need your Emerald Proto-Whelp, keep Emerald Presence active, use Emerald Dream if you drop low on health and otherwise use Emerald Bite\n",
	},
	[71930] = {
		{
			"BattlePet-0-000009E1AFD3", -- [1]
			413, -- [2]
			206, -- [3]
			624, -- [4]
			120, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AD87", -- [1]
			117, -- [2]
			654, -- [3]
			0, -- [4]
			456, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AFC6", -- [1]
			389, -- [2]
			646, -- [3]
			209, -- [4]
			1227, -- [5]
		}, -- [3]
		["teamName"] = "Shademaster Kiryn",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8530\n\nStrategy added by norng\n14 rounds.\n\nTurn 1: Ice Tomb\nTurn 2: Ice Lance\nTurn 3: Ice Lance\nStormoen comes in\nTurn 1: Ice Lance\nTurn 2: Ice Lance\nTurn 3: Call Blizzard - Stormoen resurrects\nTurn 4: Ice Lance - Stormoen dies\nNairn comes in\nTurn 1+: Ice Lance - Winter's Little Helper dies\nBring in your Blighthawk\nPriority 1: Infected Claw\nPriority 2: Ghostly Bite - Nairn dies\nSummer comes in\nTurn 1: Swap to your Menagerie Custodian\nTurn 2: Overtune\nTurn 3: Shock and Awe\nTurn 4: Ion Cannon - Summer dies\n",
	},
	[160210] = {
		{
			"BattlePet-0-000009E1B0E5", -- [1]
			270, -- [2]
			1026, -- [3]
			506, -- [4]
			2586, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B077", -- [1]
			413, -- [2]
			206, -- [3]
			624, -- [4]
			2382, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B1D7", -- [1]
			219, -- [2]
			2071, -- [3]
			1052, -- [4]
			2456, -- [5]
		}, -- [3]
		["teamName"] = "Tasha Riley",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10010\n\nStrategy added by Mutanis\nTime: ~3:20 (~34 rounds)\n\nAlternative strategy if you don't have Chitterspine Skitterling or Lil' Bling or they were already used.\n\nI recommend using TD Script!\n\nTested 02.01.2022\n\nTurn 1: Amber Prison --> Fury comes in\nTurn 2: Pass\nTurn 3: Pass\nTurn 4: Cocoon Strike\nTurn 5: Swap to your Inland Croaker\nTurn 6: Ice Tomb\nTurn 7: Swap to your Amberglow Stinger\nTurn 8: Cocoon Strike --> Presto comes in\nTurn 9: Glowing Toxin\nTurn 10: Amber Prison --> Fury comes in\nTurn 11: Glowing Toxin\nTurn 12: Glowing Toxin\nTurn 13: Cocoon Strike\nTurn 14: Swap to your Inland Croaker\nTurn 15: Ice Tomb\nTurn 16: Swap to your Amberglow Stinger\nTurn 17: Cocoon Strike --> Presto comes in\nTurn 18: Glowing Toxin\nTurn 19: Amber Prison --> Fury comes in\nTurn 20: Glowing Toxin\nTurn 21: Glowing Toxin\nTurn 22: Cocoon Strike\nTurn 23: Swap to your Inland Croaker\nTurn 24: Ice Lance until Fury dies (~1x)\nPresto comes in\nTurn 1: Call Blizzard\nTurn 2+: Ice Lance until Presto is in undead Phase\n~Turn 4: Ice Tomb (undead phase)\nGlitzy pet comes in\nTurn 1: Call Blizzard\nTurn 2: Ice Lance until Inland Croaker dies\nBring in your Barnaby\nTurn 1: Roar of the Dead\nTurn 2: Tornado Punch\nTurn 3: Jab until Glitzy dies\n",
	},
	[154919] = {
		{
			"BattlePet-0-000009E1B158", -- [1]
			1002, -- [2]
			0, -- [3]
			0, -- [4]
			1320, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5508\n\nStrategy added by DragonsAfterDark\nBe cautious, lest you give your enemies the tools to destroy you. *laughs*\n\nVideo for Fight (https://www.youtube.com/watch?v=zXxxLMjdfII)\n\nTurn 1+: Inflation\n",
		["teamName"] = "Voltgorger",
		["minXP"] = 25,
	},
	[154920] = {
		{
			"BattlePet-0-000009E1AFAA", -- [1]
			0, -- [2]
			1773, -- [3]
			518, -- [4]
			1977, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF94", -- [1]
			1773, -- [2]
			0, -- [3]
			518, -- [4]
			1974, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AFC9", -- [1]
			0, -- [2]
			0, -- [3]
			518, -- [4]
			1975, -- [5]
		}, -- [3]
		["teamName"] = "Frenzied Knifefang",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5501\n\nStrategy added by DragonsAfterDark\nKnifefang's Blood in the Water has a 25% Hit Chance for over 1592 damage.\n\nRound 1: Blood in the Water Does Not hit your Bloodgazer Hatchling\nTurns 1-2: Falcosaur Swarm!\nTurn 3: Predatory Strike\nTurns 4+: Falcosaur Swarm! until dead\nBring in your Snowfeather Hatchling\nTurn 1: Predatory Strike\nTurns 2-3: Falcosaur Swarm!\n\nRound 1: Blood in the Water Does hit your Bloodgazer Hatchling\nTurn 1: Falcosaur Swarm!\nBring in your Snowfeather Hatchling\nTurn 1: Predatory Strike\nTurns 2+: Falcosaur Swarm! until dead\nBring in your Direbeak Hatchling\nTurn 1: Predatory Strike\n",
	},
	[142234] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			0, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE77", -- [1]
			122, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [3]
		["teamName"] = "Small Beginnings",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5190\n\nStrategy added by Runisco\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up until Iron Starlette dies\nBring in your Nexus Whelpling\nTurn 1: Arcane Storm\nTurn 2: Mana Surge\nTurn 3: Tail Sweep until Nexus Whelpling dies\nBring in your Ikky\nTurn 1: Black Claw\nTurn 2: Flock\n",
	},
	[173376] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			640, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			"random:10", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9347\n\nStrategy added by DragonsAfterDark\nVideo for Fight (https://www.youtube.com/watch?v=A9QmzJk7FZs)\n\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up\nTurn 4+: Toxic Smoke\nIf needed:\nBring in your Mechanical pet\nTurn 1: Any standard attack will finish the fight\n",
		["teamName"] = "Lurking In The Shadows",
		["minXP"] = 25,
	},
	[119345] = {
		{
			"BattlePet-0-000009E1AFC9", -- [1]
			1773, -- [2]
			1758, -- [3]
			518, -- [4]
			1975, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2490\n\nStrategy added by Eekwibble\nTurns 1&2: Falcosaur Swarm!\nTurn 3: Ironskin\nTurn 4: Predatory Strike\nTurns 5&6: Falcosaur Swarm! - Krutz's Battle Monkey dies\nClean up with preferred pet/s\n",
		["teamName"] = "Klutz's Battle Monkey",
		["minXP"] = 25,
	},
	[71931] = {
		{
			"BattlePet-0-000009E1AFC3", -- [1]
			422, -- [2]
			0, -- [3]
			589, -- [4]
			1931, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B1F3", -- [1]
			666, -- [2]
			2071, -- [3]
			654, -- [4]
			2199, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10379\n\nStrategy added by makeo\nThis is a reliable two pet strategy for Taran Zhu.\n\nFor Restored Revenant there are 3 possible rotations based on which enemy pet is active. This is because sometimes the order in which you fight the pets changes.\n\nPlease follow the steps exactly to prevent any chances of failure because this strategy is quite intricate.\n\nTurn 1: Arcane Storm\nTurn 2: Shadow Shock\nTurn 3: Shadow Shock\nTurn 4: Shadow Shock\nTurn 5: Arcane Storm\nTurn 6: Shadow Shock - Court Scribe dies\nBring in your Restored Revenant\nIf Bolo is active\nTurn 1: Ghostly Bite\nTurn 2-?: Rabid Strike until Bolo dies\nIf Yen is active\nTurn 1-?: Rabid Strike until Yen dies\nIf Li is active\nTurn ?: Use Rabid Strike if the cooldown of Ghostly Bite is greater than one\nTurn 1: Roar of the Dead\nTurn 2: Ghostly Bite - Li dies\n",
		["teamName"] = "Taran Zhu",
		["minXP"] = 1,
	},
	[94642] = {
		{
			"BattlePet-0-000009E1AED9", -- [1]
			962, -- [2]
			1051, -- [3]
			786, -- [4]
			1396, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEF5", -- [1]
			1369, -- [2]
			1049, -- [3]
			919, -- [4]
			1565, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B000", -- [1]
			525, -- [2]
			597, -- [3]
			168, -- [4]
			1722, -- [5]
		}, -- [3]
		["teamName"] = "Direflame",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10268\n\nStrategy added by Mutanis\nTime: ~2-3min\n\nEasy and safe strategy!\n\nTurn 1: Blistering Cold\nTurn 2: Acid Rain\nTurn 3: Swap to your Mechanical Scorpid\nTurn 4: Blinding Poison\nTurn 5: Black Claw\nTurn 6: Barbed Stinger--> Direflame dies\n(Turn 7):  (pass if you use a S/S Mechanical Scorpid + no critical hit-->  Direflame dies)\nAn enemy pet comes in\nif Mechanical Scorpid is still alive --> Blinding Poison >> Barbed Stinger until Mechanical Scorpid dies\nBring in your Crazy Carrot\nTurn 1+: Ironbark until Crazy Carrot dies\nDream Whelpling comes in\nPrio list: Emerald Presence  >> Healing Flame hp < 70% >> Emerald Bite\n",
	},
	[154921] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			0, -- [3]
			282, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B125", -- [1]
			0, -- [2]
			282, -- [3]
			0, -- [4]
			339, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			0, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [3]
		["teamName"] = "Giant Opaline Conch",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6117\n\nStrategy added by Neevi#2149\nWorked pretty well for me\n\nTurn 1: Wind Up\nTurn 2: Wind Up\nTurn 3: Explode, switch to other Explode Pet\nTurn 4: Explode\nTurn 5: Chrominius - Howl\nTurn 6: Surge of Power\n",
	},
	[141215] = {
		{
			"BattlePet-0-000009E1B176", -- [1]
			115, -- [2]
			779, -- [3]
			334, -- [4]
			844, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1AFC9", -- [1]
			1773, -- [2]
			1758, -- [3]
			518, -- [4]
			1975, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3363\n\nStrategy added by Akyro\nTurn 1: Decoy\nTurn 2: Swap to your Level Pet\nTurn 3: Swap to your Direbeak Hatchling\nTurn 4: Ironskin on Cooldown\nTurn 5: Falcosaur Swarm! until Chitara has the Broken Shell debuff\nTurn 6: Predatory Strike\n",
		["teamName"] = "Unbreakable",
		["minXP"] = 1,
	},
	[173377] = {
		{
			"BattlePet-0-000009E1AE77", -- [1]
			0, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B0CD", -- [1]
			0, -- [2]
			595, -- [3]
			536, -- [4]
			1266, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			0, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [3]
		["teamName"] = "Airborne Defense Force",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/11130\n\nStrategy added by Faymos#1176\nStrategy based on original by Shenk, but flipped 1st and last pet based on comment by Bighoff.\n\nTurn 1: Arcane Storm\nTurns 2-4: Mana Surge\nNeedlenose comes in\nTurn 5: Swap to your Xu-Fu, Cub of Xuen\nTurn 6: Prowl\nTurn 7: Moonfire\nBrite comes in\nTurn 8: Swap to your Chrominius\nTurn 9: Howl\nTurns 10-12: Surge of Power\n",
	},
	[155145] = {
		{
			"BattlePet-0-000009E1B16E", -- [1]
			118, -- [2]
			419, -- [3]
			1062, -- [4]
			1687, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5489\n\nStrategy added by DragonsAfterDark\nIf the backline pets don't die before the active pet, you will face all the enemy pets. \n\nTurn 1: Tidal Wave\nTurn 2: Tidal Wave\nTurn 3: Rain Dance\nAfter that:\nPriority 1: Rain Dance on CD\nPriority 2: Tidal Wave as filler\nPriority 3: Once the backline enemies are dead Rain Dance & Water Jet to kill enemy #1\n",
		["teamName"] = "Plagued Critters",
		["minXP"] = 25,
	},
	[83837] = {
		{
			"BattlePet-0-000009E1B077", -- [1]
			413, -- [2]
			206, -- [3]
			624, -- [4]
			2382, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B0C9", -- [1]
			0, -- [2]
			2223, -- [3]
			172, -- [4]
			2352, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/13102\n\nStrategy added by Mutanis\nTime: 01:55 (14-15 rounds)\n\nIf you don't have Baa'l then try this strategy (https://www.wow-petguide.com/?Strategy=13103)\n\nInland Croaker breed recommendation:\nHH > HP > BB > PP/PS\n\n\nTurn 1: Call Blizzard\nTurn 2: Ice Tomb\nTurns 3-4: Ice Lance (2x)\nTurn 5: Call Blizzard (Idol of Decay dies backline)\nTurn 6: Swap to your Baa'l\nTurn 7: Murder the Innocent\nTurn 8: Scorched Earth (Wishbright Lantern dies)\nTurn 9: Swap to your Inland Croaker\nTurn 10: Ice Tomb\nTurn 11: Swap to your Baa'l (Baa'l dies)\nBring in your Level Pet\nTurn 12: Swap to your Inland Croaker\nTurn 13: Call Blizzard\nTurns 14+: Ice Lance until Gyrexle, the Eternal Mechanic dies (~1-2x)\n",
		["teamName"] = "Cymre Brightblade",
		["minXP"] = 1,
	},
	[119346] = {
		{
			"BattlePet-0-000009E1B05D", -- [1]
			228, -- [2]
			934, -- [3]
			564, -- [4]
			2373, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFFC", -- [1]
			1370, -- [2]
			256, -- [3]
			517, -- [4]
			1715, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AF71", -- [1]
			1370, -- [2]
			256, -- [3]
			517, -- [4]
			1714, -- [5]
		}, -- [3]
		["teamName"] = "Unfortunate Defias",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5867\n\nStrategy added by Threewolves\nEverything you’ve ever wanted is on the other side of fear.\n\nTurn 1: Bubble (Keep on Cooldown)\nTurns 2+: Tongue Lash til Unfortunate Defias enters undead round.\nTurn 3: Dive (Keep on Cooldown)\nTurns 4+ : Tongue Lash til River Frog dies.\nBring in your Nightwatch Swooper\nTurn 1: Call Darkness\nTurn 2: Nocturnal Strike\nTurn 3: Savage Talon if needed.\n",
	},
	[71932] = {
		{
			"BattlePet-0-000009E1AD67", -- [1]
			184, -- [2]
			179, -- [3]
			501, -- [4]
			144, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEFE", -- [1]
			608, -- [2]
			1231, -- [3]
			448, -- [4]
			1524, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7230\n\nStrategy added by Berendain\nUsually takes 14-15 rounds.\n\nUpdated instructions and TD script so fight is a bit quicker.\n\nTurn 1+: Spam Quills until Carpe Diem dies\nSpirus comes in\nFollow this priority list until Spirus dies:\nPrio 1: Flame Breath if Spirus is protected by Soul Ward\nPrio 2: Conflagrate when Spirus is affected by Flame Breath\nPrio 3: Flame Breath as filler\nIf your Dragonhawk dies, bring in Netherspawn, Spawn of Netherspawn and use Nether Blast until Spirus dies\nRiver comes in\nTurn 1: Swap to your Netherspawn, Spawn of Netherspawn\nPrio 1: Consume Magic if Whirlpool is active\nPrio 2: Creeping Ooze until River dies\n",
		["teamName"] = "Wise Mari",
		["minXP"] = 1,
	},
	[94643] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B15F", -- [1]
			406, -- [2]
			453, -- [3]
			490, -- [4]
			1155, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEA2", -- [1]
			525, -- [2]
			597, -- [3]
			598, -- [4]
			1167, -- [5]
		}, -- [3]
		["teamName"] = "Mirecroak",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/311\n\nStrategy added by Remte\nNOTE: If Ikky gets frogged just start the fight over.\nTurn 1: Black Claw\nTurns 2+: Flock - Mirecroak dies.\nNext enemy pet comes in.\nTurns 1+: Flock until Ikky is dead.\n\nBring in your Backup Pets to clear the fight.\n",
	},
	[154923] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B01C", -- [1]
			113, -- [2]
			503, -- [3]
			173, -- [4]
			1149, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "Sputtertube",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6626\n\nStrategy added by Skwirrel\nTurn 1: Black Claw\nTurn 2: Flock - Ikky dies\nBring in Corefire Imp\nTurn 3: Flamethrower\nTurn 4: Burn\nTurn 5: Burn\n",
	},
	[173315] = {
		{
			"BattlePet-0-000009E1B16C", -- [1]
			118, -- [2]
			564, -- [3]
			513, -- [4]
			868, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE77", -- [1]
			122, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [2]
		{
			"random:8", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9497\n\nStrategy added by DragonsAfterDark\nThere seems to be an issue with using Duration and < or > conditionals with non-active enemy abilites. The script I posted *did* work, just not with the most recent update. I had some kind of leftover from the previous version that didn't cause this issue for me. \n\nI've posted a new script. Deleted the one in-game, copied from here, and re-tested. It worked. \n\nVideo for Fight (https://www.youtube.com/watch?v=XggSOaSORe4&t=6s)\n\nTurn 1: Whirlpool\nTurns 2-3: Dive\nTurn 4+: Water Jet until Ash dies\nFang comes in\nTurn 1: Whirlpool\nTurn 2+: Water Jet until Pandaren Water Spirit dies\nBring in your Nexus Whelpling\nTurn 1: Arcane Storm\nTurns 2-4: Mana Surge\nSwarm comes in\nTurn 1+: Mana Surge may continue\n~~: Arcane Storm & Tail Sweep until Swarm or Nexus Whelp dies\nIf needed:\nBring in your Beast pet\nTurn 1: Any standard attack will finish the fight\n",
		["teamName"] = "Resilient Survivors",
		["minXP"] = 25,
	},
	[161649] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			0, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFE6", -- [1]
			112, -- [2]
			0, -- [3]
			581, -- [4]
			52, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AFC6", -- [1]
			0, -- [2]
			646, -- [3]
			209, -- [4]
			1227, -- [5]
		}, -- [3]
		["teamName"] = "Rampage",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7073\n\nStrategy added by DragonsAfterDark\nThe opponent's pets are random in this phase. This team will work no matter which enemy pet comes in. \n\nLiz (https://www.wow-petguide.com/index.php?Strategy=7071)\n\nRalf (https://www.wow-petguide.com/index.php?Strategy=7072)\n\nPriority 1: All pets: Pass on Stun\n\nBoneshard\nPriority 1: Blistering Cold on CD\nPriority 2: Chop as filler\nBring in your Ancona Chicken\nPriority 1: Flock for Shattered Defenses\nPriority 2: Peck \nBring in your Menagerie Custodian\nTurn 1: Shock and Awe\nTurn 2: Ion Cannon\n",
	},
	[154924] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			0, -- [2]
			786, -- [3]
			0, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10192\n\nStrategy added by Akxur#2166\nTurn 1: Blistering Cold\nTurn 2: Pass\nTurn 3: Swap to your Level Pet\nTurn 4: Swap to your Boneshard\nTurn 5: Blistering Cold\nTurn 6: Pass\nBring in your Ikky\nTurn 1: Black Claw\nTurns 2-4: Flock\n",
		["teamName"] = "Goldenbot XD",
		["minXP"] = 1,
	},
	[85419] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			0, -- [3]
			282, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["teamName"] = "Gnawface",
		["notes"] = "Strategy added by Phil\nTurn 1: Wind-Up\nTurn 2: Wind-Up\nTurn 3: Explode\nLevel 1 Pets get 160xp each whil wearing Safari Hat\n",
	},
	[85463] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			566, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "Gorefu",
		["notes"] = "Strategy added by unknown\nThe three Pests can be defeated by many combinations of pets. Listed here are only a few good options, but there are many other good choices.\n\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up\n",
	},
	[161650] = {
		{
			"BattlePet-0-000009E1AEE8", -- [1]
			503, -- [2]
			636, -- [3]
			334, -- [4]
			1467, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B02B", -- [1]
			640, -- [2]
			1921, -- [3]
			0, -- [4]
			2001, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8675\n\nStrategy added by Berendain\nTwo pet strat where neither of them dies, which may appeal to those with a limited collection.  Takes 8 rounds if using breeds with high power.\n\nTurn 1: Decoy\nTurn 2: Sticky Grenade\nTurn 3: Flamethrower\nTurn 4: Swap to your Dibbler\nTurn 5+: Drill Charge, use whenever available\nTurn 6+: Toxic Smoke as filler\n",
		["teamName"] = "Liz",
		["minXP"] = 1,
	},
	[85420] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			566, -- [3]
			282, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["teamName"] = "Carrotus Maximus",
		["notes"] = "Strategy added by Phil\nTurn 1: Wind-Up\nTurn 2: Powerball\nTurn 3: Powerball\nTurn 4: Powerball\nTurn 5: Wind-Up\nTurn 6: Explode make sure Carrotus has about 427 hp or less else Powerball first\nLevel 1 pets get 160 xp each (wearing Safari Hat)\n",
	},
	[71933] = {
		{
			"BattlePet-0-000009E1AE0A", -- [1]
			118, -- [2]
			0, -- [3]
			297, -- [4]
			383, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B149", -- [1]
			429, -- [2]
			574, -- [3]
			521, -- [4]
			1416, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AD7E", -- [1]
			113, -- [2]
			178, -- [3]
			179, -- [4]
			270, -- [5]
		}, -- [3]
		["teamName"] = "Blingtron 4000",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/139\n\nTurn 1: Pump\nTurn 2: Water Jet\nTurn 3: Pump\nTurns 4+: Water Jet until Au dies (mostly not necessary)\nBanks comes in\nTurns 1+: Water Jet until Eternal Strider dies\nBring in your Teroclaw Hatchling\n\nTurn 1: Nature's Ward\nTurn 2: Hawk Eye\nTurn 3: Claw\nTurn 4: Claw\nTurn 5: Claw\n\nRepeat this rotation over and over until you won the fight.\nWith some bad luck your Hatchling dies at Lil'B. If so bring in your Dark Phoenix Hatchling and:\nTurn 1: Immolate\nTurn 2: Conflagrate\nTurns 3+: Burn until Lil'B dies\n",
	},
	[94644] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			0, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEF5", -- [1]
			1369, -- [2]
			1049, -- [3]
			919, -- [4]
			1565, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B000", -- [1]
			525, -- [2]
			597, -- [3]
			168, -- [4]
			1722, -- [5]
		}, -- [3]
		["teamName"] = "Dark Gazer",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10179\n\nStrategy added by Mutanis\nTime: ~2-3min\n\nEasy and safe strategy!\n\nTurn 1: Blistering Cold\nTurn 2: Swap to your Mechanical Scorpid\nTurn 3: Black Claw\nTurn 4: Blinding Poison\nTurn 5: Swap to your Boneshard\nTurn 6: Pass\nTurn 7: Chop --> Dark Gazer dies\nAn enemy pet comes in\nPrio list: Blistering Cold >> Chop until Boneshard dies\nBring in your Mechanical Scorpid\nPrio list: Black Claw >> Blinding Poison >> Barbed Stinger until Mechanical Scorpid dies\nDream Whelpling comes in\nPrio list: Emerald Presence  >> Healing Flame hp < 70% >> Emerald Bite\n",
	},
	[145968] = {
		{
			"BattlePet-0-000009E1B059", -- [1]
			2067, -- [2]
			163, -- [3]
			934, -- [4]
			2386, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE44", -- [1]
			429, -- [2]
			179, -- [3]
			503, -- [4]
			145, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AD92", -- [1]
			429, -- [2]
			179, -- [3]
			503, -- [4]
			143, -- [5]
		}, -- [3]
		["teamName"] = "Leper Rat",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3610\n\nStrategy added by DragonsAfterDark\nTurn 1: Bubble\nTurn 2-4: Stampede\nTurn 5+: Pinch until Undead Round\nUndead: Pass\n\nRandom Enemy Pet Comes In\n\nNote 1:: There are a few different pets that will come in with Leper Rat, so the turn orders won't be exact.\n\nNote 2:: Keep in mind, if you can't see the enemy attacks with an addon, Automated Drilling Machine's ability, Smoke Cloud, is on a 4 round CD, so you may need to adjust your pet's attacks\n\nNote 3:: Pass during any Undead/Dodge rounds\n\nTurn 1+: Stampede until you die, unless one of the random enemies is a Cockroach, then use Pinch instead\n\nFor the Dragonhawk Hatchlings:\nIf:: Mech pets are up: Flamethrower > Conflagrate > Use Conflagrate on CD and Flamethrower Between\nIf:: Critter/Undead pets are up: Flamethrower > Conflagrate > Claw +\n",
	},
	[154925] = {
		{
			0, -- [1]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			1762, -- [4]
			1963, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [3]
		["minHP"] = 1001,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10036\n\nStrategy added by Dpaul\nLevel pet variation on Kylana#1731's strategy\n\nTurn 1: Pass\nBring in your Boneshard\nTurn 3: Blistering Cold\nTurn 4: Chop\nBring in your Ikky\nTurn 6: Black Claw\nTurn 7: Flock\n",
		["teamName"] = "Creakclank",
		["minXP"] = 1,
	},
	[68563] = {
		{
			"BattlePet-0-000009E1B158", -- [1]
			1002, -- [2]
			0, -- [3]
			985, -- [4]
			1320, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13E", -- [1]
			0, -- [2]
			566, -- [3]
			282, -- [4]
			1387, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8375\n\nStrategy added by cellardwellar\nModified from Nick's Strategy which is great! But I like any xp I can get so I modified it to be a reliable leveling strategy.\nI use a H/H Iron Starlette, other breeds would probably work just as well but I didn't test them & the point at which you explode may change with different breeds.\n\nTurn 1: Make it Rain\nTurn 2: Inflation\nTurn 3+: Pass until Lil' Bling dies\nSwitch to Iron Starlette\nPriority: Iron Starlette\nPrio 1: Pass untill Make it Rain has ended (usually all you need is Explode at this point)\nPrio 2: Powerball if you need to get Kafi <= 690\nPrio 3: Explode <=690\n",
		["teamName"] = "Kafi",
		["minXP"] = 1,
	},
	[160205] = {
		{
			"BattlePet-0-000009E1AED9", -- [1]
			962, -- [2]
			0, -- [3]
			786, -- [4]
			1396, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7678\n\nStrategy added by Shrouds#2360\nAll you need to do is to keep blistering cold up and fill with bark. Long fight but it works, didn't have Hexxer or 500 charms to buy it :D\n\nTurn 1: Blistering Cold Use again with when stacks are about to fall off\nTurn 2: Ironbark Spam this untill you have to use Blistering Cold again\n",
		["teamName"] = "Pixy Whizzle",
		["minXP"] = 1,
	},
	[173381] = {
		{
			"BattlePet-0-000009E1B125", -- [1]
			0, -- [2]
			282, -- [3]
			334, -- [4]
			339, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B160", -- [1]
			0, -- [2]
			208, -- [3]
			209, -- [4]
			2717, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/11296\n\nStrategy added by norng\n5 rounds.\n\nTurn 1: Decoy\nTurn 2: Explode\nBring in your Level Pet\nTurn 1: Swap to your Microbot XD\nTurn 2: Supercharge\nTurn 3: Ion Cannon - Rascal dies\n",
		["teamName"] = "Ardenweald's Tricksters",
		["minXP"] = 1,
	},
	[68558] = {
		{
			"BattlePet-0-000009E1B0B5", -- [1]
			384, -- [2]
			0, -- [3]
			293, -- [4]
			277, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			0, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/289\n\nTurn 1: Launch Rocket\nTurn 2: Launch Rocket\nTurn 3: Launch Rocket\nTurn 4: Launch Rocket\nTurn 5: Metal Fist until Clockwork Gnome dies\nBring in Chrominius\nTurn 1: Howl\nTurn 2: Surge of Power\n",
		["teamName"] = "Gorespine",
		["minXP"] = 1,
	},
	[94641] = {
		{
			"BattlePet-0-000009E1B08A", -- [1]
			112, -- [2]
			1963, -- [3]
			506, -- [4]
			2384, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B001", -- [1]
			514, -- [2]
			270, -- [3]
			1756, -- [4]
			2134, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE31", -- [1]
			113, -- [2]
			173, -- [3]
			519, -- [4]
			415, -- [5]
		}, -- [3]
		["teamName"] = "Tainted Maulclaw",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10386\n\nStrategy added by Mutanis\nTime: ~ 2 min (exact 18 rounds)\n\nThis Strategy works for other Tanaan legendaries too (TD Script is the same!):\n1. Defiled Earth (https://www.wow-petguide.com/?Strategy=10383)\n2. Direflame (https://www.wow-petguide.com/index.php?Strategy=10278)\n5. Netherfist (https://www.wow-petguide.com/?Strategy=10406)\n8. Corrupted Thundertail (https://www.wow-petguide.com/index.php?Strategy=10385)\n10. Tainted Maulclaw (https://www.wow-petguide.com/index.php?Strategy=10386)\n\nThis one is inspired by Threewolves Apocalypse Strategy (https://www.wow-petguide.com/?Strategy=9172).\n\nTested 11/21/2020 (9.0.2)\n\nTurn 1: Wind Buffet\nAn enemy pet comes in\nTurn 2: Swap to your Fire Beetle\nTurn 3: Apocalypse\nTurn 4: Swap to your Skyfin Juvenile\n\nPrio list (Skyfin Juvenile is active)\nPrio 1: if enemy health > 50% --> Wild Winds\nPrio 2: if DOT Glowing Toxin is on enemy --> Wing Buffet (only if it hits else pass (dodge effects))\nPrio 3: If enemy health <= dmg from Wing Buffet* --> Wing Buffet  (only if it hits else pass (dodge effects))\nPrio 4: If enemy health > dmg from Wing Buffet* --> Glowing Toxin \n\nAn enemy pet comes in\nTurn 1+: Wild Winds until enemy dies or Skyfin Juvenile dies **\nBring in your Shore Butterfly\n(if backline pet is active --> Peck)\nTainted Maulclaw comes in\nTurn 1+: Prio: Cocoon Strike > pass until Shore Butterfly dies\nLava Beetle comes in\nTurn 1+: Prio: Cauterize > pass\n\n*breed and family typ depending!\n** optional (safer): If the enemy pet has ~40% health and the duration of Apocalypse > 4 then pass until it's 4 (It's already in TDScript)\n",
	},
	[87122] = {
		{
			"BattlePet-0-000009E1AF48", -- [1]
			455, -- [2]
			634, -- [3]
			282, -- [4]
			85, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B10E", -- [1]
			0, -- [2]
			646, -- [3]
			209, -- [4]
			338, -- [5]
		}, -- [3]
		["teamName"] = "Gargra",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1611\n\nStrategy added by Prudentius\nTD Script updated. 2.16.19\n\nTurn 1: Minefield\nTurns 2+: Batter until enemy Wolfus dies\nFangra comes in\nTurn 1: Explode – both Pet Bombling and Fangra die\nWolfgar comes in. Bring in your carry pet\nTurn 2: Pass\nTurn 3: Swap to your Darkmoon Tonk\nTurn 4: Shock and Awe\nTurn 5: Ion Cannon\n",
	},
	[66738] = {
		{
			"BattlePet-0-000009E1B15F", -- [1]
			406, -- [2]
			453, -- [3]
			490, -- [4]
			1155, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2\n\nStrategy added by Aranesh\nThe Void-Scarred Anubisath works instead of Anubisath Idol and is a little faster and safer. Just use Spiritfire Bolt instead of Crush.\n\nTurn 1: Sandstorm\nTurn 2: Pass\nTurn 3: Deflection\nTurn 4: Swap to level pet 1\nTurn 5: Swap to level pet 2 (only if you want to)\nTurn 6: Swap back to the Idol\nTurns 7+: Sandstorm when ready, otherwise Spiritfire Bolt / Crush. Use Deflection after Piqua lifts off.\nVoid-Scarred Anubisath / Anubisath Idol will solo the fight from here on\nFor Lapin use Deflection after he burrows.\nFor Bleat use Deflection after Chew, unless you can kill it as it emerges.\n\nLong fight but it works out :-)\n",
		["teamName"] = "Courageous Yon",
		["minXP"] = 1,
	},
	[154926] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			0, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B176", -- [1]
			0, -- [2]
			779, -- [3]
			334, -- [4]
			844, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [3]
		["teamName"] = "CK-9 Micro-Oppression Unit",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6245\n\nStrategy added by Quenyaiden\nTested multiple times, even when crit strat has 100% win rate for me.\n\nTurn 1: Blistering Cold\nTurn 2: Chop\nTurn 3: Switch to Mechanical Pandaren Dragonling and use Decoy\nTurn 4: Switch to Ikky and use Black Claw\nTurn 5: Flock\nTurn 6: If Ikky dies then bring back Mechanical Pandaren Dragonling and cast Thunderbolt (never got this far, always dead by now)\n",
	},
	[68555] = {
		{
			"BattlePet-0-000009E1B161", -- [1]
			921, -- [2]
			364, -- [3]
			919, -- [4]
			1211, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			184, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6848\n\nStrategy added by DarkShade#2783\nSugested by Adalsteinn here https://www.wow-petguide.com/index.php?Strategy=255\n\nTD Script suggested by ultharwe on same page, I just modified to include IDs\n\nWorks in Shadowlands.\n\nTurn 1: Black Claw\nTurn 2: Hunting Party\nBlack Claw on CD\nTurn 3: Flock\n",
		["teamName"] = "Ka'wi the Gorger",
		["minXP"] = 1,
	},
	[141814] = {
		{
			"BattlePet-0-000009E1B000", -- [1]
			525, -- [2]
			597, -- [3]
			168, -- [4]
			1722, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B149", -- [1]
			429, -- [2]
			312, -- [3]
			0, -- [4]
			1416, -- [5]
		}, -- [3]
		["minHP"] = 401,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9642\n\nStrategy added by shpungout\nYour level pet will take (0..4) x (63..105) flying damage.\nAlso you can try Emerald Whelpling with Tranquility instead of Healing Flame.\n\nTurn 1: Emerald Presence\nTurns 2+: Emerald Bite until Feathers dies\nSplat comes in\nTurn 1: Swap to your Level Pet\nTurn 2: Swap to your Teroclaw Hatchling\nTurn 3: Dodge\nTurns 4+: Claw until Splat dies\nBrite comes in\nTurn 1: Swap to your Dream Whelpling\nTurn 2: if health is below 300, then Healing Flame, else Emerald Bite\nTurns 3+: Emerald Bite until Brite dies\n",
		["teamName"] = "Accidental Dread",
		["minXP"] = 5,
	},
	[71924] = {
		{
			"BattlePet-0-000009E1B084", -- [1]
			119, -- [2]
			1087, -- [3]
			159, -- [4]
			2395, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AD7B", -- [1]
			535, -- [2]
			256, -- [3]
			536, -- [4]
			319, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7153\n\nStrategy added by Berendain\nFirst pet:\nAny breed of Glutted Bleeder works, but P/P is best.\n\nSecond pet:\nAny pet that can finish off Alex if needed, then reliably and quickly kill Dah'da.\n\nThe following pets can be used with the abilities listed.  They use different abilities, which sadly means I can't add them as alternatives in the pet info box at the top, but I've written the TD script in a way that works with them all.  I've tested each one myself, using different breeds of Glutted Bleeder.\n\nKills Dah'da on turn 2:\nCrypt Fiend (1/1/2)\nFeline Familiar (2/2/2)\nCursed Birman (1/1/2)\nMicrobot XD (1/2/2)\n\nKills Dah'da on turn 3:\nKor'thik Swarmling (2/1/1)\nBarnaby (1/1/2)\nPandaren Monk (1/1/1)\nRestored Revenant (1/2/2)\nChrominius (1/1/2)\nMicrobot 8D (1/2/2)\n\nShadowlands Update:  Tested existing pet combinations, tested and added new alternatives for pet #2.\n\nTurn 1: Scratch\nTurn 2: Scratch\nTurns 3-4: Burrow\nTurn 5: Scratch until Cindy enters undead round\nTurn 6: Toxic Skin during the undead round\nAlex comes in\nTurn 1: Scratch until Glutted Bleeder dies\nBring in your second pet.\nTurn 1: Pounce, or other basic attack, until Alex is dead\nDah'da comes in\nIf you are using Restored Revenant, Chrominius, or Microbot 8D, then use your first slotted ability [Bite or Alert!] if Dah'da is on 1600 HP\nTurn 1: Prowl (or Roar of the Dead, Howl, Supercharge, etc.)\nTurn 2: Call Darkness (or Ion Cannon, Tornado Punch, Surge of Power, etc.)\n",
		["teamName"] = "Wrathion",
		["minXP"] = 1,
	},
	[71929] = {
		{
			"BattlePet-0-000009E1AF13", -- [1]
			535, -- [2]
			479, -- [3]
			624, -- [4]
			1145, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFEA", -- [1]
			504, -- [2]
			404, -- [3]
			168, -- [4]
			1545, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/188\n\nTurn 1: Ice Tomb\nTurn 2: Ice Barrier\nTurn 3: Pass\nTurn 4: Pounce - Monte comes in\nTurn 5: Pounce\nTurn 6: Swap to your third pet - it will take the damage from Burrow\nTurn 7: Pass\nTurn 8: Pass\nTurn 9: Swap back to Mr. Bigglesworth\nTurn 10: Pounce\nTurn 11: Pounce - Monte dies\nSocks comes back in\nTurn 1: Ice Tomb \nTurn 2: Ice Barrier - Mr. Bigglesworth dies\nBring in your Firewing\nTurn 1: Pass - Socks gets stunned\nTurn 2: Sunlight - Sully swaps to Rikki\nTurn 3: Healing Flame\nTurns 4+: Alpha Strike until Rikki dies\nSocks comes in one last time\nTurn 1: Healing Flame\nTurn 2: Sunlight\nTurn 3: Alpha Strike and Healing Flame on cooldown until Socks is dead\n",
		["teamName"] = "Sully \"The Pickle\" McLeary",
		["minXP"] = 25,
	},
	[71934] = {
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			299, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE1B", -- [1]
			501, -- [2]
			172, -- [3]
			179, -- [4]
			519, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B160", -- [1]
			0, -- [2]
			0, -- [3]
			209, -- [4]
			2717, -- [5]
		}, -- [3]
		["teamName"] = "Dr. Ion Goldbloom",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10395\n\nStrategy added by Berendain\nBackground and explanation in the comments.\n\nIn slot 3, you can use any pet with Ion Cannon, but note that the G0-R41-0N Ultratonk is the only one that doesn't have a 1-round standard attack, so in that sense it's worse than the other options.  It will still work though, and often you won't even need to use any attacks to get Trike low before using Ion Cannon, especially with him burning each round.\n\nTurn 1: Arcane Explosion\nTurn 2: Howl\nTurn 3: Surge of Power, Screamer dies\nChaos comes in\nTurn 1+: Arcane Explosion until Chrominius dies\nBring in your Fel Flame\nTurn 1: Flame Breath\nTurn 2: Scorched Earth\nTurn 3+: Flame Breath until Chaos dies\nTrike comes in\nTurn 1: Conflagrate\nTurn 2: Apply Flame Breath\nTurn 3: Scorched Earth\nTurn 4+: Spam Flame Breath until Fel Flame dies\nBring in your Microbot XD\nTurn 1: If needed, use any standard attack until Trike is low enough to be killed with Ion Cannon\nTurn 2: Ion Cannon, Trike dies\n",
	},
	[94645] = {
		{
			"BattlePet-0-000009E1B1CE", -- [1]
			1066, -- [2]
			453, -- [3]
			490, -- [4]
			2833, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			110, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEA2", -- [1]
			525, -- [2]
			597, -- [3]
			598, -- [4]
			1167, -- [5]
		}, -- [3]
		["teamName"] = "Bleakclaw",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9273\n\nStrategy added by Mutanis\nTime: ~ 01:40 - 2:00 (depends on quality and abilities of the backline pets)\n\nUpdate 2 (01/23/2021): Sorry changed the strategy again. It's much safer now against strong backline pets ( (P/P breed, rare pets, call lightning...)\n\n\nTested 01/23/2021 (9.0.2)\n\nTurn 1: Spiritfire Bolt\nTurn 2: Swap to your Chrominius\nTurn 3: Howl\nTurn 4-6: Surge of Power --> Bleakclaw dies\nTurn 7+: Bite until Chrominius dies\nBring in your Void-Scarred Anubisath\nTurn 1+: prio list: Sandstorm > Spiritfire Bolt\nI-->: Deflection for Burrow, Dive and Lift-Off\nBring in your Emerald Proto-Whelp (if needed)\nprio list: Emerald Dream hp < ~70% >> Emerald Presence on Cd >> Emerald Bite\n\n",
	},
	[71926] = {
		{
			"BattlePet-0-00000A0B4F37", -- [1]
			421, -- [2]
			277, -- [3]
			595, -- [4]
			87, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1ADF5", -- [1]
			122, -- [2]
			214, -- [3]
			657, -- [4]
			538, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE09", -- [1]
			713, -- [2]
			490, -- [3]
			307, -- [4]
			514, -- [5]
		}, -- [3]
		["teamName"] = "Lorewalker Cho",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/183\n\nTurn 1: Moonfire\nTurns 2+: Arcane Blast until Wisdom dies\nPatience comes in\nTurn 1: Life Exchange\nTurn 2: Moonfire\nTurns 3+: Arcane Blast until Sprite Darter Hatchling dies\nBring in your Scourged Whelpling\nTurns 1+: Tail Sweep until Patience dies\nKnowledge comes in\nTurn 1: Plagued Blood\nTurn 2: Death and Decay\nTurns 3+: Tail Sweep until Scourged Whelpling dies\nBring in Flayer Youngling\nTurn 1: Kick\nTurns 2+: Blitz until you're done!\n",
	},
	[154927] = {
		{
			"BattlePet-0-000009E1AFBF", -- [1]
			908, -- [2]
			906, -- [3]
			1717, -- [4]
			1917, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9614\n\nStrategy added by shpungout\nStormstruck Beaver with P/P breed has a high chance of dying at the same time as Unit 35. In this case, all experience for the battle will go to your level pets.\nStormstruck Beaver with B/B breed has a higher chance of surviving due to more health. In this case, your level pets will not gain experience.\n\nTurn 1: Discharge\nTurn 2: Jolt\nTurn 3: Lightning Shield\nTurn 4: Jolt\n",
		["teamName"] = "Unit 35",
		["minXP"] = 1,
	},
	[72290] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2706\n\nStrategy added by lazyjohnson\nTurn 1: Curse of Doom\nTurn 2: Haunt\nBring in your Ikky\nTurn 1: Black Claw\nTurns 2-4: Flock\n",
		["teamName"] = "Zao, Calfling of Niuzao",
		["minXP"] = 25,
	},
	[150911] = {
		{
			"BattlePet-0-000009E1AD64", -- [1]
			541, -- [2]
			253, -- [3]
			163, -- [4]
			437, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF1B", -- [1]
			541, -- [2]
			253, -- [3]
			163, -- [4]
			209, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE3F", -- [1]
			360, -- [2]
			312, -- [3]
			159, -- [4]
			479, -- [5]
		}, -- [3]
		["teamName"] = "Crypt Fiend",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5487\n\nStrategy added by DragonsAfterDark\nIf you get a couple of Lost Souls on the backline, just Stampede until the Ram dies then bring in your Elfin Rabbit. Use Dodge and Burrow to avoid Nightmare and Phase Punch. \n\nTurn 1: Chew\nTurn 2-4: Stampede\nTurn 5+: Comeback until Little Black Ram dies\nBring in your Elwynn Lamb\nTurn 1: Chew\nTurn 2-4: Stampede\nTurn 5+: Comeback until Elwynn Lamb dies\nBring in your Elfin Rabbit\nPriority 1: Dodge\nPriority 2: Flurry as filler\nPriority 3: Burrow when/if you want\n",
	},
	[72285] = {
		{
			"BattlePet-0-000009E1B01C", -- [1]
			567, -- [2]
			409, -- [3]
			592, -- [4]
			1149, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1ADDF", -- [1]
			445, -- [2]
			369, -- [3]
			564, -- [4]
			743, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "Chi-Chi, Hatchling of Chi-Ji",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/214\n\nTurn 1: Immolation\nTurn 2: Wild Magic\nTurn 3: Swap to your Rapana Whelk\nTurn 4: Acidic Goo\nTurn 5: Ooze Touch\nTurn 6: Ooze Touch\nTurns 7+8: Dive\n",
	},
	[116786] = {
		{
			"BattlePet-0-000009E1AF57", -- [1]
			420, -- [2]
			506, -- [3]
			508, -- [4]
			1586, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE4A", -- [1]
			420, -- [2]
			506, -- [3]
			508, -- [4]
			756, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEFB", -- [1]
			420, -- [2]
			506, -- [3]
			508, -- [4]
			1589, -- [5]
		}, -- [3]
		["teamName"] = "Deviate Smallclaw",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2723\n\nStrategy added by CrazyFluffy#21258\nWailing Critters - Moth team\n\nAll moths use same method in all fights.\n\nNext: Moth team vs. Deviate Chomper (https://www.wow-petguide.com/index.php?Strategy=2724)\n\nTurn 1: Moth Dust\nTurn 2: Cocoon Strike\nTurn 3: Slicing Wind\nTurn 4: Slicing Wind\nRepeat until the fight is done\nIf your moth dies, swap to next moth and start at turn 1\n",
	},
	[116787] = {
		{
			"BattlePet-0-000009E1B14A", -- [1]
			421, -- [2]
			906, -- [3]
			1754, -- [4]
			2078, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6224\n\nStrategy added by Lowlander#2941\nTurn 1: Fire Shield\nTurn 2: Lightning Shield\nTurn 3: Arcane Blast (Keep spamming this till all are dead)\nTurn 4: \nTurn 5: \nTurn 6: \nTurn 7: \nTurn 8: \n",
		["teamName"] = "Deviate Flapper",
		["minXP"] = 25,
	},
	[87123] = {
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			299, -- [2]
			0, -- [3]
			0, -- [4]
			1152, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B176", -- [1]
			115, -- [2]
			779, -- [3]
			282, -- [4]
			844, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/42\n\nTurn 1+: Arcane Explosion until Chrominius dies\nBring in your Mechanical Pandaren Dragonling\nTurn 1: Breath\nTurn 2: Thunderbolt\nTurn 3+: Breath until Apexis Guardian resurrects\nThen:: Explode - your small pet gets the full experience points :-)\n",
		["teamName"] = "Vesharr",
		["minXP"] = 1,
	},
	[66739] = {
		{
			"BattlePet-0-000009E1B11C", -- [1]
			421, -- [2]
			440, -- [3]
			273, -- [4]
			1631, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			566, -- [3]
			282, -- [4]
			1387, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["minHP"] = 609,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/4873\n\nStrategy added by Mot\nWastewalker Shu:215J:21151IV:11271BB:ZL:P:406::10::::\n\nFor non-Remtach users: Min. health for leveler: Beast: 609, Elemental: 270, All other: 406\n\nTip: Use an addon that shows you when an enemy ability (for example Rupture) is off CD.\n\nExplode damage of the Iron Starlette: P/P, P/S: 560; P/B: 586; H/P: 618; H/H: 690. It should also be OK to use a different pet with Explode.\n\nScript provided by Nikeisha, see comments section. Many thanks!\n\nTurn 1: Arcane Blast\nTurn 2: Arcane Blast\nTurn 3: Arcane Blast\nTurn 4: Evanescence (Dodging the incoming Whirlpool. Since 8.1 though it seems the launch time of the Wirlpool cast can vary. Look at the Whirlpool indicator (“1 round”).)\nTurn 5: Arcane Blast\nTurn 6: Arcane Blast\nTurn 7: Wish\nTurn 8+: Arcane Blast\nPounder comes in\nTurn 1: Arcane Blast\nTurn 2: Evanescence (Goal: Block Rupture)\nTurn 3: Arcane Blast\nTurn 4: Wish\nTurn 5: Arcane Blast\nTurn 6: Arcane Blast\nTurn 7: Evanescence (Again: Blocking Rupture)\nTurn 8+: Arcane Blast\nMutilator comes in\nTurn 1+: Arcane Blast until your Wisp dies. Do not kill Mutilator if you are interested in XPs for your leveler.\nBring in your Iron Starlette\nTurn 1: Explode if it kills Mutilator (Look at your tooltip or at the Info box above.). Otherwise: Any other attacks until the threshold is reached, and then Explode.\n\n",
		["teamName"] = "Wastewalker Shu",
		["minXP"] = 12,
	},
	[154928] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			1762, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B161", -- [1]
			921, -- [2]
			364, -- [3]
			919, -- [4]
			1211, -- [5]
		}, -- [3]
		["minHP"] = 601,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8941\n\nStrategy added by Tinlar#1408\nYour level pet will take some back-line damage so needs about 600 HP.\n\nTurn 1: Blistering Cold\nTurn 2: Chop until Boneshard is dead\nBring in your Level Pet\nBring in your Zandalari Anklerender\nTurn 1: Black Claw\nTurn 2: Hunting Party\n",
		["teamName"] = "Unit 6",
		["minXP"] = 10,
	},
	[116792] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			640, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B149", -- [1]
			504, -- [2]
			574, -- [3]
			802, -- [4]
			1416, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1798\n\nStrategy added by NostrA#2338\nprops to Aranesh for his/her strategy, i just changed the TD Script and Strategy to make Teroclaw viable again\n\nTurn 1: use Wind-Up\nTurn 2: use Supercharge\nTurn 3: use Wind-Up\nTurn 4+: use Toxic Smoke until Phyxia dies\nan enemy comes in\nTurn 1+: use Toxic Smoke until your Iron Starlette dies\nbring in your Teroclaw Hatchling\nenemy HP < 618: use Ravage\nif the target enemy is a Flying enemy, you want to use Ravage when the enemy HP is under 406\nwhen not active: use Nature's Ward\nelse: use Alpha Strike\n",
		["teamName"] = "Phyxia",
		["minXP"] = 25,
	},
	[116791] = {
		{
			"BattlePet-0-000009E1B17C", -- [1]
			657, -- [2]
			940, -- [3]
			1043, -- [4]
			1574, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5692\n\nStrategy added by DragonsAfterDark\nTurn 1: Touch of the Animus\nTurn 2: Plagued Blood\nTurn 3: Drain Blood\nTurn 4+5: Plagued Blood\nTurn 6: Touch of the Animus\nTurn 7: Drain Blood\nTurn 8: Plagued Blood\nFor the Random Enemy Pets:\nPriority 1: Touch of the Animus & Drain Blood on CD\nPriority 2: Plagued Blood as filler\n\nIf needed:\nBring in any pet to clean up\n",
		["teamName"] = "Dreadcoil",
		["minXP"] = 25,
	},
	[173129] = {
		{
			"BattlePet-0-000009E1AEFC", -- [1]
			0, -- [2]
			752, -- [3]
			998, -- [4]
			1567, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE77", -- [1]
			0, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B160", -- [1]
			0, -- [2]
			208, -- [3]
			209, -- [4]
			2717, -- [5]
		}, -- [3]
		["teamName"] = "Thenia's Loyal Companions",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9390\n\nStrategy added by Lazey\nIf you're eager to save 1 round, you could start with Soulrush directly. This way you can use any Soulrush pet with >300 Power with the risk that your pet is put to sleep and you'll have to Pass & Soulrush again. But when the Sleep happens, you could also restart the fight without healing, your Soulrush pet has only one job...trigger the forced pet swap with one big hit.\n\n(Script and steps will include Ethereal of a Sentinel's Companion to avoid the Sleep, but the script should react properly if you manually used Soulrush first round)\n\n(10-11 rounds)\n\n*** Created on Beta, so maybe not final  ***\n\nTurn 1: Ethereal\nTurn 2: Soulrush\nTurn 3: If Soulrush stunned the enemy, swap your Dragonkin, otherwise Pass (forced pet swap)\nTurn 4: Arcane Storm\nTurn 5-7: Mana Surge (at least one enemy pet will die, maybe two)\n(Turn 8): (Arcane Storm / Soulrush to kill the second pet if needed)\nBring in your Mech\nTurn 1: Supercharge\nTurn 1: Ion Cannon\n",
	},
	[116793] = {
		{
			"BattlePet-0-000009E1B158", -- [1]
			1002, -- [2]
			392, -- [3]
			985, -- [4]
			1320, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEFC", -- [1]
			112, -- [2]
			752, -- [3]
			595, -- [4]
			1567, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5694\n\nStrategy added by DragonsAfterDark\nTurn 1: Extra Plating\nTurn 2: Make it Rain\nTurn 3-5: Inflation\nTurn 6: Make it Rain\nRandom Enemy comes in:\nTurn 1+: Inflation until dead\nBring in your Sentinel's Companion\nPriority 1: Moonfire & Soulrush on CD\nPriority 2: Peck as filler\n",
		["teamName"] = "Hiss",
		["minXP"] = 25,
	},
	[154922] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B176", -- [1]
			115, -- [2]
			779, -- [3]
			282, -- [4]
			844, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9777\n\nStrategy added by Mnrogar\nTurn 1: Black Claw\nTurns 2-4: Flock\nBring in your Mechanical Pandaren Dragonling\nTurn 1: Breath\nTurn 2: Thunderbolt\nTurn 3: Explode\n",
		["teamName"] = "Gnomefeaster",
		["minXP"] = 1,
	},
	[94646] = {
		{
			"BattlePet-0-000009E1B0BA", -- [1]
			504, -- [2]
			1991, -- [3]
			1963, -- [4]
			2544, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF48", -- [1]
			116, -- [2]
			634, -- [3]
			282, -- [4]
			85, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B0C9", -- [1]
			393, -- [2]
			2223, -- [3]
			172, -- [4]
			2352, -- [5]
		}, -- [3]
		["teamName"] = "Vile Blood of Draenor",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9249\n\nStrategy added by Mutanis\nTime: ~ 01:40 - 2:00 (depends on quality and abilities of the backline pets)\n\nIf you have problems with Dazzling Dance --> Try this one (https://www.wow-petguide.com/index.php?Strategy=9641)\n\nYou can use the same strategy for  Corrupted Thundertail (https://www.wow-petguide.com/index.php?Strategy=9238), Cursed Spirit (https://wow-petguide.com/index.php?Strategy=9270), Tainted Maulclaw (https://www.wow-petguide.com/index.php?Strategy=9257), Dark Gazer (https://wow-petguide.com/index.php?Strategy=9312)  and Chaos Pup (https://wow-petguide.com/index.php?Strategy=9322). TD Script is the same!\n\nTested 10/16/2020\n\nnote!: If your enemy has Violet Firefly with Dazzling Dance --> start fight again\nTurn 1: Wind Buffet\nAn enemy pet comes in\nTurn 2: Alpha Strike\nTurn 3: Ancient Knowledge\nTurn 4: If enemy pets hp > 390 (aquatic 585) then Alpha Strike else pass\nTurn 5+: Alpha Strike until the enemy pet dies\nVile Blood of Draenor comes in\nTurn 1: Wind Buffet -- if Darkshore Sentinel is slower than Vile Blood of Draenor or dead --> start fight again\nAn enemy pet comes in\nTurn 1+: Alpha Strike until the enemy pets hp < 50% \nTurn 2: Swap to your Pet Bombling\nTurn 3: Minefield\nTurn 4+: Zap until the enemy pet dies\nVile Blood of Draenor comes in\nTurn 1: Explode\nBring in your Baa'l\nTurn 1: Murder the Innocent\nTurn 2+: Shadowflame --> Vile Blood of Draenor dies\n",
	},
	[173257] = {
		{
			"BattlePet-0-000009E1AFC3", -- [1]
			422, -- [2]
			1231, -- [3]
			218, -- [4]
			1931, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B160", -- [1]
			1585, -- [2]
			208, -- [3]
			209, -- [4]
			2717, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE77", -- [1]
			122, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [3]
		["teamName"] = "Mighty Minions of Maldraxxus",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10982\n\nStrategy added by Faymos#1176\nBased on strategy added by DragonsAfterDark, substituted Court Scribe for Lesser Voidwalker\n\nTurn 1: Curse of Doom\nTurn 2: Consume Magic\nTurn 3+: Shadow Shock until Bloog dies\nBone Crusher comes in\nTurn 1+: Shadow Shock until Court Scribe dies\nBring in your Microbot XD\nTurn 1: Supercharge\nTurn 2: Ion Cannon\nChipper comes in\nTurn 1: Recover\nTurn 2: Recover\nTurn 3: Swap to your Nexus Whelpling\nTurn 4: Arcane Storm\nTurns 5-7: Mana Surge\nIf your Microbot XD is swapped in:\nTurn 1: Alert!\nTurn 2: Supercharge\nTurn 3: Ion Cannon\n",
	},
	[154929] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			0, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B161", -- [1]
			921, -- [2]
			0, -- [3]
			919, -- [4]
			1211, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8948\n\nStrategy added by Tinlar#1408\nThank you to shpungout for the suggestion on how to streamline the strategy\n\nTurn 1: Blistering Cold\nTurn 2: Chop\nTurn 3: Swap to your Level Pet\nTurn 4: Swap to your Zandalari Anklerender\nTurn 5: Black Claw\nTurns 6-7: Hunting Party\n",
		["teamName"] = "Unit 17",
		["minXP"] = 1,
	},
	[116794] = {
		{
			"BattlePet-0-000009E1B161", -- [1]
			921, -- [2]
			364, -- [3]
			919, -- [4]
			1211, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEA2", -- [1]
			525, -- [2]
			597, -- [3]
			598, -- [4]
			1167, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "Growing Ectoplasm 2",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1142\n\nStrategy added by Aranesh\nTurn 1: Black Claw\nTurns 2+3: Hunting Party\nTurn 4: Leap until Growing Ectoplasm is dead\nAn enemy pet comes in\nTurns 1+: Black Claw and Hunting Party until your Zandalari Anklerender dies\nBring in your Emerald Proto-Whelp\nTurn 1: Emerald Presence\nTurns 2+: Keep Emerald Presence active, use Emerald Dream when you drop below 1000 health and use Emerald Bite to finish the enemy pets.\n",
	},
	[116795] = {
		{
			"BattlePet-0-000009E1B01C", -- [1]
			113, -- [2]
			409, -- [3]
			592, -- [4]
			1149, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF94", -- [1]
			1773, -- [2]
			165, -- [3]
			518, -- [4]
			1974, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B10E", -- [1]
			777, -- [2]
			646, -- [3]
			209, -- [4]
			338, -- [5]
		}, -- [3]
		["teamName"] = "Everliving Spore",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8725\n\nStrategy added by norng\nAverage 13 rounds.\n\nTurn 1: Immolation\nTurn 2: Wild Magic\nTurn 3: Swap to your Snowfeather Hatchling\nTurn 4: Crouch\nTurns 5-6: Falcosaur Swarm!\nTurn 7: Predatory Strike\nTurn 8: Falcosaur Swarm! - Budding Everliving Spore dies\nAn enemy pet comes in\nPriority 1: Predatory Strike when enemy pet is affected by Shattered Defenses\nPriority 2: Falcosaur Swarm! - Snowfeather Hatchling dies\nBring in your Darkmoon Tonk\nPriority 1: Ion Cannon when 3rd enemy pet is Deviate Smallclaw\nPriority 2: Ion Cannon when 3rd enemy pet is affected by Shattered Defenses\nPriority 3: Ion Cannon when 3rd enemy pet has 732 or less health\nPriority 4: Shock and Awe\nPriority 5: Missile\n",
	},
	[173130] = {
		{
			"BattlePet-0-000009E1B15C", -- [1]
			413, -- [2]
			624, -- [3]
			206, -- [4]
			1349, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1AFD3", -- [1]
			413, -- [2]
			206, -- [3]
			624, -- [4]
			120, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9489\n\nStrategy added by Lazey\nWinter is coming...\n\nUsually Rotten Little Helper will solo all enemies and is killed by Pounder's Explode so pets in the other slots share XP (I prefer having a backup pet, but you could go for two level pets if you feel safe).\n\nKeep in mind that Pounder is using Pounder (ID: 2235). So Explode has a chance to miss, your Helper would survive and your level pet(s) won't get XP.\n\n(~12 rounds)\n\n*** Created on Beta, so maybe not final  ***\n<570 HP is more like <25.5% Health, but Blizzard rounding numbers... ;-)\n\nNote::  If Rotten Little Helper dies, bring your Level Pet. Then immediately swap your second Helper!\n\nTurn 1: Ice Tomb\nTurn 2: Call Blizzard\nTurn 3+: Ice Lance (until Pounder has <25% Health (<570 HP)\n\nYour active pet has 894 Health or less?\nYES ->: Pass (if Explode doesn't miss, both active pets die and Level Pets gain XP)\nNO ->: Ice Lance until you win the fight\n",
		["teamName"] = "Micro Defense Force",
		["minXP"] = 1,
	},
	[119409] = {
		{
			"BattlePet-0-000009E1B16C", -- [1]
			118, -- [2]
			564, -- [3]
			418, -- [4]
			868, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1229\n\nTurn 1: Geyser\nTurn 2+3: Dive\nTurn 4: Water Jet\nTurn 5+: Keep Geyser and Dive on cooldown, otherwise use Water Jet\nIf your Pandaren Water Spirit dies too early, bring in your level 25 pet and use any damaging spell. The incoming Geyser will finish the fight anyway.\n",
		["teamName"] = "Foe Reaper 50",
		["minXP"] = 25,
	},
	[119408] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			422, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "\"Captain\" Klutz",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1233\n\nTurn 1: Pass\nTurn 2: Pass\nTurn 3: Haunt\nTurn 4: Bring in Ikky\nTurn 5: Black Claw\nTurns 6+: Flock\n",
	},
	[87124] = {
		{
			"BattlePet-0-000009E1B176", -- [1]
			115, -- [2]
			647, -- [3]
			282, -- [4]
			844, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["teamName"] = "Ashlei",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/34\n\nScript thanks to Wildcard\n\nTurn 1+: Breath until Pixiebell dies\nDoodle comes in\nTurn 1: Bombing Run\nTurn 2+: Breath until Tally dies. (Doodle swaps out and Tally swaps in sometime between your Breaths)\nDoodle comes back in\nTurn 1+: Breath until Doodle is below 560 health\nThen:: Explode - your leveling pets will get the full experience.\n",
	},
	[119343] = {
		{
			"BattlePet-0-000009E1B15F", -- [1]
			406, -- [2]
			453, -- [3]
			490, -- [4]
			1155, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "Klutz's Battle Rat",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1240\n\nStrategy added by Aranesh\nTurn 1: Sandstorm\nTurns 2+: Use Deflection after the bird lifted off, otherwise Sandstorm on cooldown and Crush in between.\n",
	},
	[146005] = {
		{
			"BattlePet-0-000009E1B090", -- [1]
			1570, -- [2]
			1087, -- [3]
			513, -- [4]
			2462, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFD7", -- [1]
			118, -- [2]
			1087, -- [3]
			513, -- [4]
			1623, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/4405\n\nStrategy added by Reilly\nPriority 1: Maintain Toxic Skin\nPriority 2: Whirlpool if debuff is not active\nPriority 3: Tentacle Slap\nBring in your Leviathan Hatchling\nPriority 1: Maintain Toxic Skin\nPriority 2: Whirlpool if debuff is not active\nPriority 3: Water Jet\nAny standard attack will finish the fight\n",
		["teamName"] = "Bloated Leper Rat",
		["minXP"] = 25,
	},
	[119407] = {
		{
			"BattlePet-0-000009E1B176", -- [1]
			115, -- [2]
			779, -- [3]
			334, -- [4]
			844, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B149", -- [1]
			504, -- [2]
			312, -- [3]
			0, -- [4]
			1416, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1237\n\nStrategy added by Aranesh\nTurn 1: Decoy\nTurn 2: Thunderbolt\nTurns 3+: Now keep Thunderbolt and Decoy on cooldown and otherwise use Breath\nYour Mechanical Pandaren Dragonling will usually solo the fight.\nIf you are unlucky, bring in your Teroclaw Hatchling and use Dodge + Alpha Strike\n\nCongrats!\n",
		["teamName"] = "Cookie's Leftovers",
		["minXP"] = 1,
	},
	[141479] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			566, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B016", -- [1]
			228, -- [2]
			232, -- [3]
			934, -- [4]
			1934, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2193\n\nStrategy added by Jadeon#1206\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up\nTurn 4: Wind-Up\nPokey comes in\nTurn 5: Powerball\nTurn 6: Supercharge\nTurn 7: Wind-Up\nBurly Jr. comes in\nTurns 8+: Wind-Up until death.\nBring in your Level Pet\nSwap to your Benax\nTurn 1: Swarm of Flies\nTurn 2: Tongue Lash\nContinue Tongue Lash until Burly Jr. is dead and win. \n",
		["teamName"] = "Strange Looking Dogs",
		["minXP"] = 1,
	},
	[173131] = {
		{
			"BattlePet-0-000009E1B125", -- [1]
			0, -- [2]
			282, -- [3]
			334, -- [4]
			339, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE9D", -- [1]
			384, -- [2]
			204, -- [3]
			208, -- [4]
			116, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			0, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [3]
		["teamName"] = "Cliffs of Bastion",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9906\n\nStrategy added by Lazey\n(9-10 rounds)\n\n*** Created on Beta, so maybe not final  ***\n\nTurn 1: Decoy\nTurn 2: Explode\nBring in your Tranquil Mechanical Yeti\nTurn 1: Supercharge\nTurn 2: Call Lightning (Shelby dies, Tinyhoof comes in)\nTurn 3+: Metal Fist (until Tinyhoof is dead)\nSwap to your Chrominius\nTurn 1: Howl\nTurn 2: Surge of Power\n",
	},
	[146001] = {
		{
			"BattlePet-0-000009E1B15C", -- [1]
			413, -- [2]
			624, -- [3]
			206, -- [4]
			1349, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B156", -- [1]
			413, -- [2]
			206, -- [3]
			624, -- [4]
			119, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3600\n\nStrategy added by DragonsAfterDark\nWhatever pet you have in the third slot should only need to be there to soak backline damage, so make sure it's one you won't be using later on. \n\n\nTurn 1: Ice Tomb\nTurn 2: Pass\nTurn 3: Call Blizzard\nTurn 4: Ice Lance\nTurn 5: Ice Lance\nTurn 6: Pass\nTurn 7: Ice Tomb\nTurn 8: Pass – your Rotten Little Helper dies\nBring in your Father Winter's Helper\nTurn 1: Call Blizzard\nTurn 2: Ice Lance\nTurn 3: Ice Tomb\nTurn 4: Pass\nTurn 5: Call Blizzard\nTurn 6+: Ice Lance until Annoy-O-Tron dies\n",
		["teamName"] = "Prototype Annoy-O-Tron",
		["minXP"] = 25,
	},
	[146182] = {
		{
			"BattlePet-0-000009E1B075", -- [1]
			2067, -- [2]
			934, -- [3]
			564, -- [4]
			2399, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B167", -- [1]
			394, -- [2]
			745, -- [3]
			1343, -- [4]
			1429, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B173", -- [1]
			113, -- [2]
			382, -- [3]
			173, -- [4]
			1517, -- [5]
		}, -- [3]
		["teamName"] = "Living Sludge",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3605\n\nStrategy added by DragonsAfterDark\nTurn 1+2: Dive\nTurn 3: Bubble\nTurn 4+: Pinch until Living Sludge is dead\n\nRandom Enemy Pet Comes In\n\nNote 1:: There are a few different pets that will come in with Living Sludge, so the turn orders won't be exact.\n\nNote 2:: Keep in mind, if you can't see the enemy attacks with an addon, Automated Drilling Machine's ability, Smoke Cloud, is on a 4 round CD, so you may need to adjust your pet's attacks\n\nNote 3:: Pass during the Undead / Dodge Rounds\n\nTurn 1: Pinch (skip this turn if Sewege Eruption has 1 round left)\nTurn 2+3: Dive\nTurn 4+: Pinch until dead\nBring in your Autumnal Sproutling\nPriority 1: Use Leech Seed on CD\nPriority 2: Use Fist of the Forest on CD\nPriority 3: Lash as filler\nBring in your Blazing Cindercrawler\nPriority 1: Cauterize as needed\nIf: Mech/Undead pet is up: Burn+\nIf : Critter is up: Brittle Webbing +\n",
	},
	[94647] = {
		{
			"BattlePet-0-000009E1B0BA", -- [1]
			504, -- [2]
			1991, -- [3]
			1963, -- [4]
			2544, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B02B", -- [1]
			640, -- [2]
			1921, -- [3]
			282, -- [4]
			2001, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE1B", -- [1]
			113, -- [2]
			178, -- [3]
			179, -- [4]
			519, -- [5]
		}, -- [3]
		["teamName"] = "Dreadwalker",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9301\n\nStrategy added by Mutanis\nTime: ~ 01:40 - 2:00 (depends on quality and abilities of the backline pets)\n\nThis strat is safe against enemy Team speed buffs (Violet Firefly with Dazzling Dance)\n\nTested 10/14/2020\n\nTurn 1: Wind Buffet\nAn enemy pet comes in\nTurn 2: Alpha Strike\nTurn 3: Ancient Knowledge\nTurn 4: If enemy pets hp > 390 (aquatic 585) then Alpha Strike else pass\nTurn 5+: Alpha Strike until the enemy pet dies\nDreadwalker comes in\nTurn 1: Wind Buffet\nAn enemy pet comes in\nTurn 1+: Alpha Strike until the enemy pets hp < 50% \nTurn 2: Swap to your Dibbler\nTurn 3: Drill Charge\nTurn 4+: Toxic Smoke until enemy pet dies\nDreadwalker comes in\nTurn 1: Explode\nBring in your Fel Flame\nTurn 1: Immolate\nTurn 2: Conflagrate\nTurn 3+: Burn\n",
	},
	[146183] = {
		{
			"BattlePet-0-000009E1B150", -- [1]
			445, -- [2]
			369, -- [3]
			564, -- [4]
			289, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AD7E", -- [1]
			113, -- [2]
			178, -- [3]
			179, -- [4]
			270, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B162", -- [1]
			380, -- [2]
			447, -- [3]
			448, -- [4]
			1802, -- [5]
		}, -- [3]
		["teamName"] = "Living Napalm",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3601\n\nStrategy added by DragonsAfterDark\nTurn 1: Acidic Goo\nTurn 2+3: Dive\nTurn 4+: Ooze Touch until Napalm dies\n\nRandom Enemy Pet Comes In\n\nNote 1:: There are a few different pets that will come in with Living Napalm, so the turn orders won't be exact.\n\nNote 2:: Keep in mind, if you can't see the enemy attacks with an addon, Automated Drilling Machine's ability, Smoke Cloud, is on a 4 round CD, so you may need to adjust the Dark Phoenix's attacks\n\nNote 3:: Pass during any Undead / Dodge Rounds\n\nTurn 1+: Use Acidic Goo until applied on enemy\nTurn 2+: Ooze Touch until Scooter the Snail dies\n\nBring in your Dark Phoenix Hatchling\nTurn 1: Immolate\nTurn 2: Conflagrate\nTurn 3+: Burn until enemy #2 dies\nEnemy #3 Comes In\nTurn 1+: Immolate until applied\nTurn 2+: Burn until Conflagrate comes off CD\nTurn 3: Conflagrate\n\nIf needed, bring in your Fetid Waveling:\nIf: Critter/Undead are up: Creeping Ooze > Corrosion > Poison Spit +\nIf: Mech pet is up: Creeping Ooze > Poison Spit +\n",
	},
	[146181] = {
		{
			"BattlePet-0-000009E1B084", -- [1]
			119, -- [2]
			1087, -- [3]
			159, -- [4]
			2395, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B134", -- [1]
			429, -- [2]
			179, -- [3]
			503, -- [4]
			142, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3607\n\nStrategy added by DragonsAfterDark\nPriority 1: Keep Toxic Skin active\nPriority 2: Scratch all else\nIf the Cockroach is up while your Glutted Bleeder is still alive, use Burrow\n\nBring in your Golden Dragonhawk Hatchling\n\nPass during any Undead rounds\n\nIf a Roach is up: Claw until they die\n\nIf a Mech/Undead is up: Flamethrower > Conflagrate > Flamethrower until they die\n",
		["teamName"] = "Living Permafrost",
		["minXP"] = 25,
	},
	[145988] = {
		{
			"BattlePet-0-000009E1AF24", -- [1]
			0, -- [2]
			0, -- [3]
			362, -- [4]
			1660, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1ADEF", -- [1]
			0, -- [2]
			906, -- [3]
			0, -- [4]
			1175, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEE5", -- [1]
			0, -- [2]
			0, -- [3]
			0, -- [4]
			1426, -- [5]
		}, -- [3]
		["teamName"] = "Pulverizer Bot Mk 6001",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/12158\n\nStrategy added by norng\n4 rounds.\n\nTurn 1: Howl - Thundertail Flapper comes in\nTurn 2: Lightning Shield\nTurn 3: Pass - Pulverizer Bot Mk 6001 resurrects\nTurn 4: Pass - Pulverizer Bot Mk 6001 dies\n",
	},
	[145971] = {
		{
			"BattlePet-0-000009E1ADCE", -- [1]
			406, -- [2]
			364, -- [3]
			124, -- [4]
			509, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF13", -- [1]
			429, -- [2]
			414, -- [3]
			624, -- [4]
			1145, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B064", -- [1]
			626, -- [2]
			159, -- [3]
			1598, -- [4]
			2383, -- [5]
		}, -- [3]
		["teamName"] = "Cockroach",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3609\n\nStrategy added by DragonsAfterDark\nTurn 1-3: Rampage\nTurn 4+: Leap until Cockroach dies\n\nRandom Enemy Pet Comes In\n\nNote 1: : There are a few different pets that will come in with Cockroach, so the turn orders won't be exact.\n\nNote 2: : Keep in mind, if you can't see the enemy attacks with an addon, Automated Drilling Machine's ability, Smoke Cloud, is on a 4 round CD, so you may need to adjust your pet's attacks\n\nNote 3: : Pass during any Undead/Dodge Rounds\n\nTurn 1: Crush\nTurn 2+: Rampage until dead\n\nBring in your Mr. Bigglesworth\nIf:: Mech pet is up: Ice Tomb > Frost Nova > Claw +\nIf the second pet is a Mech, chances are you only need to Frost Nova > Claw to finish it off\nIf:: Undead pet is up: Ice Tomb > Claw +\nIf:: Critter is up: Claw +\n\nBring in your Giant Woodworm\nTurn 1: Unstable Shield\nTurn 2: Skitter\nTurn 3: Skitter\nTurn 4+5: Burrow\nRepeat 1-5 as needed (if a critter is up, you can skip the Unstable Shield and sub for another Skitter)\n",
	},
	[141002] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			566, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B176", -- [1]
			115, -- [2]
			779, -- [3]
			282, -- [4]
			844, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1745\n\nStrategy added by Lazey\n*** 9.0.2 approved ***\n\nIt's very rare, but if an early Sweep forces a pet swap on your side, I recommend a Restart.\n\nLevel Pet will get all XP cause both carry pets die.\n\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up\nTurn 4: Wind-Up, Dead Deckhand Leonard dies.\nCorrupted Slime comes in\nTurn 1: Powerball\nTurn 2: Supercharge\nTurn 3+: Prio 1: Unleash Wind-Up attack if Failsafe was triggered. Don't apply new Wind-Up\nPrio 2: Powerball\nIron Starlette dies, bring in your Mechanical Pandaren Dragonling\nTurn 1+: Use Thunderbolt if you're sure the split damage will kill Corrupted Slime, otherwise Breath.\nReanimated Kraken Tentacle comes in\nTurn 1: Prio 1: Explode if Kraken Tentacle has 560HP or less.\nPrio 2: Thunderbolt\nPrio 3: Breath\n",
		["teamName"] = "Sea Creatures Are Weird ",
		["minXP"] = 1,
	},
	[142054] = {
		{
			"BattlePet-0-000009E1B10F", -- [1]
			111, -- [2]
			216, -- [3]
			513, -- [4]
			2457, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AD7D", -- [1]
			535, -- [2]
			0, -- [3]
			208, -- [4]
			1162, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9320\n\nStrategy added by Mutanis\nTime: 1:20 (~12 rounds)\n\nIt's a fast strat!\n\nTested 11/22/2020 (9.0.2)\n\nTurn 1: Whirlpool\nTurn 2: Punch\nTurn 3: Inner Vision\nTurn 4: Punch --> Beets dies\nRawly comes in\nTurn 5: Whirlpool\nTurn 6: Inner Vision\nTurn 7+: Punch until Rawly  dies (1-2 times)\nStinger comes in\nTurn 9: Whirlpool\nTurn 10: Inner Vision\nif Coldlight Surfrunner dies then bring in Fluxfire Feline else Punch\nTurn 1: Supercharge\nTurn 2: Pounce\n",
		["teamName"] = "Desert Survivors",
		["minXP"] = 1,
	},
	[146004] = {
		{
			"BattlePet-0-000009E1AFBE", -- [1]
			962, -- [2]
			268, -- [3]
			404, -- [4]
			1777, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3953\n\nStrategy added by schlumpf#2707\nPriority 1: Maintain Photosynthesis\nPriority 2: Maintain Sunlight\nPriority 3: Ironbark\n",
		["teamName"] = "Gnomeregan Guard Mechanostrider",
		["minXP"] = 1,
	},
	[87125] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			640, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF93", -- [1]
			782, -- [2]
			489, -- [3]
			589, -- [4]
			1721, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10931\n\nStrategy added by kachooman\n11 turns total with P/P Iron starlette. Should work with any Iron Starlette but if they have any H in breed might last another round or so.\n\nTurn 1: Pass\nTurn 2: Wind-Up\nTurn 3: Supercharge\nTurn 4: Wind-Up\nGrace comes in\nTurn 5: Toxic Smoke\nTurn 6: Toxic Smoke\nBring in your Level Pet\nTurn 7: Swap to your Stormborne Whelpling\nTurn 8: Arcane Storm\nTurns 9: Mana Surge\nAtonement comes in\nTurns 10: Mana Surge\nTurn 11: Mana Surge\n",
		["teamName"] = "Taralune",
		["minXP"] = 1,
	},
	[66741] = {
		{
			"BattlePet-0-000009E1B161", -- [1]
			110, -- [2]
			364, -- [3]
			919, -- [4]
			1211, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B0B5", -- [1]
			384, -- [2]
			278, -- [3]
			710, -- [4]
			277, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["teamName"] = "Aki the Chosen",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/591\n\nBreeds that we know work:\nAnklerender must be a P/P breed for this to work 100%.\nP/S and P/B also work just follow the notes below.\n\n(The notes down there are an estimate of 550 HP). (Saint)\n\nTurn 1: Bite\nTurn 2: Bite\nTurn 3+: Leap until Chirrup is dead.\nStormlash comes in.\nTurn 1: Black Claw - your Anklerender dies.\nBring in your Clockwork Gnome.\nTurn 1: Build Turret - Stormlash dies.  If not, just go on to the next step for your turret will kill him as you repair.\nWhiskers comes in.\nTurns 1-3: Repair\nTurn 4: Build Turret\nNOTE: If Whiskers is 551 HP or below after turn 4, Skip to turn 6. So he'll use Survival instead of Surge on your level pet. This is an estimate.\nNOTE: If Whiskers is above 551 HP after turn 4, continue to Turn 5. So he'll use Survival instead of Surge on your level pet. This is an estimate.\nTurn 5: Metal Fist\nTurn 6: Swap to your Level Pet.\nTurn 7: Swap back to your Clockwork Gnome.\nTurn 8: Build Turret - Whiskers dies.\nTurn 9: Metal Fist - if you think you need to.\n",
	},
	[146003] = {
		{
			"BattlePet-0-000009E1AF7E", -- [1]
			477, -- [2]
			206, -- [3]
			120, -- [4]
			117, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6332\n\nStrategy added by ddj88#1113\nThis strategy works if all enemy pets are mechanical, adjust other pets according to the enemy back line pets (beast if critter, elemental if mechanical). I've used tiny snowman twice now and he can take out all the pets.\n\nTurn 1: Call Blizzard\nTurn 2: Howling Blast\nTurn 3: Snowball\nTurn 4: Priority Call Blizzard>Howling Blast>Snowball. If enemy pet is near death cast snowball save the cd's of other two big spells for higher HP pet\nTurn 5: \nTurn 6: \nTurn 7: \nTurn 8: \n",
		["teamName"] = "Gnomeregan Guard Tiger",
		["minXP"] = 22,
	},
	[173324] = {
		{
			"BattlePet-0-000009E1AE55", -- [1]
			901, -- [2]
			916, -- [3]
			204, -- [4]
			1178, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			184, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B160", -- [1]
			0, -- [2]
			208, -- [3]
			209, -- [4]
			2717, -- [5]
		}, -- [3]
		["teamName"] = "Eyegor's Special Friends",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/11215\n\nStrategy added by Freakzoid#11736\nTurn 1: Call Lightning\nTurn 2: Haywire, Boneclaw dies\nTurn 3: Fel Immolate, bring in ikky when Sunreaver dies\nTurn 4: Black Claw\nTurn 5: Quills, Spindler Dies\nTurn 6: Black Claw\nTurn 7: Flock, bring in Microbot XD when Ikky dies\nTurno 8: Supercharge\nTurno 9: Ion Cannon you win \n\n",
	},
	[140461] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			184, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B158", -- [1]
			983, -- [2]
			392, -- [3]
			985, -- [4]
			1320, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1717\n\nStrategy added by Lazey\n*** 9.0.2 approved ***\n\nTurn 1: Black Claw\nTurn 2+: Flock until Atherton is dead.\nBybee comes in\nTurn 1: Black Claw\nTurn 2+: Flock until Bybee is dead.\nJennings comes in\nTurn 1: Black Claw until Ikky has 366HP or less. (Ikky must be killed by Jennings!)\nTurn 2: Flock until Ikky is dead.\nBring in your Level Pet\nSwap to your Lil' Bling\nTurn 1: Make it Rain\nAny standard attack will finish the fight\n",
		["teamName"] = "Night Horrors",
		["minXP"] = 1,
	},
	[173133] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			184, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF10", -- [1]
			0, -- [2]
			0, -- [3]
			518, -- [4]
			1597, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10092\n\nStrategy added by Lazey\n2020-Oct-15 Jawbone finally available for testing, but right now a joke. I guess they did forget to add the passive they created for this fight  https://shadowlands.wowhead.com/pet-ability=2383 We'll see if it'll be added later and what it does for the diffculty.\n\n*** Created on Beta so maybe not final ***\n\nTurn 1: Black Claw\nTurns 2-4: Flock\n(If needed, bring your backup pet and use Predatory Strike)\n",
		["teamName"] = "Mega Bite",
		["minXP"] = 1,
	},
	[146002] = {
		{
			"BattlePet-0-000009E1B169", -- [1]
			113, -- [2]
			409, -- [3]
			945, -- [4]
			1700, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B17D", -- [1]
			429, -- [2]
			0, -- [3]
			624, -- [4]
			57, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B14C", -- [1]
			1359, -- [2]
			1965, -- [3]
			0, -- [4]
			2086, -- [5]
		}, -- [3]
		["teamName"] = "Gnomeregan Guard Wolf",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3614\n\nStrategy added by DragonsAfterDark\nTurn 1: Heat Up\nTurn 2: Immolation\nTurn 3+: Burn until the Guard Wolf dies\nRandom Enemy Pet Comes In\n\nNote:: Pass whenever there's an Undead round or Dodge\n\nTurn 1: Burn\nTurn 2: Heat Up\nTurn 3+: Burn until the Torch dies\nBring in your Azure Whelpling\nTurn 1+: Claw to finish off enemy #2\nEnemy Pet #3 Comes In\nTurn 1: Ice Tomb (Skip this if the Random Enemy is a Critter)\nTurn 2+: Claw until the Azure Whelpling or the enemy dies\nBring in your Blazehound\nTurn 1: Frenzy\nTurn 2+: Bark to finish them off\n",
	},
	[146932] = {
		{
			"BattlePet-0-000009E1ADDF", -- [1]
			445, -- [2]
			369, -- [3]
			564, -- [4]
			743, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE5A", -- [1]
			445, -- [2]
			369, -- [3]
			564, -- [4]
			493, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AF82", -- [1]
			445, -- [2]
			369, -- [3]
			564, -- [4]
			1776, -- [5]
		}, -- [3]
		["teamName"] = "Door Control Console",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3608\n\nStrategy added by DragonsAfterDark\nI'm putting the warning here, since quite a few people have experienced this:\n\nDO NOT GO AFK after this battle. If you do, the door will close, and re-doing the fight will not open it again. You'll have to drop out of the dungeon and start over. If you need to go AFK, go inside the door at least, or head to the next pet and AFK there.  \n\nTurn 1: Acidic Goo\nTurn 2+3: Dive\nTurn 4+: Ooze Touch until Ultra Safe Napalm Carrier dies, or Rapana Whelk does\nIf:: Rapana Whelk dies before Napalm, bring in your Shimmershell Snail and Ooze Touch\nIf:: Rapana Whelk survives to fight Freeze Ray, then: Acidic Goo > Ooze Touch until dead\nBring in your Shimmershell Snail / Mudshell Conch \nPriority 1: : Dive to avoid Ice Tomb / Sewer Eruption\nPriority 2: : Apply Acidic Goo once\nPriority 3:: Ooze Touch all else\n",
	},
	[94648] = {
		{
			"BattlePet-0-000009E1AED7", -- [1]
			0, -- [2]
			1015, -- [3]
			282, -- [4]
			1537, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B001", -- [1]
			514, -- [2]
			270, -- [3]
			1756, -- [4]
			2134, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B000", -- [1]
			525, -- [2]
			597, -- [3]
			168, -- [4]
			1722, -- [5]
		}, -- [3]
		["teamName"] = "Netherfist",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9739\n\nStrategy added by Mutanis\nTime: 2-3 min\n\nYou take zero damage from Fel Corruption. Your Skyfin Juvenile and Dream Whelpling have 100% health at the start fighting backline pets.\n\nYou also can use Void-Scarred Anubisath (2/1/1) or Anubisath Idol (1/1/1) -->(Void>Idol). TD Script works in that case too.\n\nTurn 1: Blinding Powder\nTurn 2: Swap to your Skyfin Juvenile\nTurn 3: Glowing Toxin\nTurn 4: Swap to your Crimson Spore\nTurn 5: Blinding Powder\nTurn 6: Explode\nBring in your Skyfin Juvenile\nTurn 7: Glowing Toxin\nTurn 8: Wing Buffet --> Netherfist dies in a few turns backline\nAn enemy pet comes in\nTurn 9: Glowing Toxin\nTurn 10: Wild Winds until Skyfin Juvenile dies\nBring in your Dream Whelpling\nPrio Rotation for backline pets (Dream Whelpling is active)\nPrio 1: if Dream Whelpling health< ~ 70% then Healing Flame \nPrio 2: Emerald Presence if duration < 1 or  enemy has Burrow, Dive, Lift-Off ...\nPrio 3: Emerald Bite\n",
	},
	[142151] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			566, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["minHP"] = 501,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2216\n\nStrategy added by Laponko\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up\nTurn 4: Wind-Up\nTurn 5: Swap to Level Pet\nTurn 6: Swap to Iron Starlette\nTurn 7: Wind-Up\n",
		["teamName"] = "You've Never Seen Jammer Upset",
		["minXP"] = 25,
	},
	[150914] = {
		{
			"BattlePet-0-000009E1AFE5", -- [1]
			493, -- [2]
			1231, -- [3]
			652, -- [4]
			1442, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFA5", -- [1]
			778, -- [2]
			310, -- [3]
			1360, -- [4]
			1903, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AD9E", -- [1]
			115, -- [2]
			172, -- [3]
			170, -- [4]
			489, -- [5]
		}, -- [3]
		["teamName"] = "Wandering Phantasm",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5972\n\nStrategy added by Threewolves\nTurn 1: Hoof\nTurn 2: Consume Magic\nTurns 3+: Hoof til enemy #2 enters.\nTurn 4: Haunt\n\nBring in Zoom if enemy #2 is Undead or Dragonkin:\nBring in Spawn of Onyxia if enemy #2 is Magic:\n\nIf Zoom:: Keep Shell Shield active. Keep Slow and Steady on Cooldown. Otherwise, Charge til dead or done.\nIf Onyxia:: Keep Lift-Off and Scorched Earth on Cooldown. Otherwise, Breath til dead or done.\n",
	},
	[73626] = {
		{
			"BattlePet-0-000009E1AE55", -- [1]
			901, -- [2]
			392, -- [3]
			204, -- [4]
			1178, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B0B5", -- [1]
			384, -- [2]
			278, -- [3]
			710, -- [4]
			277, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B125", -- [1]
			777, -- [2]
			647, -- [3]
			334, -- [4]
			339, -- [5]
		}, -- [3]
		["teamName"] = "Little Tommy Newcomer",
		["notes"] = "Strategy added by zekrrun\nStrategy credit to mel9525@WowHead.com\n\nTurn 1: Call Lightning\nLil' Oondasta's  Frill Blast ability will force Clockwork Gnome out\nTurn 2: Build Turret\nTurn 3: Metal Fist\nIf at round 3 your Clockwork Gnome just die and resurrect with  Failsafe, bring out Sunreaver Micro-Sentry and pass then bring your Clockwork Gnome an skip to Turn 5\nTurn 4: Metal Fist\nTurn 5: Build Turret\n    Clockwork Gnome usually dies here, bring out Darkmoon Zeppelin\nTurn 6: Decoy\nTurn 7: Missile\nTurn 8: Missile\n\n",
	},
	[150917] = {
		{
			"BattlePet-0-000009E1AEA1", -- [1]
			0, -- [2]
			0, -- [3]
			305, -- [4]
			1212, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B161", -- [1]
			921, -- [2]
			0, -- [3]
			919, -- [4]
			1211, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["minHP"] = 1303,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6566\n\nStrategy added by DavidG\nTurn 1: Exposed Wounds\nTurn 2: Black Claw\nTurn 3-4: Hunting Party\nTurn 5: By the time Hunting party finishes he'll be in his undead round, so just do whatever and let him die\n",
		["teamName"] = "Huncher",
		["minXP"] = 25,
	},
	[68463] = {
		{
			"BattlePet-0-000009E1B15F", -- [1]
			406, -- [2]
			453, -- [3]
			490, -- [4]
			1155, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/28\n\nTurn 1: Crush\nTurn 2: Sandstorm\nTurn 3: Deflection\nTurns 4+: Crush until Crimson is dead (refresh Sandstorm if it comes off cooldown)\nPandaren Fire Spirit comes in\nTurn 1: Deflection (NOTE: Unfortunately if you get a crit on Crimson then Deflection will not be available and you will have to restart the fight)\nTurns 2+: Keep Sandstorm on cooldown and use Crush in between.\nImportant: When Deflection comes off cooldown, cast Crush or Sandstorm, then use Deflection again.\nPandaren Fire Spirit should die shortly after the second Deflection. \nGlowy comes in\nUse Crush until Sandstorm comes off cooldown\nThen use Sandstorm\nSwap in Level-Pet 1\nSwap in Level-Pet 2 if you want\nSwap back to Anubisath Idol\nSame as before, Sandstorm on cooldown and Crush in between until Glowy dies.\n",
		["teamName"] = "Burning Pandaren Spirit",
		["minXP"] = 5,
	},
	[94640] = {
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			110, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			0, -- [3]
			321, -- [4]
			1238, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B1CE", -- [1]
			1066, -- [2]
			453, -- [3]
			490, -- [4]
			2833, -- [5]
		}, -- [3]
		["teamName"] = "Felfly",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9371\n\nStrategy added by Mutanis\nOriginal strat is not from me: https://www.wow-petguide.com/?Strategy=86\nI just optimized it.\n\nFirst:\nVoid-Scarred Anubisath is better than Anubisath Idol. Spiritfire Bolt is strong against flying pet and not weak against any backline pet from the Tanaan Jungle. On the other hand Crush is weak against beasts and there could be beasts. Dragons have never been seen there :'(\n\nSecond:\nI got greedy with fighting time. Unholy Ascension is to make the enemy team a bit weaker. But there is a risk that this strat will fail. If yo want to be save then play a second Void-Scarred Anubisath or Anubisath Idol. (TD-Script works as well in this case)\n\nThird:\nI optimized the TD script. Reflective Shield is only used if the enemy pet has the aura Burrow, Dive or Lift-Off.\n\nTested 11/21/2020 (9.0.2)\n\nTurn 1: Howl\nTurn 2-4: Surge of Power\n\nA fast version -- B safe version (2x Void-Scarred Anubisath or Anubisath Idol)\n\nA\nTurn 1: Swap to your Unborn Val'kyr\nTurn 2: Unholy Ascension\nBring in your Void-Scarred Anubisath\nTurn 3-x: prio rotation: Deflection for Burrow, Dive and Lift-Off > Sandstorm > Spiritfire Bolt\n\nB\nTurn 1: Bite until Chrominius dies\nBring in your Void-Scarred Anubisath\nTurn 2-x: prio rotation: Deflection for Burrow, Dive and Lift-Off > Sandstorm > Spiritfire Bolt\n--> if your first Void-Scarred Anubisath dies then bring in your second one\n",
	},
	[140813] = {
		{
			"BattlePet-0-000009E1B16C", -- [1]
			118, -- [2]
			564, -- [3]
			513, -- [4]
			868, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1ADDF", -- [1]
			449, -- [2]
			310, -- [3]
			564, -- [4]
			743, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2030\n\nStrategy added by NostrA#2338\nThis Strategy can still fail when you are very unlucky with crits. If you want to level a flying pet, it should be level 19+\n\nTurn 1: use Whirlpool\nTurn 2: use Dive\nTurn 3: use Water Jet\nenemy Azerite Slime dies\nTurn 1: use Whirlpool\nTurn 2+: use Water Jet until your Pandaren Water Spirit dies\nbring in your Level Pet\nbring in your Rapana Whelk\nPriority 1: use Shell Shield when the duration is at 1\nPriority 2: use Dive when available\nPriority 3: use Absorb\n",
		["teamName"] = "Rogue Azerite",
		["minXP"] = 12,
	},
	[94639] = {
		{
			"BattlePet-0-000009E1B0BA", -- [1]
			504, -- [2]
			1991, -- [3]
			1963, -- [4]
			2544, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF48", -- [1]
			116, -- [2]
			634, -- [3]
			282, -- [4]
			85, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B0C9", -- [1]
			393, -- [2]
			2223, -- [3]
			172, -- [4]
			2352, -- [5]
		}, -- [3]
		["teamName"] = "Cursed Spirit",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9270\n\nStrategy added by Mutanis\nTime: ~1:40 - 2:00 (depends on quality and abilities of the backline pets)\n\nIf you have problems with Dazzling Dance --> Try this one (https://www.wow-petguide.com/?Strategy=9603)\n\nThe easiest way is to use td scripts for this strategy :)\nYou can use the same strategy for  Vile Blood of Draenor (https://www.wow-petguide.com/index.php?Strategy=9249), Corrupted Thundertail (https://www.wow-petguide.com/index.php?Strategy=9238), Tainted Maulclaw (https://www.wow-petguide.com/index.php?Strategy=9257), Dark Gazer (https://wow-petguide.com/index.php?Strategy=9312) and Chaos Pup (https://wow-petguide.com/index.php?Strategy=9322). TD Script is the same!\n\nTested 01/12/2021\n\nNOTE: If your enemy has Violet Firefly with Dazzling Dance --> start fight again\nTurn 1: Wind Buffet\nAn enemy pet comes in\nTurn 2: Alpha Strike\nTurn 3: Ancient Knowledge\nTurn 4: If enemy pets hp > 390 (aquatic 585) then Alpha Strike else pass\nTurn 5+: Alpha Strike until the enemy pet dies\nCursed Spirit comes in\nTurn 1: Wind Buffet -- if Darkshore Sentinel is slower than Cursed Spirit or dead --> start fight again\nAn enemy pet comes in\nTurn 1+: Alpha Strike until the enemy pet hp < 50% \nTurn 2: Swap to your Pet Bombling\nTurn 3: Minefield\nTurn 4+: Zap until the enemy pet dies\nCursed Spirit comes in\nTurn 1: Explode\nBring in your Baa'l\nTurn 1: Murder the Innocent\nTurn 2+: Shadowflame --> Corrupted Thundertail dies\n",
	},
	[161657] = {
		{
			"BattlePet-0-000009E1B15F", -- [1]
			406, -- [2]
			453, -- [3]
			490, -- [4]
			1155, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8239\n\nStrategy added by Silverleaf#1446\nPriority 1: Deflection when Whirlpool is at 1\nPriority 2: Sandstorm\nPriority 3: Crush\n",
		["teamName"] = "Ninn Jah",
		["minXP"] = 25,
	},
	[142114] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			566, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE77", -- [1]
			122, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2761\n\nStrategy added by DisposableH#1293\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up - Eighty-eight dies\nTurn 4: Wind-Up\nTurn 5: Powerball\nTurn 6: Supercharge - Iron Starlette triggers failsafe\nTurn 7: Wind-Up - Turbo dies\nTurn 8: Pass - Iron Starlette dies, bring in leveling pet\nTurn 9: Swap to your Nexus Whelpling\nTurn 10: Arcane Storm\nTurn 11: Mana Surge - If whiplash isn't dead after Mana Surge finishes with Arcane Storm\n",
		["teamName"] = "Add More to the Collection",
		["minXP"] = 1,
	},
	[68559] = {
		{
			"BattlePet-0-000009E1AF94", -- [1]
			1773, -- [2]
			165, -- [3]
			518, -- [4]
			1974, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFAA", -- [1]
			1370, -- [2]
			1773, -- [3]
			518, -- [4]
			1977, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3498\n\nStrategy added by DragonsAfterDark\nTurn 1: Crouch\nFor both Falcosaurs:\n~~: Use Predatory Strike & Savage Talon with Shattered Defenses, unless Beaver Dam is up\n~~: Beaver Dam is up and all else: Falcosaur Swarm!\n",
		["teamName"] = "No-No",
		["minXP"] = 1,
	},
	[150918] = {
		{
			"BattlePet-0-000009E1ADB4", -- [1]
			119, -- [2]
			632, -- [3]
			706, -- [4]
			747, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "Tommy the Cruel",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6029\n\nStrategy added by Nordak\nTurn 1-3: Swarm\nTurn 4: Scratch\nTurn 5: Scratch\nTurn 6: Pass\n",
	},
	[94601] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			0, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEF5", -- [1]
			1369, -- [2]
			1049, -- [3]
			919, -- [4]
			1565, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B000", -- [1]
			525, -- [2]
			597, -- [3]
			168, -- [4]
			1722, -- [5]
		}, -- [3]
		["teamName"] = "Felsworn Sentry",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10180\n\nStrategy added by Mutanis\nTime: ~2-3min\n\nEasy and safe strategy!\n\ntested 12 april 2021\n\nTurn 1: Blistering Cold\nTurn 2: Chop\nTurn 3: Swap to your Mechanical Scorpid\nTurn 4: Blinding Poison\nTurn 5: Black Claw\nTurn 6: Swap to your Boneshard\nTurn 7: Blistering Cold --> Felsworn Sentry dies\nAn enemy pet comes in\nPrio list: Blistering Cold >> Chop until Boneshard dies\nBring in your Mechanical Scorpid\nPrio list: Black Claw >> Blinding Poison >> Barbed Stinger until Mechanical Scorpid dies\nDream Whelpling comes in\nPrio list: Emerald Presence  >> Healing Flame hp < 70% >> Emerald Bite\n",
	},
	[141292] = {
		{
			"BattlePet-0-000009E1AFC9", -- [1]
			1773, -- [2]
			1758, -- [3]
			518, -- [4]
			1975, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF94", -- [1]
			0, -- [2]
			0, -- [3]
			518, -- [4]
			1974, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2255\n\nStrategy added by Eekwibble\nI changed this from having a carry pet because the xp is so lame since the nerf. The upside is, it now only lasts 13 rounds.\n\nTurn 1: Ironskin\nTurns 2&3: Falcosaur Swarm!\nTurn 4: Predatory Strike - Fungus dies\nMort comes in\nTurn 1: Pass\nTurn 2: Ironskin\nTurns 3&4: Falcosaur Swarm!\nTurn 5: Predatory Strike - Mort dies\nOld Blue comes in\nTurn 1+: Falcosaur Swarm! until Direbeak Hatchling dies\nBring in your Snowfeather Hatchling\nThen:: Predatory Strike - Old Blue dies\n",
		["teamName"] = "That's a Big Carcass",
		["minXP"] = 25,
	},
	[155267] = {
		{
			"BattlePet-0-000009E1B165", -- [1]
			360, -- [2]
			1049, -- [3]
			152, -- [4]
			2190, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B176", -- [1]
			115, -- [2]
			779, -- [3]
			334, -- [4]
			844, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["teamName"] = "Risen Guard",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6023\n\nStrategy added by Shenk\nReads hard, but it's actually simple. Just using the abilities as you'd usually always do.\nGuardian Cobra Hatchling can solo it when there is no magic enemy pet. \n\nTurn 1: Blinding Poison\nTurn 2: Flurry until Risen Guard enters undead phase\n*: Risen Guard enters undead phase. Is the next pet a Lost Soul or Tormented Spirit?\nTurn 4:  Yes - Swap to your Mechanical Pandaren Dragonling, then skip to the \"Magic enemy\" at the bottom\nTurn 4: No - Pass\nAn enemy pet comes in\nTurn 1: Blinding Poison\nTurn 2: Flurry until the enemy enters undead phase\n The second pet enters undead phase. Is the next pet a Lost Soul or Tormented Spirit?\nTurn 3: Yes - Swap to your Mechanical Pandaren Dragonling, then skip to the \"Magic enemy\" at the bottom\nTurn 4: No - Pass\n\nMagic enemy\nTurn 1: Thunderbolt\nTurn 2: Decoy\nTurn 3: Breath until enemy pet dies\n",
	},
	[94649] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			422, -- [2]
			218, -- [3]
			321, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF91", -- [1]
			499, -- [2]
			362, -- [3]
			665, -- [4]
			1146, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEA2", -- [1]
			525, -- [2]
			597, -- [3]
			598, -- [4]
			1167, -- [5]
		}, -- [3]
		["teamName"] = "Skrillix",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/590\n\nTurn 1: Curse of Doom\nTurn 2: Pass\nTurn 3: Pass\nTurn 4: Unholy Ascension\nBring in your Stitched Pup\nTurn 3: Howl - Skrillix dies\nTurn 4+: Diseased Bite until your Pup is done\nBring in your Tanaan Pet\nUse this pet to clean up :-)\nGreat choices are an Anubisath Idol or an Emerald Proto-Whelp.\n",
	},
	[173263] = {
		{
			"BattlePet-0-000009E1B1F6", -- [1]
			0, -- [2]
			1087, -- [3]
			706, -- [4]
			1338, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B170", -- [1]
			849, -- [2]
			312, -- [3]
			163, -- [4]
			848, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B160", -- [1]
			0, -- [2]
			208, -- [3]
			209, -- [4]
			2717, -- [5]
		}, -- [3]
		["teamName"] = "Extra Pieces",
		["notes"] = "Strategy added by norng\n13 rounds.\n\nTurn 1: Toxic Skin\nTurns 2-4: Swarm - Leftovers resurrects\nTurn 5: Swap to your Darkmoon Rabbit - Leftovers dies\nLeftovers comes in\nTurn 1: Huge, Sharp Teeth!\nTurn 2: Dodge\nTurns 3-5: Stampede - Darkmoon Rabbit dies\nBring in your Microbot XD\nTurn 1: Supercharge - Leftovers dies\nLeftovers comes in\nTurn 1-2: Ion Cannon - Leftovers dies\n",
	},
	[161651] = {
		{
			"BattlePet-0-000009E1B1A4", -- [1]
			1085, -- [2]
			456, -- [3]
			752, -- [4]
			1601, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			640, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10265\n\nStrategy added by Berendain\nTurn 1: Clean-Up\nTurn 2: Soulrush\nTurn 3: Swap to your Iron Starlette\nTurn 4: Wind-Up\nTurn 5: Supercharge\nTurn 6: Wind-Up\nTurn 7: Toxic Smoke until something dies\nTurn 8: If Iron Starlette dies before Ralf does, bring back your Servant of Demidos, and finish him off\n",
		["teamName"] = "Ralf",
		["minXP"] = 1,
	},
	[68462] = {
		{
			"BattlePet-0-000009E1B149", -- [1]
			504, -- [2]
			312, -- [3]
			802, -- [4]
			1416, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/59\n\nTurn 1: Alpha Strike\nTurn 2: Alpha Strike\nTurn 3: Dodge\nTurn 4: Alpha Strike - Marley dies.\nTiptoe comes in.\nTurn 1: Alpha Strike\nTurn 2: Alpha Strike\nTurn 3: Alpha Strike\nTurn 4: Dodge\nTurn 5+6: Ravage\nPandaren Water Spirit comes in.\nTurn 1: Swap to your Level Pet.\nTurn 2: Swap back to your Teroclaw Hatchling \nTurn 3: Alpha Strike\nTurn 4: Dodge\nTurns 5+: Alpha Strike until the fight is won.\n",
		["teamName"] = "Flowing Pandaren Spirit",
		["minXP"] = 15,
	},
	[66918] = {
		{
			"BattlePet-0-000009E1AE33", -- [1]
			356, -- [2]
			511, -- [3]
			310, -- [4]
			746, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			110, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [3]
		["minHP"] = 151,
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/45\n\nTurn 1: Shell Shield\nTurn 2: Renewing Mists\nTurn 3+: Snap until Diamond is dead\nMollus comes in\nTurn 1: Shell Shield\nTurn 2: Renewing Mists\nTurn 3+: Snap until Mollus is dead as well\nSkimmer comes in\nTurn 1: Swap to Level Pet\nTurn 2: Swap back to Emperor Crab\nTurns 3+: Snap until Emperor Crab dies\nBring in Chrominius\nTurn 1: Bite\nTurn 2: Howl\nTurn 3: Surge of Power\n",
		["teamName"] = "Seeker Zusshi",
		["minXP"] = 2,
	},
	[161661] = {
		{
			"BattlePet-0-000009E1B172", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			2438, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B125", -- [1]
			0, -- [2]
			282, -- [3]
			0, -- [4]
			339, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7090\n\nStrategy added by Shenk\nLiterally any pet with explode will work in the 2nd slot, no matter the family.\n\nTurn 1: Black Claw\nTurn 2+3: Flock\nTurn 4+: Peck until Foulfeather dies\nBring in your Darkmoon Zeppelin\nTurn 1: Explode\n",
		["teamName"] = "Wilbur",
		["minXP"] = 1,
	},
	[162458] = {
		{
			0, -- [1]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			1762, -- [4]
			1963, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8104\n\nStrategy added by Hollandshoop\nTurn 1: Pass or use any ability with your Level Pet\nTurn 2: Swap to your Boneshard\nTurn 3: Blistering Cold\nTurn 4: Boneshard stunned. Swap to your Ikky\nTurn 5: Black Claw\nTurn 6: Flock\nAnd the job is done!!!\n",
		["teamName"] = "Retinus the Seeker",
		["minXP"] = 1,
	},
	[161662] = {
		{
			"BattlePet-0-000009E1B1AD", -- [1]
			114, -- [2]
			460, -- [3]
			751, -- [4]
			342, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AE9B", -- [1]
			0, -- [2]
			0, -- [3]
			282, -- [4]
			1540, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B1ED", -- [1]
			626, -- [2]
			0, -- [3]
			282, -- [4]
			2565, -- [5]
		}, -- [3]
		["teamName"] = "Char",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/8756\n\nStrategy added by norng\n8 rounds.\n\nTurn 1: Beam\nTurn 2: Soul Ward\nTurn 3: Illuminate\nTurn 4: Swap to your Brilliant Spore\nTurn 5: Explode\nBring in your Rebuilt Mechanical Spider\nTurn 1: Skitter\nTurn 2: Explode - Char resurrects\nBring in your Festival Lantern\nTurn 1: Pass - Char dies\n",
	},
	[161663] = {
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7179\n\nStrategy added by Shenk\nTurn 1: Black Claw\nTurn 2-4: Flock\n",
		["teamName"] = "Tempton",
		["minXP"] = 1,
	},
	[155414] = {
		{
			"BattlePet-0-000009E1AFF3", -- [1]
			943, -- [2]
			786, -- [3]
			0, -- [4]
			1963, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEF5", -- [1]
			1369, -- [2]
			1049, -- [3]
			919, -- [4]
			1565, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B1D7", -- [1]
			219, -- [2]
			312, -- [3]
			1052, -- [4]
			2456, -- [5]
		}, -- [3]
		["teamName"] = "Ezra Grimm",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10185\n\nStrategy added by Mutanis\nTime: ~2:30\n\nTurn 1: Blistering Cold\nTurn 2: Chop\nTurn 3: Swap to your Mechanical Scorpid\nTurn 4: Blinding Poison\nTurn 5: Black Claw\nif: Smokey isn't dead then Barbed Stinger --> Smokey dies\nPyro comes in\nTurn 1: Swap to your Barnaby\nTurn 2: Dodge\nTurns 3-7: Jab (5x)\nTurn 8: Dodge\nTurn 9+: Jab until  Pyro hp < 335 then Tornado Punch  --> Pyro dies\nInfectus comes in\nTurn 1: Swap to your Mechanical Scorpid\nTurn 2: Blinding Poison\nTurn 3: Swap to your Boneshard\nTurn 4: Blistering Cold\nTurn 5: Chop\nTurn 6: Swap to your Mechanical Scorpid\nTurn 7: Blinding Poison\nTurn 8: Black Claw\nTurn 9: Barbed Stinger --> infectus undead phase\nTurn 10: Pass --> Infectus dies (and in best case scenario your whole team is alive!)\n",
	},
	[139489] = {
		{
			"BattlePet-0-000009E1AFC9", -- [1]
			1773, -- [2]
			0, -- [3]
			518, -- [4]
			1975, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFAA", -- [1]
			1370, -- [2]
			1773, -- [3]
			518, -- [4]
			1977, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AFBD", -- [1]
			1773, -- [2]
			0, -- [3]
			518, -- [4]
			1976, -- [5]
		}, -- [3]
		["teamName"] = "Crab People",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2148\n\nStrategy added by DragonsAfterDark\nGreat flocking Falcosaurs! It's hard to go wrong with any order of attacks on this one, just try to keep the debuff from Falcosaur Swarm! up, and you should have no issues. \n\nTurn 1 + 2: Falcosaur Swarm!\nTurn 3: Predatory Strike\nTurn 4: Falcosaur Swarm! until Shelly is dead. \nSheldon comes in\nTurn 1: Falcosaur Swarm! until Direbeak Hatchling dies. \nBring in your Bloodgazer Hatchling\nTurn 1: Predatory Strike\nTurn 2: Savage Talon until Sheldon is dead. \nShelby comes in\nTurn 1: Falcosaur Swarm! until Predatory Strike is up. \nTurn 2: Predatory Strike\n",
	},
	[68560] = {
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			0, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B125", -- [1]
			777, -- [2]
			282, -- [3]
			334, -- [4]
			339, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/4725\n\nStrategy added by Kurasu#2861\nTurn 1: Wind-Up\nTurn 2: Supercharge\nTurn 3: Wind-Up\nTurn 4: Use any basic attack until Iron Starlette dies.\nBring in your Darkmoon Zeppelin\nTurn 1+: If enemy is not below 614 health, Decoy and Missile until it is. \nIf enemy is below 614 health, Explode.\nLeveling pet gets all the XP.\n",
		["teamName"] = "Greyhoof",
		["minXP"] = 1,
	},
	[141046] = {
		{
			"BattlePet-0-000009E1AFAE", -- [1]
			1570, -- [2]
			1062, -- [3]
			1572, -- [4]
			1753, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFE2", -- [1]
			122, -- [2]
			1758, -- [3]
			611, -- [4]
			1956, -- [5]
		}, -- [2]
		{
			"random:2", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2101\n\nStrategy added by DragonsAfterDark\nMind Warper hurts something fierce, so I kept a level pet out of this particular strat. \n\nTurn 1: Rain Dance\nTurn 2: Squeeze\nTurn 3: Tentacle Slap\nLesser Twisted Current comes in\nTurn 1+: Tentacle Slap until Rain Dance is off CD\n~~: Rain Dance\n~~: Squeeze\n~~: Tentacle Slap until Lesser Twisted Current is dead. \nMind Warper comes in\nTurn 1+2: Pass\nBring in your Ironbound Proto-Whelp\nTurn 1: Ironskin\nTurn 2: Ancient Blessing\nTurn 3+: Tail Sweep until Mind Warper is dead, or Ironbound Proto-Whelp is. \nBring in your Dragonkin pet\nAny standard Dragonkin attack will finish the fight\n",
		["teamName"] = "Captured Evil",
		["minXP"] = 25,
	},
	[139987] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1B158", -- [1]
			1002, -- [2]
			0, -- [3]
			985, -- [4]
			1320, -- [5]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/2287\n\nStrategy added by gsanta\nI was able to bring a Level 1 pet with no damage taken.\n\nTurn 1: Curse of Doom\nTurn 2: Haunt\nTurn 3: Bring in your Level Pet\nTurn 4: Swap to your Lil' Bling\nTurn 5: Make it Rain\nTurn 6+: Inflation\n",
		["teamName"] = "This Little Piggy Has Sharp Tusks",
		["minXP"] = 1,
	},
	[155413] = {
		{
			"BattlePet-0-000009E1B016", -- [1]
			228, -- [2]
			232, -- [3]
			934, -- [4]
			1934, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE21", -- [1]
			228, -- [2]
			232, -- [3]
			934, -- [4]
			1182, -- [5]
		}, -- [3]
		["teamName"] = "Postmaster Malown",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6060\n\nStrategy added by Stilgar#2864\nTurn 1: Swarm of Flies\nTurn 2-4: Tongue Lash\nTurn 5: Bubble\nTurn 6-9: Tongue Lash\nUndead round: Swarm of Flies\nPlagued Mailemental comes in\nTurn 11: Benax will die, swap to Ikky\nTurn 12: Black Claw\nTurn 13: Flock\nTurn 14: Ikky dies, swap to Croaker\nTongue Lash\nSoul Collector comes in\nKeep Swarm of Flies up\nBubble when you can to keep your hp up\nTongue Lash everything else\n",
	},
	[161658] = {
		{
			"BattlePet-0-000009E1B0E2", -- [1]
			0, -- [2]
			218, -- [3]
			1084, -- [4]
			2580, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF94", -- [1]
			1773, -- [2]
			165, -- [3]
			518, -- [4]
			1974, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B0AA", -- [1]
			113, -- [2]
			1041, -- [3]
			0, -- [4]
			2466, -- [5]
		}, -- [3]
		["teamName"] = "Shred",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7078\n\nStrategy added by DragonsAfterDark\nTurn 1: Curse of Doom\nTurn 2: Fade\nYour Snowfeather Hatchling is brought in\nTurn 1: Crouch\nTurn 2+3: Falcosaur Swarm!\nTurn 4: Predatory Strike\nTurn 5+: Falcosaur Swarm! until dead\nBring in your Giggling Flame\nTurn 1+: Burn until Shred's Mech round\nMech: Flame Jet\n",
	},
	[94650] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			422, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			1370, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1AEA2", -- [1]
			525, -- [2]
			597, -- [3]
			598, -- [4]
			1167, -- [5]
		}, -- [3]
		["teamName"] = "Defiled Earth",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/1239\n\nStrategy added by Aranesh\nTurn 1: Curse of Doom\nTurn 2: Haunt\nBring in Ikky\nTurn 3: Black Claw\nTurn 4: Flock\nTurn 5+: Savage Talon until Ikky dies\nBring in Emerald Proto-Whelp\nTurns 1-3: Emerald Dream\nTurn 4: Emerald Presence\nTurns 5+: Emerald Bite until the last pet is dead, keep Emerald Presence active.\n",
	},
	[140880] = {
		{
			"BattlePet-0-000009E1AEA2", -- [1]
			525, -- [2]
			597, -- [3]
			598, -- [4]
			1167, -- [5]
		}, -- [1]
		{
			"random:0", -- [1]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5357\n\nStrategy added by Runisco\nPrio 1: Emerald Presence up. Use when 1 turn left\nPrio 2: Emerald Dream when health < 750\nPrio 3: Standby. There is no point in attacking, the bees stinging is cooldown based\nAs soon as one bee uses sting and dies, the others will. Your whelp should survive all 3.\n",
		["teamName"] = "What's the Buzz?",
		["minXP"] = 25,
	},
	[161656] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AD91", -- [1]
			163, -- [2]
			743, -- [3]
			0, -- [4]
			627, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/7094\n\nStrategy added by Shenk\nYou can use pretty much any pet with Stampede-like abilities instead of the Infected Squirrel.\n\nTurn 1: Pass\nTurn 2: Curse of Doom\nTurn 3: Haunt\nBring in your Infected Squirrel\nTurn 1: Creeping Fungus\nTurn 2-3: Stampede\n",
		["teamName"] = "Splint",
		["minXP"] = 1,
	},
	["Growing Ectoplasm 1"] = {
		{
			"BattlePet-0-000009E1AD91", -- [1]
			163, -- [2]
			743, -- [3]
			663, -- [4]
			627, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEC5", -- [1]
			112, -- [2]
			916, -- [3]
			170, -- [4]
			1403, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/5887\n\nStrategy added by DragonsAfterDark\nTurn 1: Creeping Fungus\nTurn 2-4: Stampede\nTurn 5: Corpse Explosion\n\nBring in your Mechanical Axebeak\nTurn 1: Peck\nRandom Enemy Pet comes in\n\nDeviate Flapper:\nPeck > Lift-Off > Haywire\n\nDeviate Smallclaw:\nHaywire > Peck+\n\nDeviate Chomper:\nLift-Off > Peck+\n",
		["minXP"] = 25,
	},
	[68464] = {
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			299, -- [2]
			611, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [1]
		{
			0, -- [1]
		}, -- [2]
		{
			"BattlePet-0-000009E1AE77", -- [1]
			122, -- [2]
			489, -- [3]
			589, -- [4]
			1165, -- [5]
		}, -- [3]
		["teamName"] = "Whispering Pandaren Spirit",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/233\n\nTurns 1+: Use Ancient Blessing on cooldown, otherwise Arcane Explosion or Pass if you are stunned until Chrominius dies\nBring in your Level Pet\nTurn 1: Swap to your Nexus Whelpling\nTurn 2: Arcane Storm\nTurns 3+: Mana Surge\n",
	},
	[68465] = {
		{
			"BattlePet-0-000009E1ADDE", -- [1]
			445, -- [2]
			369, -- [3]
			564, -- [4]
			568, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B125", -- [1]
			777, -- [2]
			282, -- [3]
			334, -- [4]
			339, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/26\n\nTurns 1+2: Dive\nTurn 3: Acidic Goo\nTurn 4: Ooze Touch until Pandaren Earth Spirit dies.\nSludgy comes in\nTurn 1: Acidic Goo\nTurns 2+: Keep Ooze Touching until your Snail dies.\nBring in your Darkmoon Zeppelin\nTurns 1+: Missile until Sludgy dies.\nDarnak comes in\nTurn 1: Missile\nTurn 2: Decoy\nImportant: While doing the next moves. If he gets below 850 and has Stone rush ready, just Skip to Explode for he will do 240 damage to himself.\nTurn 3+: Missile until Darnak is below 618 health.\nThen (BOOM!): Explode\nYour level pet will be the only survivor and get the full experience of the fight.\n",
		["teamName"] = "Thundering Pandaren Spirit",
		["minXP"] = 1,
	},
	[173274] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			218, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B124", -- [1]
			626, -- [2]
			919, -- [3]
			706, -- [4]
			2648, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1ADB4", -- [1]
			119, -- [2]
			0, -- [3]
			706, -- [4]
			747, -- [5]
		}, -- [3]
		["teamName"] = "Failed Experiment",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9530\n\nStrategy added by Lazey\n(~7 rounds)\n\n*** Created on Beta, so maybe not final  ***\n\nTurn 1: Curse of Doom\nTurn 2: Haunt\nBring in your Chitterspine Skitterling\nTurn 3: Black Claw\nTurns 4-6: Swarm\nTurn 7: Pass in Gorgemouth's Undead round\n(if needed, trigger Undead with Scratch after bringing in your last pet)\n",
	},
	[66733] = {
		{
			"BattlePet-0-000009E1B125", -- [1]
			777, -- [2]
			282, -- [3]
			334, -- [4]
			339, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AEB6", -- [1]
			0, -- [2]
			362, -- [3]
			593, -- [4]
			1152, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/70\n\nStrategy by Rendigar published on Warcraft Pets (https://www.warcraftpets.com/community/forum/viewtopic.php?f=3&t=7556#p57980).\n\n\n\nTurn 1: Missile \nTurn 2: Decoy \nTurns 3+: Missile until Woodcarver is dead \nLightstalker comes in \nTurn 1: Swap to Chrominius\nTurn 2: Howl \nTurn 3: Surge of Power – Lightstalker dies\nNeedleback comes in and kills Chrominius \nBring back in your Darkmoon Zeppelin\nTurn 1 : Missile \nTurn 2: Missile \nTurn 3: Decoy \nTurns 4+: Missile until Needleback is below 619 health \nExplode \nYour level pet enjoys the XP!\n",
		["teamName"] = "Mo'ruk",
		["minXP"] = 1,
	},
	[87110] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			210, -- [2]
			0, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF59", -- [1]
			648, -- [2]
			611, -- [3]
			649, -- [4]
			266, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["teamName"] = "Tarr the Terrible",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/3\n\nTurn 1: Haunt\nBring in Fossilized Hatchling\nTurn 1: BONESTORM Gladiator Murkalot switches with Gladiator Deathy\nTurn 2: Ancient Blessing\nTurn 3: Swap to your Level Pet\nTurn 4: Swap back to your Fossilized Hatchling\nTurn 5: BONESTORM - killing off Gladiator Murkalot in the back row\nTurn 6: Ancient Blessing\nTurn 7: Bone Bite\nTurn 8: Bone Bite Killing of Gladiator Deathy\nGladiator Murkimus comes in\nTurns 1+ : Use Ancient Blessing on cooldown and otherwise Bone Bite until your Fossilized Hatchling dies.\nBring in your Unborn Val'kyr\nTurns 1+ : Shadow Slash until the fight is done!\n",
	},
	[94637] = {
		{
			"BattlePet-0-000009E1B0BA", -- [1]
			504, -- [2]
			1991, -- [3]
			1963, -- [4]
			2544, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AF48", -- [1]
			116, -- [2]
			634, -- [3]
			282, -- [4]
			85, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B0C9", -- [1]
			393, -- [2]
			2223, -- [3]
			0, -- [4]
			2352, -- [5]
		}, -- [3]
		["teamName"] = "Corrupted Thundertail",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/9238\n\nStrategy added by Mutanis\nTime: ~1:40 - 2:00 (depends on quality and abilities of the backline pets)\n\nThis strat is safe against enemy Team speed buffs (Violet Firefly with Dazzling Dance)\n\nThe easiest way is to use td scripts for this strategy :)\nYou can use the same strategy for  Vile Blood of Draenor (https://www.wow-petguide.com/index.php?Strategy=9249), Cursed Spirit (https://wow-petguide.com/index.php?Strategy=9270), Tainted Maulclaw (https://www.wow-petguide.com/index.php?Strategy=9257), Dark Gazer (https://wow-petguide.com/index.php?Strategy=9312) and Chaos Pup (https://wow-petguide.com/index.php?Strategy=9322). TD Script is the same!\n\nTested 10/14/2020\n\nTurn 1: Wind Buffet\nAn enemy pet comes in\nTurn 2: Alpha Strike\nTurn 3: Ancient Knowledge\nTurn 4: If enemy pets hp > 390 (aquatic 585) then Alpha Strike else pass\nTurn 5+: Alpha Strike until the enemy pet dies\nCorrupted Thundertail comes in\nTurn 1: Wind Buffet\nAn enemy pet comes in\nTurn 1+: Alpha Strike until the enemy pet hp < 50% \nTurn 2: Swap to your Pet Bombling\nTurn 3: Minefield\nTurn 4+: Zap until the enemy pet dies\nCorrupted Thundertail comes in\nTurn 1: Explode\nBring in your Baa'l\nTurn 1: Murder the Innocent\nTurn 2+: Shadowflame --> Corrupted Thundertail dies\n",
	},
	[150858] = {
		{
			"BattlePet-0-000009E1AFC9", -- [1]
			1773, -- [2]
			1758, -- [3]
			518, -- [4]
			1975, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1AFBD", -- [1]
			1773, -- [2]
			514, -- [3]
			518, -- [4]
			1976, -- [5]
		}, -- [2]
		{
			"random:0", -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/10195\n\nStrategy added by Konstapeln\nIronskin\nFalcosaur Swarm!\nPredatory Strike\n\n",
		["teamName"] = "Blackmane",
		["minXP"] = 1,
	},
	[68561] = {
		{
			"BattlePet-0-000009E1AF6E", -- [1]
			0, -- [2]
			0, -- [3]
			652, -- [4]
			1238, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B13A", -- [1]
			0, -- [2]
			919, -- [3]
			581, -- [4]
			1532, -- [5]
		}, -- [2]
		{
			0, -- [1]
		}, -- [3]
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6320\n\nStrategy added by Alexstrasza\nOriginal strategy by CrazyFluffy#21258 (https://www.wow-petguide.com/?Strategy=2789) which had a random pet as 3rd pet.\nI've slightly altered it to include a leveling pet\n\nUnborn Val'kyr\nTurn 1: Haunt\nBring in your Level Pet\n\nLevel Pet\nTurn 1: Swap to your Ikky\n\nIkky\nTurn 1: Black Claw\nTurn 2-4: Flock\n",
		["teamName"] = "Lucky Yi",
		["minXP"] = 1,
	},
	[141799] = {
		{
			"BattlePet-0-000009E1AEC5", -- [1]
			112, -- [2]
			916, -- [3]
			334, -- [4]
			1403, -- [5]
		}, -- [1]
		{
			"BattlePet-0-000009E1B10E", -- [1]
			777, -- [2]
			646, -- [3]
			209, -- [4]
			338, -- [5]
		}, -- [2]
		{
			"BattlePet-0-000009E1B13E", -- [1]
			459, -- [2]
			640, -- [3]
			208, -- [4]
			1387, -- [5]
		}, -- [3]
		["teamName"] = "Pack Leader",
		["notes"] = "Xu-Fu's Pet Guides =^_^=\nhttps://wow-petguide.com/Strategy/6782\n\nStrategy added by RedBeard\nTurn 1: Decoy\nTurn 2: Haywire\nTurn 3: Peck\nTurn 4: Peck\nScars comes in\nTurn 5: Peck\nTurn 6: Haywire\nBring in your Darkmoon Tonk\nTurn 7: Shock and Awe\nTurn 8+: Missile until Scars dies\nUndead: Pass\nLittle Blue comes in\nTurn 9: Missile\nTurn 10: Ion Cannon\nBring in your Iron Starlette\nTurn 1: Toxic Smoke\n",
	},
}
RematchSettings = {
	["ScriptFilters"] = {
		{
			"Unnamed Pets", -- [1]
			"-- Collected pets that still have their original name.\n\nreturn owned and not customName", -- [2]
		}, -- [1]
		{
			"Partially Leveled", -- [1]
			"-- Pets that have earned some xp in battle.\n\nreturn xp and xp>0", -- [2]
		}, -- [2]
		{
			"Unique Abilities", -- [1]
			"-- Pets with abilities not shared by other pets.\n\nif not count then\n  -- create count of each ability per species\n  count = {}\n  for speciesID in AllSpeciesIDs() do\n    for abilityID in AllAbilities(speciesID) do\n      if not count[abilityID] then\n        count[abilityID] = 0\n      end\n      count[abilityID] = count[abilityID] + 1\n    end\n  end\nend\n\nfor _,abilityID in ipairs(abilityList) do\n  if count[abilityID]==1 then\n    return true\n  end\nend", -- [2]
		}, -- [3]
		{
			"Pets Without Rares", -- [1]
			"-- Collected battle pets that have no rare version.\n\nif not rares then\n  rares = {}\n  for petID in AllPetIDs() do\n    if select(5,C_PetJournal.GetPetStats(petID))==4 then\n      rares[C_PetJournal.GetPetInfoByPetID(petID)]=true\n    end\n  end\nend\n\nif canBattle and owned and not rares[speciesID] then\n  return true\nend", -- [2]
		}, -- [4]
		{
			"Hybrid Counters", -- [1]
			"-- Pets with three or more attack types different than their pet type.\n\nlocal count = 0\nfor _,abilityID in ipairs(abilityList) do\n  local abilityType,noHints = select(7, C_PetBattles.GetAbilityInfoByID(abilityID) )\n  if not noHints and abilityType~=petType then\n    count = count + 1\n  end\nend\n\nreturn count>=3\n", -- [2]
		}, -- [5]
	},
	["QueueSortOrder"] = 1,
	["XPos"] = 691.7106323242188,
	["AutoLoad"] = true,
	["LevelingQueue"] = {
		"BattlePet-0-00000C9121B6", -- [1]
		"BattlePet-0-00000C94E699", -- [2]
		"BattlePet-0-00000C9443DB", -- [3]
		"BattlePet-0-00000C98E791", -- [4]
		"BattlePet-0-00000C92B638", -- [5]
		"BattlePet-0-00000C928FA1", -- [6]
		"BattlePet-0-00000C92F876", -- [7]
		"BattlePet-0-00000C91D906", -- [8]
		"BattlePet-0-00000C927779", -- [9]
		"BattlePet-0-00000C9BDBEF", -- [10]
		"BattlePet-0-000009E1B287", -- [11]
		"BattlePet-0-00000C948A26", -- [12]
		"BattlePet-0-00000C954FC3", -- [13]
		"BattlePet-0-000009E1B278", -- [14]
		"BattlePet-0-00000A2EB5B6", -- [15]
		"BattlePet-0-000009E1B1F7", -- [16]
		"BattlePet-0-00000C77F960", -- [17]
		"BattlePet-0-00000C9F3FB8", -- [18]
		"BattlePet-0-000009E1B22F", -- [19]
		"BattlePet-0-00000A2BC101", -- [20]
		"BattlePet-0-00000C8FBD54", -- [21]
		"BattlePet-0-000009E1B266", -- [22]
		"BattlePet-0-000009E1B285", -- [23]
		"BattlePet-0-000009E1B24C", -- [24]
		"BattlePet-0-000009E1B24D", -- [25]
		"BattlePet-0-00000AB0B6E1", -- [26]
		"BattlePet-0-000009E1B269", -- [27]
		"BattlePet-0-000009E1B232", -- [28]
		"BattlePet-0-000009E1B261", -- [29]
		"BattlePet-0-000009E1B271", -- [30]
		"BattlePet-0-000009E1B276", -- [31]
		"BattlePet-0-00000C93FB01", -- [32]
		"BattlePet-0-00000C77610F", -- [33]
		"BattlePet-0-00000C77610E", -- [34]
		"BattlePet-0-00000A12B407", -- [35]
		"BattlePet-0-00000C778DF1", -- [36]
		"BattlePet-0-000009E1B230", -- [37]
		"BattlePet-0-00000C939924", -- [38]
		"BattlePet-0-000009E1B268", -- [39]
		"BattlePet-0-00000C77F95F", -- [40]
		"BattlePet-0-00000A01BCFF", -- [41]
		"BattlePet-0-000009E1B281", -- [42]
		"BattlePet-0-00000C929728", -- [43]
		"BattlePet-0-000009E1B22D", -- [44]
		"BattlePet-0-000009E1B1FE", -- [45]
		"BattlePet-0-000009E1B1D6", -- [46]
		"BattlePet-0-000009E1B218", -- [47]
		"BattlePet-0-00000BE75719", -- [48]
		"BattlePet-0-00000C9290B3", -- [49]
		"BattlePet-0-000009E1B257", -- [50]
		"BattlePet-0-00000A07CFFA", -- [51]
		"BattlePet-0-00000A011B65", -- [52]
		"BattlePet-0-000009E1B275", -- [53]
		"BattlePet-0-00000C79653A", -- [54]
		"BattlePet-0-000009E1B1F9", -- [55]
		"BattlePet-0-000009E1B283", -- [56]
		"BattlePet-0-000009E1B213", -- [57]
		"BattlePet-0-00000C80D76C", -- [58]
		"BattlePet-0-00000C788A81", -- [59]
		"BattlePet-0-000009E1B1C9", -- [60]
		"BattlePet-0-000009E1B18B", -- [61]
		"BattlePet-0-000009E1B25D", -- [62]
		"BattlePet-0-000009E1B282", -- [63]
		"BattlePet-0-00000A0B4F3E", -- [64]
		"BattlePet-0-000009E1B26E", -- [65]
		"BattlePet-0-00000BA8EA08", -- [66]
		"BattlePet-0-000009E1B258", -- [67]
		"BattlePet-0-000009E1B21F", -- [68]
		"BattlePet-0-000009E1B1E4", -- [69]
		"BattlePet-0-000009E1B217", -- [70]
		"BattlePet-0-000009E1B27C", -- [71]
		"BattlePet-0-000009E1B1ED", -- [72]
		"BattlePet-0-00000C929939", -- [73]
		"BattlePet-0-000009E1B18E", -- [74]
		"BattlePet-0-000009E1B280", -- [75]
		"BattlePet-0-00000C77FB92", -- [76]
		"BattlePet-0-00000AB20CD4", -- [77]
		"BattlePet-0-00000C8F9ABA", -- [78]
		"BattlePet-0-000009E1B270", -- [79]
		"BattlePet-0-00000A2FCE43", -- [80]
		"BattlePet-0-000009E1B226", -- [81]
		"BattlePet-0-00000A00E5FE", -- [82]
		"BattlePet-0-00000C7DAEF1", -- [83]
		"BattlePet-0-000009E1B224", -- [84]
		"BattlePet-0-000009E1B27D", -- [85]
		"BattlePet-0-00000A033C69", -- [86]
		"BattlePet-0-000009E1B24F", -- [87]
		"BattlePet-0-000009E1B26A", -- [88]
		"BattlePet-0-00000C78AFFE", -- [89]
		"BattlePet-0-00000C929599", -- [90]
		"BattlePet-0-00000A2FE869", -- [91]
		"BattlePet-0-000009E1B225", -- [92]
		"BattlePet-0-00000C79AA21", -- [93]
		"BattlePet-0-00000C9830D7", -- [94]
		"BattlePet-0-000009E1B216", -- [95]
		"BattlePet-0-000009E1B26B", -- [96]
		"BattlePet-0-000009E1B272", -- [97]
		"BattlePet-0-000009E1B1CA", -- [98]
		"BattlePet-0-00000C923C82", -- [99]
		"BattlePet-0-00000C948A27", -- [100]
		"BattlePet-0-000009E1B250", -- [101]
		"BattlePet-0-00000C933A74", -- [102]
		"BattlePet-0-00000A00E767", -- [103]
		"BattlePet-0-00000C7A87C0", -- [104]
		"BattlePet-0-000009E1B1FB", -- [105]
		"BattlePet-0-000009E1B236", -- [106]
		"BattlePet-0-00000C948A28", -- [107]
		"BattlePet-0-00000C7CA8E5", -- [108]
		"BattlePet-0-000009E1B229", -- [109]
		"BattlePet-0-000009E1B22E", -- [110]
		"BattlePet-0-00000A02E11A", -- [111]
		"BattlePet-0-00000AB20914", -- [112]
		"BattlePet-0-000009E1B279", -- [113]
		"BattlePet-0-000009E1B273", -- [114]
		"BattlePet-0-000009E1B27E", -- [115]
		"BattlePet-0-00000C929959", -- [116]
		"BattlePet-0-00000C93D720", -- [117]
		"BattlePet-0-00000AB20CD5", -- [118]
		"BattlePet-0-000009E1B26D", -- [119]
		"BattlePet-0-000009E1B1DE", -- [120]
		"BattlePet-0-000009E1B1EC", -- [121]
		"BattlePet-0-00000B7A0547", -- [122]
		"BattlePet-0-000009E1B1BB", -- [123]
		"BattlePet-0-000009E1B1D0", -- [124]
		"BattlePet-0-000009E1B1D4", -- [125]
		"BattlePet-0-00000A011B5E", -- [126]
		"BattlePet-0-000009E1B1F8", -- [127]
		"BattlePet-0-00000A2BC102", -- [128]
		"BattlePet-0-00000C923E00", -- [129]
		"BattlePet-0-000009F8B059", -- [130]
		"BattlePet-0-00000C95D045", -- [131]
	},
	["CustomScaleValue"] = 100,
	["loadedTeam"] = 85419,
	["HidePetToast"] = true,
	["FavoriteFilters"] = {
	},
	["Sort"] = {
		["Order"] = 1,
		["FavoritesFirst"] = true,
	},
	["AllowHiddenPetsDefaulted"] = true,
	["BackupCount"] = 189,
	["TeamGroups"] = {
		{
			"General", -- [1]
			"Interface\\Icons\\PetJournalPortrait", -- [2]
		}, -- [1]
	},
	["AutoLoadTargetOnly"] = true,
	["Filters"] = {
		["Other"] = {
		},
		["Expansion"] = {
		},
		["Script"] = {
		},
		["Types"] = {
		},
		["Favorite"] = {
		},
		["Collected"] = {
		},
		["Sources"] = {
		},
		["Similar"] = {
		},
		["Breed"] = {
		},
		["Rarity"] = {
		},
		["Strong"] = {
		},
		["Level"] = {
		},
		["Tough"] = {
		},
		["Moveset"] = {
		},
	},
	["ExpandedOptHeaders"] = {
	},
	["JournalUsed"] = true,
	["JournalPanel"] = 1,
	["SpecialSlots"] = {
		[2] = 0,
		[3] = 0,
	},
	["ExpandedTargetHeaders"] = {
	},
	["PreferredMode"] = 1,
	["ActivePanel"] = 1,
	["Sanctuary"] = {
		["BattlePet-0-000009E1B16E"] = {
			1, -- [1]
			true, -- [2]
			1687, -- [3]
			25, -- [4]
			1441, -- [5]
			292, -- [6]
			268, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B161"] = {
			9, -- [1]
			true, -- [2]
			1211, -- [3]
			25, -- [4]
			1302, -- [5]
			305, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF91"] = {
			2, -- [1]
			true, -- [2]
			1146, -- [3]
			25, -- [4]
			1546, -- [5]
			289, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B000"] = {
			7, -- [1]
			true, -- [2]
			1722, -- [3]
			25, -- [4]
			1400, -- [5]
			341, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF48"] = {
			4, -- [1]
			true, -- [2]
			85, -- [3]
			25, -- [4]
			1627, -- [5]
			244, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B08F"] = {
			1, -- [1]
			true, -- [2]
			2385, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF1B"] = {
			1, -- [1]
			true, -- [2]
			209, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEA2"] = {
			8, -- [1]
			true, -- [2]
			1167, -- [3]
			25, -- [4]
			1400, -- [5]
			305, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0BF"] = {
			1, -- [1]
			true, -- [2]
			2530, -- [3]
			25, -- [4]
			1380, -- [5]
			281, -- [6]
			301, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1ADDF"] = {
			3, -- [1]
			true, -- [2]
			743, -- [3]
			25, -- [4]
			1790, -- [5]
			289, -- [6]
			208, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B10E"] = {
			5, -- [1]
			true, -- [2]
			338, -- [3]
			25, -- [4]
			1627, -- [5]
			273, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD7B"] = {
			2, -- [1]
			true, -- [2]
			319, -- [3]
			25, -- [4]
			1221, -- [5]
			322, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B150"] = {
			1, -- [1]
			true, -- [2]
			289, -- [3]
			25, -- [4]
			1969, -- [5]
			276, -- [6]
			195, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B17D"] = {
			1, -- [1]
			true, -- [2]
			57, -- [3]
			25, -- [4]
			1481, -- [5]
			309, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD64"] = {
			1, -- [1]
			true, -- [2]
			437, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B160"] = {
			8, -- [1]
			true, -- [2]
			2717, -- [3]
			25, -- [4]
			1619, -- [5]
			287, -- [6]
			248, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B125"] = {
			10, -- [1]
			true, -- [2]
			339, -- [3]
			25, -- [4]
			1546, -- [5]
			273, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0AA"] = {
			1, -- [1]
			true, -- [2]
			2466, -- [3]
			25, -- [4]
			1359, -- [5]
			329, -- [6]
			264, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEF5"] = {
			4, -- [1]
			true, -- [2]
			1565, -- [3]
			25, -- [4]
			1546, -- [5]
			289, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE9D"] = {
			3, -- [1]
			true, -- [2]
			116, -- [3]
			25, -- [4]
			1546, -- [5]
			273, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFA5"] = {
			2, -- [1]
			true, -- [2]
			1903, -- [3]
			25, -- [4]
			1969, -- [5]
			276, -- [6]
			0, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B001"] = {
			2, -- [1]
			true, -- [2]
			2134, -- [3]
			25, -- [4]
			1481, -- [5]
			289, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF6E"] = {
			18, -- [1]
			true, -- [2]
			1238, -- [3]
			25, -- [4]
			1562, -- [5]
			292, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD9E"] = {
			2, -- [1]
			true, -- [2]
			489, -- [3]
			25, -- [4]
			1400, -- [5]
			341, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE3F"] = {
			1, -- [1]
			true, -- [2]
			479, -- [3]
			25, -- [4]
			1481, -- [5]
			227, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B13E"] = {
			21, -- [1]
			true, -- [2]
			1387, -- [3]
			25, -- [4]
			1465, -- [5]
			305, -- [6]
			257, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B1CE"] = {
			2, -- [1]
			true, -- [2]
			2833, -- [3]
			25, -- [4]
			1705, -- [5]
			282, -- [6]
			242, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF10"] = {
			1, -- [1]
			true, -- [2]
			1597, -- [3]
			25, -- [4]
			1319, -- [5]
			322, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFAE"] = {
			1, -- [1]
			true, -- [2]
			1753, -- [3]
			25, -- [4]
			1359, -- [5]
			305, -- [6]
			281, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFDB"] = {
			1, -- [1]
			true, -- [2]
			1957, -- [3]
			25, -- [4]
			1644, -- [5]
			276, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B124"] = {
			1, -- [1]
			true, -- [2]
			2648, -- [3]
			25, -- [4]
			1278, -- [5]
			304, -- [6]
			299, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B170"] = {
			1, -- [1]
			true, -- [2]
			848, -- [3]
			25, -- [4]
			1546, -- [5]
			227, -- [6]
			322, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE5A"] = {
			1, -- [1]
			true, -- [2]
			493, -- [3]
			25, -- [4]
			1790, -- [5]
			305, -- [6]
			195, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFBE"] = {
			2, -- [1]
			true, -- [2]
			1777, -- [3]
			25, -- [4]
			1522, -- [5]
			284, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B165"] = {
			1, -- [1]
			true, -- [2]
			2190, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0BA"] = {
			4, -- [1]
			true, -- [2]
			2544, -- [3]
			25, -- [4]
			1461, -- [5]
			293, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["random:6"] = {
			1, -- [1]
		},
		["BattlePet-0-000009E1AF93"] = {
			3, -- [1]
			true, -- [2]
			1721, -- [3]
			25, -- [4]
			1400, -- [5]
			305, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B14C"] = {
			1, -- [1]
			true, -- [2]
			2086, -- [3]
			25, -- [4]
			1465, -- [5]
			273, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B1AD"] = {
			1, -- [1]
			true, -- [2]
			342, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B16C"] = {
			3, -- [1]
			true, -- [2]
			868, -- [3]
			25, -- [4]
			1546, -- [5]
			260, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B15C"] = {
			2, -- [1]
			true, -- [2]
			1349, -- [3]
			25, -- [4]
			1359, -- [5]
			333, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-00000A0B4F37"] = {
			2, -- [1]
			true, -- [2]
			87, -- [3]
			25, -- [4]
			1400, -- [5]
			276, -- [6]
			309, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF82"] = {
			1, -- [1]
			true, -- [2]
			1776, -- [3]
			25, -- [4]
			1790, -- [5]
			305, -- [6]
			195, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF59"] = {
			1, -- [1]
			true, -- [2]
			266, -- [3]
			25, -- [4]
			1481, -- [5]
			305, -- [6]
			257, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF05"] = {
			1, -- [1]
			true, -- [2]
			1450, -- [3]
			25, -- [4]
			1400, -- [5]
			289, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFE2"] = {
			1, -- [1]
			true, -- [2]
			1956, -- [3]
			25, -- [4]
			1627, -- [5]
			273, -- [6]
			257, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0C9"] = {
			5, -- [1]
			true, -- [2]
			2352, -- [3]
			25, -- [4]
			1522, -- [5]
			284, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF99"] = {
			1, -- [1]
			true, -- [2]
			1701, -- [3]
			25, -- [4]
			1465, -- [5]
			257, -- [6]
			305, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B1ED"] = {
			1, -- [1]
			true, -- [2]
			2565, -- [3]
			24, -- [4]
			1289, -- [5]
			238, -- [6]
			335, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B10F"] = {
			1, -- [1]
			true, -- [2]
			2457, -- [3]
			25, -- [4]
			1359, -- [5]
			285, -- [6]
			301, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0B5"] = {
			3, -- [1]
			true, -- [2]
			277, -- [3]
			25, -- [4]
			1546, -- [5]
			257, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD59"] = {
			1, -- [1]
			true, -- [2]
			646, -- [3]
			25, -- [4]
			1465, -- [5]
			273, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE53"] = {
			1, -- [1]
			true, -- [2]
			429, -- [3]
			25, -- [4]
			1644, -- [5]
			276, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["random:2"] = {
			1, -- [1]
		},
		["BattlePet-0-000009E1B149"] = {
			6, -- [1]
			true, -- [2]
			1416, -- [3]
			25, -- [4]
			1546, -- [5]
			289, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF57"] = {
			1, -- [1]
			true, -- [2]
			1586, -- [3]
			25, -- [4]
			1546, -- [5]
			260, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEA1"] = {
			1, -- [1]
			true, -- [2]
			1212, -- [3]
			25, -- [4]
			1237, -- [5]
			276, -- [6]
			341, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF51"] = {
			3, -- [1]
			true, -- [2]
			1351, -- [3]
			25, -- [4]
			1546, -- [5]
			289, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFC3"] = {
			2, -- [1]
			true, -- [2]
			1931, -- [3]
			25, -- [4]
			1319, -- [5]
			305, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE33"] = {
			1, -- [1]
			true, -- [2]
			746, -- [3]
			25, -- [4]
			1806, -- [5]
			292, -- [6]
			211, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE4A"] = {
			1, -- [1]
			true, -- [2]
			756, -- [3]
			25, -- [4]
			1562, -- [5]
			244, -- [6]
			292, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFE6"] = {
			1, -- [1]
			true, -- [2]
			52, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEB6"] = {
			12, -- [1]
			true, -- [2]
			1152, -- [3]
			25, -- [4]
			1644, -- [5]
			276, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B11C"] = {
			1, -- [1]
			true, -- [2]
			1631, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B05D"] = {
			1, -- [1]
			true, -- [2]
			2373, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B077"] = {
			2, -- [1]
			true, -- [2]
			2382, -- [3]
			25, -- [4]
			1766, -- [5]
			268, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEC5"] = {
			2, -- [1]
			true, -- [2]
			1403, -- [3]
			25, -- [4]
			1400, -- [5]
			325, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFC6"] = {
			2, -- [1]
			true, -- [2]
			1227, -- [3]
			25, -- [4]
			1627, -- [5]
			260, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B08E"] = {
			1, -- [1]
			true, -- [2]
			2389, -- [3]
			25, -- [4]
			1546, -- [5]
			289, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1ADDD"] = {
			1, -- [1]
			true, -- [2]
			744, -- [3]
			25, -- [4]
			1627, -- [5]
			240, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFFC"] = {
			1, -- [1]
			true, -- [2]
			1715, -- [3]
			25, -- [4]
			1400, -- [5]
			305, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B13A"] = {
			34, -- [1]
			true, -- [2]
			1532, -- [3]
			25, -- [4]
			1319, -- [5]
			322, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["random:3"] = {
			1, -- [1]
		},
		["BattlePet-0-000009E1B26C"] = {
			1, -- [1]
			true, -- [2]
			3053, -- [3]
			25, -- [4]
			1302, -- [5]
			309, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFAC"] = {
			1, -- [1]
			true, -- [2]
			1890, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE91"] = {
			1, -- [1]
			true, -- [2]
			1161, -- [3]
			25, -- [4]
			1465, -- [5]
			305, -- [6]
			257, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B176"] = {
			10, -- [1]
			true, -- [2]
			844, -- [3]
			25, -- [4]
			1400, -- [5]
			276, -- [6]
			309, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1ADCE"] = {
			1, -- [1]
			true, -- [2]
			509, -- [3]
			25, -- [4]
			1725, -- [5]
			260, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEF8"] = {
			1, -- [1]
			true, -- [2]
			1201, -- [3]
			25, -- [4]
			1302, -- [5]
			305, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B016"] = {
			2, -- [1]
			true, -- [2]
			1934, -- [3]
			25, -- [4]
			1627, -- [5]
			289, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD87"] = {
			1, -- [1]
			true, -- [2]
			456, -- [3]
			25, -- [4]
			1546, -- [5]
			305, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0E5"] = {
			1, -- [1]
			true, -- [2]
			2586, -- [3]
			25, -- [4]
			1664, -- [5]
			248, -- [6]
			284, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B158"] = {
			8, -- [1]
			true, -- [2]
			1320, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFEA"] = {
			1, -- [1]
			true, -- [2]
			1545, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1ADD1"] = {
			1, -- [1]
			true, -- [2]
			471, -- [3]
			25, -- [4]
			1627, -- [5]
			244, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEFE"] = {
			1, -- [1]
			true, -- [2]
			1524, -- [3]
			25, -- [4]
			1546, -- [5]
			260, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD67"] = {
			1, -- [1]
			true, -- [2]
			144, -- [3]
			25, -- [4]
			1384, -- [5]
			257, -- [6]
			322, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B17C"] = {
			1, -- [1]
			true, -- [2]
			1574, -- [3]
			25, -- [4]
			1319, -- [5]
			338, -- [6]
			257, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AED9"] = {
			2, -- [1]
			true, -- [2]
			1396, -- [3]
			25, -- [4]
			1481, -- [5]
			289, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0DB"] = {
			1, -- [1]
			true, -- [2]
			2590, -- [3]
			25, -- [4]
			1262, -- [5]
			310, -- [6]
			293, -- [7]
			4, -- [8]
		},
		["random:10"] = {
			2, -- [1]
		},
		["BattlePet-0-000009E1AE0A"] = {
			1, -- [1]
			true, -- [2]
			383, -- [3]
			25, -- [4]
			1465, -- [5]
			257, -- [6]
			305, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B156"] = {
			1, -- [1]
			true, -- [2]
			119, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B197"] = {
			1, -- [1]
			true, -- [2]
			2063, -- [3]
			25, -- [4]
			1319, -- [5]
			260, -- [6]
			341, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE09"] = {
			1, -- [1]
			true, -- [2]
			514, -- [3]
			25, -- [4]
			1725, -- [5]
			260, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B1F3"] = {
			1, -- [1]
			true, -- [2]
			2199, -- [3]
			25, -- [4]
			1400, -- [5]
			325, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B02B"] = {
			3, -- [1]
			true, -- [2]
			2001, -- [3]
			25, -- [4]
			1562, -- [5]
			284, -- [6]
			252, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF4F"] = {
			2, -- [1]
			true, -- [2]
			1568, -- [3]
			25, -- [4]
			1400, -- [5]
			289, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B1A4"] = {
			2, -- [1]
			true, -- [2]
			1601, -- [3]
			25, -- [4]
			1197, -- [5]
			366, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEFC"] = {
			3, -- [1]
			true, -- [2]
			1567, -- [3]
			25, -- [4]
			1319, -- [5]
			305, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B14A"] = {
			1, -- [1]
			true, -- [2]
			2078, -- [3]
			25, -- [4]
			1887, -- [5]
			260, -- [6]
			227, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF71"] = {
			1, -- [1]
			true, -- [2]
			1714, -- [3]
			25, -- [4]
			1400, -- [5]
			289, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1ADE4"] = {
			1, -- [1]
			true, -- [2]
			753, -- [3]
			25, -- [4]
			1465, -- [5]
			276, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B07A"] = {
			1, -- [1]
			true, -- [2]
			2398, -- [3]
			25, -- [4]
			1339, -- [5]
			248, -- [6]
			349, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B059"] = {
			1, -- [1]
			true, -- [2]
			2386, -- [3]
			25, -- [4]
			1668, -- [5]
			261, -- [6]
			261, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE55"] = {
			3, -- [1]
			true, -- [2]
			1178, -- [3]
			25, -- [4]
			1400, -- [5]
			325, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B075"] = {
			1, -- [1]
			true, -- [2]
			2399, -- [3]
			25, -- [4]
			1278, -- [5]
			272, -- [6]
			337, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF13"] = {
			2, -- [1]
			true, -- [2]
			1145, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD92"] = {
			1, -- [1]
			true, -- [2]
			143, -- [3]
			25, -- [4]
			1400, -- [5]
			292, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF62"] = {
			1, -- [1]
			true, -- [2]
			213, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B134"] = {
			1, -- [1]
			true, -- [2]
			142, -- [3]
			25, -- [4]
			1481, -- [5]
			292, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B084"] = {
			2, -- [1]
			true, -- [2]
			2395, -- [3]
			25, -- [4]
			1319, -- [5]
			349, -- [6]
			252, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B064"] = {
			1, -- [1]
			true, -- [2]
			2383, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFD7"] = {
			2, -- [1]
			true, -- [2]
			1623, -- [3]
			25, -- [4]
			1546, -- [5]
			289, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B162"] = {
			1, -- [1]
			true, -- [2]
			1802, -- [3]
			25, -- [4]
			1546, -- [5]
			273, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF24"] = {
			1, -- [1]
			true, -- [2]
			1660, -- [3]
			25, -- [4]
			1319, -- [5]
			276, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD7E"] = {
			2, -- [1]
			true, -- [2]
			270, -- [3]
			25, -- [4]
			1627, -- [5]
			276, -- [6]
			257, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE44"] = {
			1, -- [1]
			true, -- [2]
			145, -- [3]
			25, -- [4]
			1481, -- [5]
			273, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF7E"] = {
			3, -- [1]
			true, -- [2]
			117, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFBD"] = {
			2, -- [1]
			true, -- [2]
			1976, -- [3]
			25, -- [4]
			1400, -- [5]
			325, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B173"] = {
			1, -- [1]
			true, -- [2]
			1517, -- [3]
			25, -- [4]
			1400, -- [5]
			341, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B167"] = {
			1, -- [1]
			true, -- [2]
			1429, -- [3]
			25, -- [4]
			1725, -- [5]
			260, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD7D"] = {
			1, -- [1]
			true, -- [2]
			1162, -- [3]
			25, -- [4]
			1237, -- [5]
			292, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B090"] = {
			1, -- [1]
			true, -- [2]
			2462, -- [3]
			25, -- [4]
			1359, -- [5]
			272, -- [6]
			321, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0AB"] = {
			1, -- [1]
			true, -- [2]
			2420, -- [3]
			25, -- [4]
			1404, -- [5]
			314, -- [6]
			261, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B1D7"] = {
			2, -- [1]
			true, -- [2]
			2456, -- [3]
			25, -- [4]
			1485, -- [5]
			277, -- [6]
			281, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B169"] = {
			1, -- [1]
			true, -- [2]
			1700, -- [3]
			25, -- [4]
			1384, -- [5]
			305, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFE5"] = {
			1, -- [1]
			true, -- [2]
			1442, -- [3]
			25, -- [4]
			1725, -- [5]
			260, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFAA"] = {
			3, -- [1]
			true, -- [2]
			1977, -- [3]
			25, -- [4]
			1400, -- [5]
			289, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0FC"] = {
			1, -- [1]
			true, -- [2]
			1478, -- [3]
			25, -- [4]
			1546, -- [5]
			289, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEE5"] = {
			1, -- [1]
			true, -- [2]
			1426, -- [3]
			25, -- [4]
			2537, -- [5]
			260, -- [6]
			179, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE31"] = {
			1, -- [1]
			true, -- [2]
			415, -- [3]
			25, -- [4]
			1465, -- [5]
			305, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1ADEF"] = {
			1, -- [1]
			true, -- [2]
			1175, -- [3]
			25, -- [4]
			1546, -- [5]
			273, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B135"] = {
			1, -- [1]
			true, -- [2]
			1180, -- [3]
			25, -- [4]
			1237, -- [5]
			276, -- [6]
			341, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B172"] = {
			1, -- [1]
			true, -- [2]
			2438, -- [3]
			25, -- [4]
			1481, -- [5]
			292, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFD3"] = {
			2, -- [1]
			true, -- [2]
			120, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1ADA2"] = {
			1, -- [1]
			true, -- [2]
			378, -- [3]
			25, -- [4]
			1465, -- [5]
			240, -- [6]
			322, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B01C"] = {
			3, -- [1]
			true, -- [2]
			1149, -- [3]
			25, -- [4]
			1400, -- [5]
			289, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD72"] = {
			1, -- [1]
			true, -- [2]
			464, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B15A"] = {
			1, -- [1]
			true, -- [2]
			175, -- [3]
			25, -- [4]
			1319, -- [5]
			276, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFBF"] = {
			1, -- [1]
			true, -- [2]
			1917, -- [3]
			25, -- [4]
			1481, -- [5]
			292, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B034"] = {
			1, -- [1]
			true, -- [2]
			2057, -- [3]
			25, -- [4]
			1384, -- [5]
			273, -- [6]
			305, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1ADF5"] = {
			2, -- [1]
			true, -- [2]
			538, -- [3]
			25, -- [4]
			1481, -- [5]
			305, -- [6]
			257, -- [7]
			4, -- [8]
		},
		["random:0"] = {
			92, -- [1]
		},
		["BattlePet-0-000009E1ADDE"] = {
			1, -- [1]
			true, -- [2]
			568, -- [3]
			25, -- [4]
			1790, -- [5]
			276, -- [6]
			224, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE1B"] = {
			2, -- [1]
			true, -- [2]
			519, -- [3]
			25, -- [4]
			1627, -- [5]
			289, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEE8"] = {
			1, -- [1]
			true, -- [2]
			1467, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B1F6"] = {
			1, -- [1]
			true, -- [2]
			1338, -- [3]
			25, -- [4]
			1627, -- [5]
			257, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B15F"] = {
			6, -- [1]
			true, -- [2]
			1155, -- [3]
			25, -- [4]
			1725, -- [5]
			276, -- [6]
			244, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0E2"] = {
			1, -- [1]
			true, -- [2]
			2580, -- [3]
			25, -- [4]
			1278, -- [5]
			292, -- [6]
			317, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AF94"] = {
			6, -- [1]
			true, -- [2]
			1974, -- [3]
			25, -- [4]
			1400, -- [5]
			260, -- [6]
			325, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AD91"] = {
			3, -- [1]
			true, -- [2]
			627, -- [3]
			25, -- [4]
			1627, -- [5]
			305, -- [6]
			227, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B1C3"] = {
			1, -- [1]
			true, -- [2]
			2842, -- [3]
			25, -- [4]
			1034, -- [5]
			362, -- [6]
			297, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE77"] = {
			12, -- [1]
			true, -- [2]
			1165, -- [3]
			25, -- [4]
			1400, -- [5]
			305, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["random:8"] = {
			1, -- [1]
		},
		["BattlePet-0-000009E1AE21"] = {
			1, -- [1]
			true, -- [2]
			1182, -- [3]
			25, -- [4]
			1562, -- [5]
			260, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B08A"] = {
			1, -- [1]
			true, -- [2]
			2384, -- [3]
			25, -- [4]
			1359, -- [5]
			309, -- [6]
			284, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFC9"] = {
			9, -- [1]
			true, -- [2]
			1975, -- [3]
			25, -- [4]
			1546, -- [5]
			289, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE9B"] = {
			1, -- [1]
			true, -- [2]
			1540, -- [3]
			25, -- [4]
			1400, -- [5]
			289, -- [6]
			289, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AE24"] = {
			1, -- [1]
			true, -- [2]
			1158, -- [3]
			25, -- [4]
			1546, -- [5]
			273, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B17A"] = {
			2, -- [1]
			true, -- [2]
			2089, -- [3]
			25, -- [4]
			1465, -- [5]
			289, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1B0CD"] = {
			1, -- [1]
			true, -- [2]
			1266, -- [3]
			25, -- [4]
			1400, -- [5]
			333, -- [6]
			252, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AFF3"] = {
			15, -- [1]
			true, -- [2]
			1963, -- [3]
			25, -- [4]
			1481, -- [5]
			276, -- [6]
			276, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AED7"] = {
			1, -- [1]
			true, -- [2]
			1537, -- [3]
			25, -- [4]
			1725, -- [5]
			260, -- [6]
			260, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1ADB4"] = {
			2, -- [1]
			true, -- [2]
			747, -- [3]
			25, -- [4]
			1465, -- [5]
			289, -- [6]
			273, -- [7]
			4, -- [8]
		},
		["BattlePet-0-000009E1AEFB"] = {
			1, -- [1]
			true, -- [2]
			1589, -- [3]
			25, -- [4]
			1400, -- [5]
			289, -- [6]
			289, -- [7]
			4, -- [8]
		},
	},
	["ElvUIToastDefaulted"] = true,
	["CornerPos"] = "BOTTOMLEFT",
	["NoBackupReminder"] = true,
	["QueueSanctuary"] = {
		["BattlePet-0-000009E1B22F"] = "QQQ02Q8",
		["BattlePet-0-00000C948A28"] = "QQQC15N",
		["BattlePet-0-000009E1B1D4"] = "QQQ42OP",
		["BattlePet-0-00000C77F95F"] = "QQQ7320",
		["BattlePet-0-00000C7CA8E5"] = "QQQA15M",
		["BattlePet-0-000009E1B225"] = "QQQA2KL",
		["BattlePet-0-000009E1B1F9"] = "QQQ72BA",
		["BattlePet-0-00000C929599"] = "QQQ62SM",
		["BattlePet-0-000009E1B24D"] = "QQQA2R8",
		["BattlePet-0-000009E1B22D"] = "QQQ42F4",
		["BattlePet-0-000009E1B1FB"] = "QQQ42N9",
		["BattlePet-0-000009E1B21F"] = "QQQ62P1",
		["BattlePet-0-00000A12B407"] = "QQQ52SG",
		["BattlePet-0-00000C79AA21"] = "QQQ52S5",
		["BattlePet-0-00000C939924"] = "QQQ82V3",
		["BattlePet-0-00000A07CFFA"] = "QQQB2VQ",
		["BattlePet-0-000009E1B285"] = "QQQ42RM",
		["BattlePet-0-00000A011B65"] = "QQQ92S3",
		["BattlePet-0-00000AB20914"] = "QQQ9312",
		["BattlePet-0-000009E1B257"] = "QQQ52U0",
		["BattlePet-0-00000C80D76C"] = "QQQ6321",
		["BattlePet-0-00000C77610E"] = "QQQ831C",
		["BattlePet-0-00000C92B638"] = "QQQ818N",
		["BattlePet-0-000009E1B213"] = "QQQ417S",
		["BattlePet-0-000009E1B280"] = "QQQA2QR",
		["BattlePet-0-00000A2FE869"] = "QQQ82UF",
		["BattlePet-0-000009E1B1D6"] = "QQQ72CB",
		["BattlePet-0-000009E1B250"] = "QQQ82R2",
		["BattlePet-0-000009E1B287"] = "QQQA2QU",
		["BattlePet-0-00000C98E791"] = "QQQ82S8",
		["BattlePet-0-00000C93FB01"] = "QQQ52RT",
		["BattlePet-0-00000C9290B3"] = "QQQ431F",
		["BattlePet-0-00000C933A74"] = "QQQ62UB",
		["BattlePet-0-000009E1B271"] = "QQQ92UJ",
		["BattlePet-0-00000A2BC102"] = "QQQB2R3",
		["BattlePet-0-000009F8B059"] = "QQQ82QH",
		["BattlePet-0-00000A02E11A"] = "QQQ42SI",
		["BattlePet-0-000009E1B27C"] = "QQQ42QI",
		["BattlePet-0-00000C9F3FB8"] = "QQQ8316",
		["BattlePet-0-00000C77FB92"] = "QQQ631T",
		["BattlePet-0-00000AB0B6E1"] = "QQQ731H",
		["BattlePet-0-000009E1B279"] = "QQQ82UQ",
		["BattlePet-0-000009E1B1ED"] = "QQQ52G5",
		["BattlePet-0-000009E1B261"] = "QQQ82RG",
		["BattlePet-0-00000C9121B6"] = "QQQ731D",
		["BattlePet-0-000009E1B282"] = "QQQ42Q9",
		["BattlePet-0-00000C954FC3"] = "QQQ82SK",
		["BattlePet-0-000009E1B275"] = "QQQ72UP",
		["BattlePet-0-000009E1B1F8"] = "QQQ82PM",
		["BattlePet-0-00000C7A87C0"] = "QQQ62U4",
		["BattlePet-0-00000A00E5FE"] = "QQQ02KG",
		["BattlePet-0-00000AB20CD4"] = "QQQ7310",
		["BattlePet-0-000009E1B26D"] = "QQQ32UU",
		["BattlePet-0-000009E1B269"] = "QQQ32R6",
		["BattlePet-0-000009E1B24F"] = "QQQ52UE",
		["BattlePet-0-000009E1B224"] = "QQQ72KD",
		["BattlePet-0-000009E1B1BB"] = "QQQ42OO",
		["BattlePet-0-00000C923C82"] = "QQQ82VR",
		["BattlePet-0-00000B7A0547"] = "QQQ82QO",
		["BattlePet-0-000009E1B27D"] = "QQQA2UK",
		["BattlePet-0-00000C8F9ABA"] = "QQQ62V2",
		["BattlePet-0-000009E1B1D0"] = "QQQ82ND",
		["BattlePet-0-00000C79653A"] = "QQQ931R",
		["BattlePet-0-00000C788A81"] = "QQQA2SJ",
		["BattlePet-0-00000C91D906"] = "QQQ62SN",
		["BattlePet-0-000009E1B236"] = "QQQB2BJ",
		["BattlePet-0-00000C77610F"] = "QQQ430R",
		["BattlePet-0-00000C928FA1"] = "QQQ831B",
		["BattlePet-0-000009E1B1C9"] = "QQQ82OG",
		["BattlePet-0-00000A2BC101"] = "QQQB2R5",
		["BattlePet-0-000009E1B226"] = "QQQ32JT",
		["BattlePet-0-000009E1B229"] = "QQQ315P",
		["BattlePet-0-000009E1B283"] = "QQQ32SF",
		["BattlePet-0-000009E1B1E4"] = "QQQ82OJ",
		["BattlePet-0-000009E1B268"] = "QQQ52HU",
		["BattlePet-0-00000C8FBD54"] = "QQQ6324",
		["BattlePet-0-000009E1B26A"] = "QQQ32S9",
		["BattlePet-0-00000C95D045"] = "QQQ818P",
		["BattlePet-0-00000C929728"] = "QQQ72U9",
		["BattlePet-0-000009E1B24C"] = "QQQ42R9",
		["BattlePet-0-000009E1B25D"] = "QQQ42S0",
		["BattlePet-0-00000C94E699"] = "QQQ032H",
		["BattlePet-0-00000C778DF1"] = "QQQ431I",
		["BattlePet-0-00000BA8EA08"] = "QQQ92SA",
		["BattlePet-0-000009E1B278"] = "QQQA2UO",
		["BattlePet-0-00000C78AFFE"] = "QQQ32U2",
		["BattlePet-0-000009E1B232"] = "QQQ72LR",
		["BattlePet-0-000009E1B216"] = "QQQ91T1",
		["BattlePet-0-000009E1B26B"] = "QQQ42V4",
		["BattlePet-0-000009E1B273"] = "QQQ72UI",
		["BattlePet-0-00000C927779"] = "QQQ8221",
		["BattlePet-0-000009E1B276"] = "QQQ92R4",
		["BattlePet-0-00000C923E00"] = "QQQ8307",
		["BattlePet-0-00000C77F960"] = "QQQC31Q",
		["BattlePet-0-000009E1B230"] = "QQQ82NB",
		["BattlePet-0-00000C92F876"] = "QQQ931J",
		["BattlePet-0-00000A033C69"] = "QQQ02V0",
		["BattlePet-0-00000BE75719"] = "QQQ730Q",
		["BattlePet-0-000009E1B258"] = "QQQ32RN",
		["BattlePet-0-00000A011B5E"] = "QQQ52CS",
		["BattlePet-0-00000A2EB5B6"] = "QQQB2R1",
		["BattlePet-0-000009E1B1EC"] = "QQQ324G",
		["BattlePet-0-000009E1B1DE"] = "QQQA2KS",
		["BattlePet-0-000009E1B22E"] = "QQQ42PL",
		["BattlePet-0-00000C93D720"] = "QQQ71I5",
		["BattlePet-0-00000C929959"] = "QQQ62UA",
		["BattlePet-0-000009E1B27E"] = "QQQ92QL",
		["BattlePet-0-000009E1B18E"] = "QQQB2MO",
		["BattlePet-0-000009E1B217"] = "QQQB178",
		["BattlePet-0-000009E1B1F7"] = "QQQ62DA",
		["BattlePet-0-000009E1B1FE"] = "QQQ32BG",
		["BattlePet-0-00000C9443DB"] = "QQQ82S4",
		["BattlePet-0-00000A01BCFF"] = "QQQ82VO",
		["BattlePet-0-00000C9BDBEF"] = "QQQ54I",
		["BattlePet-0-000009E1B218"] = "QQQ62CC",
		["BattlePet-0-000009E1B281"] = "QQQA2UR",
		["BattlePet-0-00000C948A26"] = "QQQ4229",
		["BattlePet-0-00000AB20CD5"] = "QQQ3311",
		["BattlePet-0-00000C7DAEF1"] = "QQQA1D8",
		["BattlePet-0-000009E1B272"] = "QQQ82RU",
		["BattlePet-0-00000A0B4F3E"] = "QQQ52RB",
		["BattlePet-0-000009E1B18B"] = "QQQ32JQ",
		["BattlePet-0-00000C948A27"] = "QQQ930K",
		["BattlePet-0-000009E1B1CA"] = "QQQ62M1",
		["BattlePet-0-00000C9830D7"] = "QQQ830T",
		["BattlePet-0-00000A00E767"] = "QQQ62TU",
		["BattlePet-0-00000A2FCE43"] = "QQQ82RL",
		["BattlePet-0-00000C929939"] = "QQQ72PU",
		["BattlePet-0-000009E1B266"] = "QQQ42RD",
		["BattlePet-0-000009E1B270"] = "QQQ92UC",
		["BattlePet-0-000009E1B26E"] = "QQQ92S2",
	},
	["YPos"] = 246.5714416503906,
	["SelectedTab"] = 1,
	["PetNotes"] = {
	},
}
