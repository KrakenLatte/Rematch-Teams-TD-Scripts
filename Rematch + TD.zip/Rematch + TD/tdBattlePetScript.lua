
TD_DB_BATTLEPETSCRIPT_GLOBAL = {
	["global"] = {
		["version"] = 99999.99,
		["scripts"] = {
			["AllInOne"] = {
			},
			["FirstEnemy"] = {
			},
			["Base"] = {
			},
			["Rematch"] = {
				[150922] = {
					["name"] = "Sludge Belcher",
					["code"] = "ability(Corpse Explosion:663) [!enemy.aura(Corpse Explosion:664).exists]\nability(Toxic Skin:1087) [!self.aura(Toxic Skin:1086).exists]\nability(#1)\nchange(next)",
				},
				[116788] = {
					["name"] = "Deviate Chomper",
					["code"] = "ability(Evanescence:440)\nability(Forboding Curse:1068) [!enemy.aura(Forboding Curse:1067).exists]\nability(#1)\nchange(next)",
				},
				[162461] = {
					["name"] = "I Am The One Who Whispers",
					["code"] = "use(Flock:581) [ enemy.aura(Black Claw:918).exists ]\nuse(Black Claw:919)\nuse(Scorched Earth:172)\nuse(Breath:115)\nchange(next)",
				},
				[173267] = {
					["name"] = "Uncomfortably Undercover",
					["code"] = "standby [enemy.aura(Undead:242).exists]\nability(Wind-Up:459) [self.aura(Supercharged:207).exists]\nability(Supercharge:208) [self.aura(Wind-Up:458).exists]\nability(Wind-Up:459)\nchange(Iron Starlette:1387) [enemy(Trailblazer:2988).active]\n\nability(Surge of Power:593) [enemy.aura(Howl:1725).exists]\nability(Howl:362)\nchange(Chrominius:1152) [enemy(Stinkdust:2987).active]\n\n\nability(Flock:581) [enemy.aura(Black Claw:918).exists]\nability(Black Claw:919)",
				},
				[173331] = {
					["name"] = "The Mind Games of Addius",
					["code"] = "ability(Decoy:334)\nability(Explode:282)\nability(Supercharge:208) [self.aura(Wind-Up:458).exists]\nability(Toxic Smoke:640) [self.round>3]\nability(#1)\nchange(next)",
				},
				[150923] = {
					["name"] = "Belchling",
					["code"] = "ability(Dodge:312) [enemy.aura(Undead:242).exists]\nability(Great Sting:1966)\nability(Cleave:1273)\nability(Flurry:360)\nchange(next)",
				},
				[72291] = {
					["name"] = "Yu'la, Broodling of Yu'lon",
					["code"] = "use(Phase Shift:764) [enemy.aura(Flying:341).exists]\nuse(Ashes of Outland:2396) [enemy.aura(Emerald Presence:823).duration=2]\nuse(Nether Blast:608)",
				},
				[68562] = {
					["name"] = "Ti'un the Wanderer",
					["code"] = "ability(Black Claw:919) [round=1]\nability(#3) [!self(#1).dead & enemy.aura(Black Claw:918).exists] \nability(#1) [enemy.hp>560] \nchange(#3) [self(#1).dead] \nability(Explode:282) [enemy.hp<560 & !self(#3).dead] \nstandby [enemy.hp<560 & !self(#1).dead]",
				},
				[116789] = {
					["name"] = "Son of Skum",
					["code"] = "ability(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nability(#1) [enemy.aura(Shattered Defenses:542).exists]\nability(Flock:581)\nability(Mana Surge:489)\nability(#1)\nchange(next)",
				},
				[99210] = {
					["name"] = "Fight Night: Bodhi Sunwayver",
					["code"] = "if [enemy(#1).active]\n ability(Soulrush:752) [enemy.round=1]\n ability(Soulrush:752) [enemy.hp<=579 & enemy(#2).dead]\n ability(Magic Sword:1085)\nendif\n\nif [enemy(#2).active]\n   ability(Clean-Up:456)\n   ability(Soulrush:752) [enemy.hp<=868]\n   ability(Magic Sword:1085)\nchange(#2) [self(#1).dead]\n   ability(Breath:115)\nendif\n\nability(Magic Sword:1085) [enemy.hp>492]\nstandby [self(#1).active]\nchange(#2)\nability(Explode:282) [enemy(#3).hp.can_explode]\nability(Thunderbolt:779) [enemy.hp>798 & enemy(#3).active]\nability(Breath:115)",
				},
				[150925] = {
					["name"] = "Liz the Tormentor",
					["code"] = "use(Curse of Doom:218)\nuse(Scorched Earth:172)\nuse(Shadowflame:393)\nuse(Tail Sweep:122)\nchange(next)",
				},
				[142096] = {
					["name"] = "Critters are Friends, Not Food",
					["code"] = "ability(Void Nova:2356)\nability(Poison Protocol:1954)\nability(Soulrush:752) [enemy(#2).active]\nability(Moonfire:595) [enemy(#3).active]\nability(#1)\nchange(next)",
				},
				[66730] = {
					["name"] = "Hyuna of the Shrines",
					["code"] = "standby [self.aura(Stunned:927).exists & self(#3).played]\nchange(#3) [!self(#3).played & !enemy.ability(#2).usable & enemy(#3).active]\nchange(#2) [self(#3).played]\nability(Toxic Skin:1087) [round=1]\nability(Healing Flame:168) [enemy(#2).active & enemy.round=2]\nability(Black Claw:919) [enemy(#3).active & enemy.hpp>75 & !enemy.aura(Black Claw:918).exists & enemy.round>1]\nability(Flock:581) [enemy.aura(Black Claw:918).exists]\nability(#1)\nchange(next)",
				},
				[154910] = {
					["name"] = "Prince Wiggletail",
					["code"] = "ability(Shadow Shock:422) [round=1]\nability(Curse of Doom:218)\nability(Haunt:652)\nability(#1) [enemy.aura(Shattered Defenses:542).exists]\nability(Flock:581)\nchange(next)",
				},
				[141969] = {
					["name"] = "What Do You Mean, Mind Controlling Plants?",
					["code"] = "use(Curse of Doom:218)\nuse(Haunt:652)\nchange(#2) [self(#1).dead & !self(#2).active]\nuse(Black Claw:919) [round=3]\nuse(Black Claw:919) [round=9]\nstandby [self.aura(Stunned).duration>=1]\nuse(Savage Talon:518) [enemy.aura(Shattered Defenses:542).exists]\nuse(Flock:581)\nuse(Arcane Storm:589)\nchange(#3) [self(#2).dead & !self(#3).active]\nuse(Falcosaur Swarm!:1773)",
				},
				[116790] = {
					["name"] = "Vilefang",
					["code"] = "ability(Ironskin:1758)\nability(Predatory Strike:518) [enemy.aura(Shattered Defenses:542).exists]\nability(#1)\nchange(next)",
				},
				[162465] = {
					["name"] = "Dune Buggy",
					["code"] = "ability(Blistering Cold:786) [round=1]\nability(BONESTORM:1762) [round>2]\nability(Chop:943)\nability(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nability(Hunting Party:921)\nchange(next)",
				},
				[141077] = {
					["name"] = "Not So Bad Down Here",
					["code"] = "use(Supercharge:208) [ enemy(#3).hp>988 ]\nuse(Explode:282) [ enemy(#2).hp.can_explode ]\nuse(Wind-Up:459) [ !enemy(#1).active & enemy(#2).hp>1004 ]\nuse(Drill Charge:1921)\nuse(Arcane Storm:589) [ round=2 ]\nuse(Call Lightning:204)\nuse(Tail Sweep:122)\nchange(#2)",
				},
				[154911] = {
					["name"] = "Chomp",
					["code"] = "ability(Curse of Doom:218)\nability(Haunt:652)\nability(Inflation:1002)\nchange(next)",
				},
				[66635] = {
					["name"] = "Beegle Blastfuse",
					["code"] = "use(Arcane Storm:589)\nuse(Mana Surge:489)\nuse(Tail Sweep:122)\nchange(Anubis:1155) [self(Nexus Whelpling:1165).dead]\nuse(Sandstorm:453)\nuse(Crush:406)",
				},
				[162466] = {
					["name"] = "Watch Where You Step",
					["code"] = "ability(Curse of Doom:218)\nability(Inflation:1002) [enemy.aura(Shattered Defenses:542).duration<2]\nability(#1) [self(#3).active]\nability(#3)\nchange(next)",
				},
				[141588] = {
					["name"] = "Crawg in the Bog",
					["code"] = "standby [ round=1 ]\nchange(#2)\nuse(Powerball:566) [ round=4 & self.power<341 ]\nuse(Supercharge:208) [ self.aura(Wind-Up:458).exists ]\nuse(Wind-Up:459)",
				},
				[154912] = {
					["name"] = "Silence",
					["code"] = "quit [ round<4 & self(#1).dead & !enemy.aura(Shattered Defenses:542).exists ]\ntest(\"Please finish the fight with standard attacks.\") [ self(#3).active ]\nuse(Black Claw:919) [ round=1 ]\nuse(Swarm:706)\nuse(Flock:581)\nuse(Arcane Storm:589)\nuse(Mana Surge:489)\nchange(#2)",
				},
				[68564] = {
					["name"] = "Dos-Ryga",
					["code"] = "change(#1) [self(#2).active & self.dead]\nchange(#2) [round=2]\nuse(Supercharge:208) [self.aura(Wind-Up:458).exists]\nuse(Wind-Up:459)\nuse(Howl:362) [self.aura(Undead:242).exists]\nuse(Diseased Bite:499)",
				},
				["Fight Night: Bodhi 3"] = {
					["name"] = "Fight Night: Bodhi 3",
					["code"] = "quit [ self.level<25  & round=1 ] \nstandby [self(#1).active & enemy(#3).hp<=560] \nchange(next) [ self.dead ] \nuse(Consume Magic:1231) [enemy.ability(Cyclone:190).usable]\nuse(Explode:282) [enemy(#3).hp.can_explode]\nability(#1)",
				},
				[119341] = {
					["name"] = "Mining Monkey",
					["code"] = "change(next) [self.dead]\nuse(Wind-Up:459) [enemy(#1).active]\nuse(Batter:455)\nuse(Moth Dust:508)\nuse(Cocoon Strike:506)\nuse(Slicing Wind:420)\nstandby",
				},
				[71927] = {
					["name"] = "Chen Stormstout",
					["code"] = "change(#2) [ self(#1).dead ]\nuse(204)\nuse(209)\nuse(124)\nuse(426) [ enemy(#3).active & !self.aura(425).exists ]\nuse(564) [ !self.aura(1009).exists ]\nuse(779) [ !self.aura(1009).exists ]\nuse(#1)\nstandby",
				},
				[94638] = {
					["name"] = "Chaos Pup",
					["code"] = "use(Metal Fist:384) [round == 1]\nuse(Reflective Shield:1105)\nuse(Ion Cannon:209)\nuse(Metal Fist:384)\n\nchange(Anubisath Idol:1155)\nuse(Sandstorm:453)\nuse(Crush:406)",
				},
				[154913] = {
					["name"] = "Shadowspike Lurker",
					["code"] = "use(claw:919) [ round=1 ]\nuse(flock:581)\nuse(pred:518)\nchange(next)",
				},
				[66636] = {
					["name"] = "Nearly Headless Jacob",
					["code"] = "change(#3) [self(#1).dead & !self(#3).played]\nchange(#2) [self(#3).active]\nstandby [self(#2).active & enemy(#3).aura(Undead:242).exists]\nuse(Cleansing Rain:230) [weather(Darkness:257)]\nuse(Bubble:934) [self(#1).hpp=100]\nuse(Swarm of Flies:232) [enemy.aura(Undead:242).exists]\nuse(Swarm of Flies:232) [!enemy.aura(Swarm of Flies:231).exists]\nuse(Tongue Lash:228)",
				},
				[150929] = {
					["name"] = "Nefarious Terry",
					["code"] = "standby [enemy.aura(Undead:242).exists]\nability(Whirlpool:513) [round=1]\nability(Scratch:119) [enemy.aura(Shattered Defenses:542).exists]\nability(Stampede:163)\nability(#1)\nchange(next)",
				},
				[79179] = {
					["name"] = "Super Squirt 2",
					["code"] = "ability(Sweep:457) [ round=1 ]\nchange(next) [ !self(#3).active & !self(#3).played ]\nability(Wind-Up:459) [ enemy(#3).active ]\nability(#1)\nability(#2)\nability(#3)\nchange(#1)",
				},
				[162468] = {
					["name"] = "Tiny Madness",
					["code"] = "standby [round=2]\nability(Curse of Doom:218) [round=3]\nability(Haunt:652) [round=4]\nability(Dead Man's Party:1093) [!enemy.aura(Shattered Defenses:542).exists]\nability(#1)\nchange(next)",
				},
				[140315] = {
					["name"] = "Automated Chaos",
					["code"] = "standby [enemy(\"Fixed\" Remote Control Rocket Chicken:2204).active]\nability(Call Blizzard:206)\nability(Deep Freeze:481) [enemy.hp>=444]\nability(#1)\nchange(next)",
				},
				[169417] = {
					["name"] = "Trainer Grrglin",
					["code"] = "ability(Savage Talon:1370) [enemy.round>4]\nability(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nability(Puppy Parade:1681) [!enemy.aura(Shattered Defenses:542).exists]\nability(Flock:581)\nability(Superbark:1357) [enemy.hp>661]\nability(#1)\nchange(next)",
				},
				[154914] = {
					["name"] = "Pearlhusk Crawler",
					["code"] = "use(919) [ round = 1 ]\nuse(581)\nchange(#2)\nuse(282)",
				},
				[141941] = {
					["name"] = "Baa'l",
					["code"] = "use(Haunt:652) \nuse(Black Claw:919) \nuse(Moonfire:595) \nuse(#1) \nchange(#2)",
				},
				[68565] = {
					["name"] = "Nitun",
					["code"] = "use(Curse of Doom:218)\nuse(Haunt:652)\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Flock:581)\nchange(next)",
				},
				[66557] = {
					["name"] = "Bloodknight Antari",
					["code"] = "if [!enemy(#1).dead]\nuse(#3)\nuse(#1)\nendif\n\nif [!enemy(#2).dead & enemy(#1).dead]\nchange(#2) \nuse(Dive:564)\nuse(Shell Shield:310) [!self(#2).aura(Shell Shield:309).exists]\nuse(Absorb:449)\nendif\n\nif [enemy(#3).active]\nchange(#3) [self(#2).active & enemy(#3).hp>1347]\nchange(#1) [self(#3).active]\nuse(#3) [self(#1).active]\nuse(#2) [self(#1).active]\nuse(#1) [self(#1).active]\nchange(#2) [self(#1).dead]\nuse(Dive:564)\nuse(Shell Shield:310) [!self(#2).aura(Shell Shield:309).exists]\nuse(Absorb:449)\nendif",
				},
				[162469] = {
					["name"] = "Brain Tickling",
					["code"] = "change(#3) [self(#2).dead]\n\nuse(Blistering Cold:786)\nuse(Chop:943)\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Flock:581)\nuse(#1)",
				},
				[94639] = {
					["name"] = "Cursed Spirit",
					["code"] = "quit [self(#1).active & self.speed.slow & enemy(#1).active & enemy(#2).dead & !enemy(#3).dead]\n\nquit [self(#1).active & self.speed.slow & enemy(#1).active & !enemy(#2).dead & enemy(#3).dead]\n\nquit [self(#1).active & enemy(#1).active & !self(#1).ability(#3).usable]\n\nuse(#3) [self(#1).active & enemy(#1).active]\nuse(#1) [round=2]\n\n-- Turn 3 heal ?\nif [round=3]\nuse(#2) [enemy.aura(Flying:341).exists]\nuse(#2) [enemy.aura(Underground:340).exists]\nuse(#2) [enemy.aura(Underwater:830).exists]\nuse(#2) [enemy.aura(Dodge:311).exists]\nuse(#2) [enemy.aura(Silk Cocoon:505).exists]\nuse(#2) [self.ability(#1).strong]\nuse(#2) [self.hpp<50]\nuse(#1) [enemy.hp>390]\nuse(#2)\nstandby\nendif\n-- end heal turn\n\n\nif [self(#1).active & !enemy(#2).dead & !enemy(#3).dead]\nuse(#1) [self.ability(#3).duration<=1 & self.hpp>50]\nuse(#2)\nif [self.ability(#1).strong]\nuse(#1) [enemy.hp>585]\nstandby\nendif\nuse(#1) [enemy.hp>390]\nstandby\nendif\n\nif [self(#1).active & enemy(#2).dead & !enemy(#3).dead]\nchange(#2) [enemy.hpp<50]\nstandby [enemy.hpp<50]\nuse(#1)\nendif\n\nif [self(#1).active & !enemy(#2).dead & enemy(#3).dead]\nchange(#2) [enemy.hpp<50]\nstandby [enemy.hpp<50]\nuse(#1)\nendif\n\nchange(#3) [self(#2).dead]\nuse(#3) [self(#2).active & enemy(#1).active]\nuse(#2)\nuse(#1)\nstandby\nchange(next)",
				},
				[154915] = {
					["name"] = "Elderspawn of Nalaada",
					["code"] = "ability(#1) [enemy.aura(Shattered Defenses:542).exists]\nability(#2) [self.round=1]\nability(#3)\nchange(next)",
				},
				[162470] = {
					["name"] = "Living Statues Are Tough",
					["code"] = "ability(Curse of Doom:218) \nability(Haunt:652) \nability(Dead Man's Party:1093) [!enemy.aura(Shattered Defenses:542).exists]\nability(#1)\nchange(next)",
				},
				[160207] = {
					["name"] = "Therin Skysong",
					["code"] = "if [self(#1).active]\n  use(Disruption:1123) [round=1]\n  use(Life Exchange:277) [enemy.hp>=700]\n  change(#2) [enemy(#1).active]\n  use(Seethe:1056)\nendif\n\nif [self(#2).active]\n  use(Howling Blast:120) [weather(Blizzard:205)]\n  use(Call Blizzard:206)\n  use(Snowball:477)\nendif\n\nif [self(#3).active]\n  use(Burn:113) [enemy.hp<=186 & enemy.aura(Mechanical:244).exists]\n  use(Conflagrate:179) [enemy.hp<=333 & enemy.aura(Mechanical:244).exists]\n  use(Conflagrate:179) [weather(Blizzard:205) & enemy.aura(Mechanical:244).exists]\n  use(Conflagrate:179) [enemy(#2).active & enemy.aura(Immolate:177).exists]\n  use(Immolate:178) [!enemy.aura(Immolate:177).exists]\n  use(Burn:113)\nendif\n\nuse(#1)\nchange(next)",
				},
				[141879] = {
					["name"] = "Keeyo's Champions of Vol'dun",
					["code"] = "standby [enemy.aura(Dodge:2060).exists]\nability(Moonfire:595) [round=1]\nability(Life Exchange:277) [enemy.round=1]\nability(Powerball:566) [enemy(Tikka:2346).active]\nability(Powerball:566) [enemy(Milo:2347).hpp<20]\nability(Supercharge:208) [self.aura(Wind-Up:458).exists]\nability(#1)\nchange(next)",
				},
				[154916] = {
					["name"] = "Ravenous Scalespawn",
					["code"] = "use(blackclaw:919) [ round=1 ] \nuse(flock:581) \nuse(strike:504) \nchange(next)",
				},
				[68566] = {
					["name"] = "Skitterer Xi'a",
					["code"] = "ability(Primal Cry:920)\nability(Black Claw:919) [!enemy(Skitterer Xi'a:1195).aura(Black Claw:918).exists]\nability(Hunting Party:921)\nchange(#2) [self(#1).dead]\nability(Flock:581)",
				},
				[173372] = {
					["name"] = "Natural Defenders",
					["code"] = "use(Surge of Power:593) [enemy.hp<1111]\nuse(Tail Sweep:122) [round=1]\nuse(Arcane Storm:589) [round=2]\nuse(Mana Surge:489)\nuse(Wind-Up:459) [!enemy(#2).active]\nuse(Supercharge:208)\nuse(Call Lightning:204)\nuse(Howl:362)\nuse(Surge of Power:593)\nchange(next)",
				},
				[141529] = {
					["name"] = "Marshdwellers",
					["code"] = "use(Predatory Strike) [enemy.aura(Shattered Defenses:542).exists]\nuse(Falcosaur Swarm!)\nchange(#2)\nuse(Arcane Storm)\nuse(Mana Surge)\nuse(Tail Sweep)\nchange(#3)",
				},
				[162471] = {
					["name"] = "Flight of the Vil'thik",
					["code"] = "use(Toxic Skin:1087) [ !self.aura(Toxic Skin:1086).exists ]\nuse(Emerald Dream:598)\nuse(#1)\nchange(#2)",
				},
				[94640] = {
					["name"] = "Felfly",
					["code"] = "use(Howl:362) [round=1]\nuse(Surge of Power:593) [round=2]\n\nif [self(#2).ability(Unholy Ascension:321).usable]\nchange(#2)\nuse(Unholy Ascension:321) [self(#2).active]\nendif\n\nuse(Deflection:490) [enemy.aura(Flying:341).exists]\nuse(Deflection:490) [enemy.aura(Underground:340).exists]\nuse(Deflection:490) [enemy.aura(Underwater:830).exists]\nuse(Sandstorm:453)\nuse(Spiritfire Bolt:1066)\nuse(#1)\nstandby\nchange(next)",
				},
				[154917] = {
					["name"] = "Mindshackle",
					["code"] = "use(Blistering Cold:786) [ round~1,4 ]\nuse(BONESTORM:1762) [ round=3 ]\nuse(Chop:943)\nuse(Black Claw:919) [ self.round=1 ]\nuse(Hunting Party:921)\nuse(Flock:581)\nuse(Swarm:706)\nchange(next)\nstandby",
				},
				[66638] = {
					["name"] = "Okrut Dragonwaste",
					["code"] = "use(Deflection:490) [enemy.aura(Flying:341).exists] \nuse(Deflection:490) [self.aura(Ice Tomb:623).duration=1] \nuse(Stoneskin:436) [self.aura(Stoneskin:435).duration<2] \nuse(Crush:406) \nchange(#3) [self(#1).dead &!self(#3).played] \nchange(#2) [self(#3).played] \nuse(Dodge:312) \nstandby [enemy.aura(Undead:242).exists] \nuse(Flurry:360)",
				},
				[72009] = {
					["name"] = "Xu-Fu, Cub of Xuen",
					["code"] = "use(Call Lightning:204) [round=1]\nchange(#2) [round = 2]\nuse(Make it Rain:985)\nuse(Inflation:1002)\nchange(#3) [self(#2).dead & self(#1).played]\nuse(Shock and Awe:646)\nuse(Ion Cannon:209)",
				},
				[160209] = {
					["name"] = "Horu Cloudwatcher",
					["code"] = "ability(Dead Man's Party:1093) [!enemy.aura(Shattered Defenses:542).exists]\nability(Interrupting Jolt:938) \nability(Toxic Smoke:640) [enemy.aura(Toxic Smoke:639).duration<2]\nability(Ion Cannon:209) [enemy.hp<550]\nability(Shock and Awe:646)\nability(#1)\nchange(next)",
				},
				["Mo'ruk"] = {
					["name"] = "Mo'ruk",
					["code"] = "if [enemy(#1).active]\nability(334) [self.round=2]\nability(777)\nendif\n\nif [enemy(#2).active]\nchange(#2)\nstandby [self.aura(Stunned).exists]\nability(299) [self.round=1]\nability(362)\nability(593)\nendif\n\nif [enemy(#3).active]\nchange(#1)\nability(282) [enemy.hp < 618]\nability(334) [self.round=3]\nability(777)\nendif",
				},
				[154918] = {
					["name"] = "Kelpstone",
					["code"] = "use(Blistering Cold:786) [ round=1 ]\nuse(Chop:943) [ round=2 ]\nuse(BONESTORM:1762) [ round=3 ]\nuse(Black Claw:919) [ !enemy.aura(Black Claw:918).exists ]\nuse(Exposed Wounds:305) [ !enemy.aura(Exposed Wounds:306).exists ]\nuse(Hunting Party:921)\nuse(Flock:581)\nuse(Swarm:706)\nchange(next)",
				},
				[141945] = {
					["name"] = "Snakes on a Terrace",
					["code"] = "standby [round=1]\nchange(#3)\nability(Great Sting:1966) [self.round<=6]\nability(Cleave:1273)",
				},
				[119344] = {
					["name"] = "Klutz's Battle Bird",
					["code"] = "ability(589)\nability(489)\nability(122)\nchange(#2)\nability(597) [ self.aura(823).duration < 2 & self.speed.slow ]\nability(597) [ !self.aura(823).exists ]\nability(598) [ self.hpp < 50 ]\nability(525)",
				},
				[71930] = {
					["name"] = "Shademaster Kiryn",
					["code"] = "change(#2) [ self(#1).dead & enemy(#1).active ]\nchange(#3) [ enemy(#3).active ]\nuse(624) [ round=1 ]\nuse(206) [ round=6 ]\nuse(413)\nuse(654) [ self.power=276 & enemy.hp<=888 ]\nuse(654) [ self.power=289 & enemy.hp<=927 ]\nuse(654) [ self.power=292 & enemy.hp<=936 ]\nuse(654) [ self.power=305 & enemy.hp<=975 ]\nuse(117)\nuse(389) [ self.speed.slow ]\nuse(646)\nuse(209)",
				},
				[94641] = {
					["name"] = "Tainted Maulclaw",
					["code"] = "use(Wind Buffet:1963) [round=1]\nchange(#3) [round=2]\nuse(Apocalypse:519) [round=3]\nuse(Cauterize:173) [self(#3).hpp<80]\nchange(#2)\n\nif [enemy(#2).dead & enemy(#3).dead]\nuse(Cocoon Strike:506)\nuse(Cauterize:173)\nstandby\nendif\n\nif [enemy(#2).hpp<100 & enemy(#3).active]\nif [enemy.aura(Apocalypse:682).duration>4]\nuse(Wild Winds:514) [enemy.hpp>40 & !self.ability(#1).strong]\nuse(Peck:112) [enemy.hpp>40  & !self.ability(#1).strong]\nuse(Wild Winds:514) [enemy.hpp>55 & self.ability(#1).strong]\nuse(Peck:112) [enemy.hpp>55  & self.ability(#1).strong]\nuse(Burn:113) [enemy.hpp>40]\nuse(Cocoon Strike:506)\nuse(Cauterize:173)\nstandby\nendif\nuse(Wild Winds:514)\nuse(Peck:112)\nuse(Burn:113)\nendif\n\nif [enemy(#3).hpp<100 & enemy(#2).active]\nif [enemy.aura(Apocalypse:682).duration>4]\nuse(Wild Winds:514) [enemy.hpp>40 & !self.ability(#1).strong]\nuse(Peck:112) [enemy.hpp>40  & !self.ability(#1).strong]\nuse(Wild Winds:514) [enemy.hpp>55 & self.ability(#1).strong]\nuse(Peck:112) [enemy.hpp>55  & self.ability(#1).strong]\nuse(Burn:113) [enemy.hpp>40]\nuse(Cocoon Strike:506)\nuse(Cauterize:173)\nstandby\nendif\nuse(Wild Winds:514)\nuse(Peck:112)\nuse(Burn:113)\nendif\n\nif [self(#2).active]\n--\nuse(Wild Winds:514) [enemy.hpp>50 & enemy.aura(Shell Shield:309).exists]\n\nuse(Wild Winds:514) [enemy.hpp>70 & enemy.hp>490]\nuse(Wild Winds:514) [enemy.hpp>65 & enemy.hp>520]\nuse(Wild Winds:514) [enemy.hpp>60 & enemy.hp>540]\nuse(Wild Winds:514) [enemy.hpp>55 & enemy.hp>605]\nuse(Wild Winds:514) [enemy.hpp>50 & enemy.hp>650]\n\n--H/S, docile H/H\nif [self.power=260]\nuse(Glowing Toxin:270) [!enemy.aura(Glowing Toxin:271).exists & enemy.hp>280 & !self.ability(#3).strong]\nuse(Glowing Toxin:270) [!enemy.aura(Glowing Toxin:271).exists & enemy.hp>420 & self.ability(#3).strong]\nendif\n-- S/B, H/B\nif [self.power=273]\nuse(Glowing Toxin:270) [!enemy.aura(Glowing Toxin:271).exists & enemy.hp>293 & !self.ability(#3).strong]\nuse(Glowing Toxin:270) [!enemy.aura(Glowing Toxin:271).exists & enemy.hp>439 & self.ability(#3).strong]\nendif\n-- B/B\nif [self.power=276]\nuse(Glowing Toxin:270) [!enemy.aura(Glowing Toxin:271).exists & enemy.hp>296 & !self.ability(#3).strong]\nuse(Glowing Toxin:270) [!enemy.aura(Glowing Toxin:271).exists & enemy.hp>444 & self.ability(#3).strong]\nendif\n-- P/B,P/S\nif [self.power=289]\nuse(Glowing Toxin:270) [!enemy.aura(Glowing Toxin:271).exists & enemy.hp>309 & !self.ability(#3).strong]\nuse(Glowing Toxin:270) [!enemy.aura(Glowing Toxin:271).exists & enemy.hp>463 & self.ability(#3).strong]\nendif\nstandby [enemy.aura(Flying:341).exists]\nstandby [enemy.aura(Underground:340).exists]\nstandby [enemy.aura(Underwater:830).exists]\nstandby [enemy.aura(Dodge:311).exists]\nstandby [enemy.aura(Silk Cocoon:505).exists]\nuse(Wing Buffet:1756)\nstandby\n--\nendif\n\nuse(Cauterize:173) [enemy(#1).active]\nuse(Peck:112)\nuse(Burn:113)\nstandby\nchange(#1)\nchange(#3)",
				},
				[154919] = {
					["name"] = "Voltgorger",
					["code"] = "ability(Inflation:1002)",
				},
				[66639] = {
					["name"] = "Gutretch",
					["code"] = "change(next) [self.dead]\nability(Breath:115) [enemy.hp>560]\nability(Explode:282) [enemy(#3).active]\nability(Minefield:634) [enemy.aura(Underground:340).exists]\nability(Batter:455)",
				},
				[154920] = {
					["name"] = "Frenzied Knifefang",
					["code"] = "ability(Predatory Strike:518) [enemy.aura(Shattered Defenses:542).exists]\nability(Falcosaur Swarm!:1773)\nchange(next)",
				},
				[85419] = {
					["name"] = "Gnawface",
					["code"] = "use(Explode:282) [round=3]\nuse(Wind-Up:459)",
				},
				[142234] = {
					["name"] = "Small Beginnings",
					["code"] = "change(Nexus Whelpling:1165) [ self(Iron Starlette:1387).dead ]\nability(Supercharge:208) [ self.round = 2 ]\nability(Wind-Up:459)\nability(Arcane Storm:589) [ self.round = 1 ]\nability(Mana Surge:489)\nability(Tail Sweep:122)\nability(Black Claw:919) [ self.round = 1 ]\nability(Flock:581)",
				},
				[173376] = {
					["name"] = "Lurking In The Shadows",
					["code"] = "ability(Toxic Smoke:640) [round>3]\nability(Supercharge:208) [self.aura(Wind-Up:458).exists]\nability(#1)\nchange(next)",
				},
				[66815] = {
					["name"] = "Bordin Steadyfist",
					["code"] = "if [enemy(#1).active]\nuse(Bubble)\nuse(Water Jet)\nendif\n\nif [enemy(#2).active]\nchange(Anubisath Idol)\nuse(Stoneskin) [self.aura(Stoneskin).duration<2]\nuse(Crush)\nendif\n\nuse(Stoneskin) [enemy.round=1]\nuse(Deflection) [self.aura(Elementium Bolt).duration=1]\nuse(Crush)\n\nchange(#3) [self(#2).dead & !self(#3).played]\nchange(Mud Jumper) [self(#2).dead]\nuse(Bubble)\nuse(Water Jet)",
				},
				[71931] = {
					["name"] = "Taran Zhu",
					["code"] = "use(589)\nuse(422)\nchange(2199)\n\nuse(654) [enemy(1292).active]\n\nif [enemy(1293).active]\n  use(666) [self.ability(654).duration > 1]\n  use(2071)\n  use(654)\nendif\n\nuse(666)",
				},
				[94642] = {
					["name"] = "Direflame",
					["code"] = "if [enemy(#1).active]\nchange(#2) [round=3]\nuse(Blistering Cold:786)\nuse(Acid Rain:1051)\nuse(Blinding Poison:1049)\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Barbed Stinger:1369)\nendif\nuse(Blinding Poison:1049)\nuse(Barbed Stinger:1369)\nchange(#1)\nuse(Ironbark:962)\n\n-- dreamwhelp\nuse(Healing Flame:168) [self.hpp<70]\nuse(Emerald Presence:597) [self.aura(Emerald Presence:823).duration<=1]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Flying:341).exists]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Underground:340).exists]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Underwater:830).exists]\nuse(Emerald Presence:597) [enemy.aura(Dodge:311).exists]\nuse(Emerald Presence:597) [enemy.aura(Silk Cocoon:505).exists]\nuse(Emerald Bite:525)\n\nstandby\nchange(next)",
				},
				[85463] = {
					["name"] = "Gorefu",
					["code"] = "ability(Wind-Up) [round=1]\nability(Supercharge) [round=2]\nability(Wind-Up) [round=3]",
				},
				[154921] = {
					["name"] = "Giant Opaline Conch",
					["code"] = "ability(Explode:282) [round>2] \nability(Wind-Up:459) \nability(Howl:362) \nability(Surge of Power:593) \nchange(next)",
				},
				[116786] = {
					["name"] = "Deviate Smallclaw",
					["code"] = "change(next) [self.dead]\nuse(Moth Dust:508)\nuse(Cocoon Strike:506)\nuse(Slicing Wind:420)\nstandby",
				},
				[141215] = {
					["name"] = "Unbreakable",
					["code"] = "ability(decoy:334) [round=1]\nchange(#2) [round=2]\nchange(#3) [round=3]\nability(#3) [ enemy.aura(Broken Shell:2111).exists ]\nability(#2)\nability(#1)",
				},
				[173377] = {
					["name"] = "Airborne Defense Force",
					["code"] = "use(#2) [self(#3).active]\nuse(#3)\nuse(#2)\nstandby [self.aura(Asleep:498).exists]\nchange(next)",
				},
				[141799] = {
					["name"] = "Pack Leader",
					["code"] = "standby [enemy.aura(Undead:242).exists]\nability(Ion Cannon:209) [enemy(#3).active & enemy.round=2]\nability(Decoy:334)\nability(Haywire:916)\nability(Shock and Awe:646)\nability(Toxic Smoke:640)\nability(#1)\nchange(next)",
				},
				[139489] = {
					["name"] = "Crab People",
					["code"] = "ability(Predatory Strike:518) [enemy.aura(Shattered Defenses:542).exists]\nability(Savage Talon:1370) [enemy.aura(Shattered Defenses:542).exists]\nability(Falcosaur Swarm!:1773)\nchange(next)",
				},
				[68558] = {
					["name"] = "Gorespine",
					["code"] = "change(#2) [self(#1).active & self.dead]\nuse(Metal Fist:384) [self.round>4]\nuse(Launch Rocket:293)\nuse(Howl:362)\nuse(Surge of Power:593)",
				},
				[155145] = {
					["name"] = "Plagued Critters",
					["code"] = "ability(Rain Dance:1062) [ round>2 ]\nability(Water Jet:118) [enemy(#2).dead & enemy(#3).dead]\nability(Tidal Wave:419)\nchange(next)",
				},
				["Fight Night: Bodhi Sunwayver"] = {
					["name"] = "Fight Night: Bodhi Sunwayver",
					["code"] = "change(#3) [enemy(#3).active & !self(#3).played]\nchange(#3) [self(#1).dead & !self(#3).played]\nchange(#2) [self(#3).active]\n\nif [enemy(Itchy:1800).active]\nability(Arcane Blast:421)\nendif\n\nuse(Consume Magic:1231)\nif [enemy(Salty Bird:1801).active]\nability(Arcane Blast:421)\nendif\n\nstandby [self.aura(Stunned:174).exists]\nability(Ghostly Bite:654) [enemy.hp<=768]\nability(Shadow Slash:210)",
				},
				[161662] = {
					["name"] = "Char",
					["code"] = "use(Beam:114) [ round=1 ]\nuse(Soul Ward:751) [ round=2 ]\nuse(Illuminate:460)\nuse(Skitter:626) [ round=6 ]\nuse(Explode:282)\nchange(next)\nstandby",
				},
				[68563] = {
					["name"] = "Kafi",
					["code"] = "use(Explode:282) [enemy.hp.can_explode]\nuse(Wind-Up:459)\nuse(Powerball:566) [enemy.hp > 560]\nuse(Make it Rain:985) [self.round=1]\nuse(Inflation:1002) [self.round=2]\nstandby\nchange(next)",
				},
				[72290] = {
					["name"] = "Zao, Calfling of Niuzao",
					["code"] = "use(Curse of Doom:218)\nuse(Haunt:652)\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Flock:581)\nchange(next)",
				},
				[119346] = {
					["name"] = "Unfortunate Defias",
					["code"] = "use(Dive:564) [enemy.aura(Undead:242).exists]\nuse(Dive:564) [enemy(#2).active]\nuse(Call Darkness:256)\nuse(Nocturnal Strike:517)\nuse(#2)\nuse(#1)\nchange(next)",
				},
				[71932] = {
					["name"] = "Wise Mari",
					["code"] = "change(#2) [enemy(River:1297).active]\nuse(Conflagrate:179) [!enemy(Spirus:1298).aura(Soul Ward:750).exists & enemy.aura(Flame Breath:500).exists]\nuse(Flame Breath:501) [enemy(Spirus:1298).active]\nuse(Quills:184)\nuse(Consume Magic:1231) [self.aura(Whirlpool:512).exists]\nuse(Creeping Ooze:448) [enemy(River:1297).active]\nuse(#1)\nchange(next)",
				},
				[94643] = {
					["name"] = "Mirecroak",
					["code"] = "use(Black Claw:919) [!enemy(#1).aura(Black Claw:918).exists & enemy(#1).active]\nuse(Flock:581) [enemy(#1).active]\nuse(Savage Talon:1370)\nuse(Emerald Dream:598) [self.hp<900]\nuse(Emerald Presence:597) [!self.aura(Emerald Presence:823).exists]\nuse(Emerald Presence:597) [enemy.aura(Dodge:311).exists]\nuse(Emerald Presence:597) [enemy.aura(Underground:340).exists]\nuse(Emerald Presence:597) [enemy.aura(Flying:341).exists]\nuse(Emerald Bite:525)\nuse(#3) [self(#2).active]\nuse(#2) [self(#2).active]\nuse(#1) [self(#2).active]\nchange(next)",
				},
				[72285] = {
					["name"] = "Chi-Chi, Hatchling of Chi-Ji",
					["code"] = "ability(Immolation:409) [!self.aura(Immolation:408).exists]\nability(Wild Magic:592) [!enemy.aura(Wild Magic:591).exists]\nability(Acidic Goo:369) [self.round=1]\nability(Dive:564) [self.round=4]\nchange(#2)\nability(#1)",
				},
				[154923] = {
					["name"] = "Sputtertube",
					["code"] = "use(Black Claw:919) [round=1]\nuse(Flock:581)\nchange(#2)\nuse(Flamethrower:503) [!enemy(Sputtertube:2736).aura(Flamethrower:502).exists]\nuse(Burn:113)",
				},
				[173315] = {
					["name"] = "Resilient Survivors",
					["code"] = "ability(Prowl:536) [self.aura(Blinding Poison:1048).exists]\nstandby [self.aura(Blinding Poison:1048).exists]\nability(Whirlpool:513) [enemy.round=1]\nability(Dive:564) [round=2]\nability(Arcane Storm:589)\nability(Mana Surge:489)\nability(#1)\nchange(next)",
				},
				[71926] = {
					["name"] = "Lorewalker Cho",
					["code"] = "ability(Life Exchange:277) [enemy(#2).active]\nability(Moonfire:595)\nif [enemy(#3).active]\n  ability(Plagued Blood:657) [!enemy.aura(Plagued Blood:658).exists]\n  ability(Death and Decay:214) [!enemy.aura(Death and Decay:213).exists]\n  ability(Kick:307)\nendif\nability(#1)\nchange(#2)",
				},
				[161649] = {
					["name"] = "Rampage",
					["code"] = "ability(Blistering Cold:786)\nability(Chop:943)\nability(Flock:581) [!enemy.aura(Shattered Defenses:542).exists]\nability(Shock and Awe:646)\nability(Ion Cannon:209)\nability(#1)\nstandby\nchange(next)",
				},
				[119343] = {
					["name"] = "Klutz's Battle Rat",
					["code"] = "use(weather:453)\nuse(def:490) [ enemy.aura(liftedoff:341).exists ]\nuse(filler:406)",
				},
				[71929] = {
					["name"] = "Sully \"The Pickle\" McLeary",
					["code"] = "change(Firewing:1545) [ self(Mr. Bigglesworth:1145).dead ]\nuse(Ice Tomb:624) [ enemy(#1).active & enemy.round=1 ]\nuse(Ice Barrier:479) [ enemy(#1).active & enemy.round=2 ]\nstandby [ round=3 ]\nchange(Elekk Plushie:1426) [ enemy.aura(Underground:340).exists ]\nstandby [ self(Elekk Plushie:1426).active & !self.aura(Bleeding:491).exists ]\nchange(Mr. Bigglesworth:1145) [ self.aura(Bleeding:491).exists ]\nstandby [ self(Firewing:1545).active & self.round=1 ]\nif [ enemy(Rikki:1290).active & self(Firewing:1545).active ]\n    use(Sunlight:404) [ enemy.round=1 ]\n    use(Healing Flame:168) [ enemy.round=2 ]\nendif\nuse(Healing Flame:168)\nuse(Sunlight:404) [weather(Sunny Day:403).duration=1]\nuse(#1)",
				},
				[116793] = {
					["name"] = "Hiss",
					["code"] = "ability(Extra Plating:392) [round=1]\nability(Make it Rain:985)\nability(Inflation:1002)\nability(Moonfire:595)\nability(Soulrush:752)\nability(#1)\nchange(next)",
				},
				[71924] = {
					["name"] = "Wrathion",
					["code"] = "if [self(#1).active]\nuse(Burrow:159) [self.aura(Ice Tomb:623).duration=1]\nuse(Toxic Skin:1087) [enemy.aura(Undead:242).exists]\nuse(Scratch:119)\nendif\n\nif [enemy(Dah'da:1300).active]\n\nuse(#1) [self.ability(Call Darkness:256).usable & self.ability(Nocturnal Strike:517).usable & self.power<322 & enemy.hp>1500]\nuse(#1) [self.ability(Call Darkness:256).usable & self.ability(Nightmare:1731).usable & self.power<327 & enemy.hp>1480]\nuse(Vicious Slice:1223) [self.ability(Call Darkness:256).usable & enemy.hp>1084 & self.power=301]\nuse(Vicious Slice:1223) [self.ability(Call Darkness:256).usable & enemy.hp>961 & self.power=265]\nuse(Vicious Slice:1223) [self.ability(Call Darkness:256).usable & enemy.hp>864 & self.power=236]\n\nuse(Alert!:1585) [enemy.hp>1546 & self.power<271]\nuse(Bite:110) [enemy.hp>1380 & self.ability(Ghostly Bite:654).usable]\nuse(Bite:110) [enemy.hp>1480 & self.ability(Surge of Power:593).usable]\nuse(Focus Chi:223) [self.ability(Fury of 1,000 Fists:226).usable]\nuse(Prowl:536)\nuse(Roar of the Dead:2071)\nuse(Amber Prison:1026)\nuse(Howl:362)\nuse(Supercharge:208)\nuse(Nightmare:1731)\n\nuse(Call Darkness:256)\n\nuse(Tornado Punch:1052)\nuse(Fury of 1,000 Fists:226)\nuse(Ghostly Bite:654)\nuse(Surge of Power:593)\nuse(Ion Cannon:209)\nuse(Nocturnal Strike:517)\nuse(Fist of the Forest:1343)\nuse(Takedown:221) [enemy.aura(Stunned:1030).exists]\n\nendif\n\nuse(Jab:219)\nuse(Club:1079)\nuse(Bite:110)\nuse(Pounce:535)\nuse(Alert!:1585)\nuse(Sticky Web:339)\n\nstandby [self.aura(Stunned:927).exists]\nchange(#2)\nuse(#1)",
				},
				[154924] = {
					["name"] = "Goldenbot XD",
					["code"] = "change(#2) [ round=3 ]\nchange(#1) [ self(#2).active ]\nuse(786)\nstandby [self(#1).active]\nuse(919) [ self.round = 1 ]\nuse(581)\nchange(#3)",
				},
				[116795] = {
					["name"] = "Everliving Spore",
					["code"] = "use(Immolation:409) [ round=1 ]\nuse(Wild Magic:592) [ round=2 ]\nuse(Burn:113) [ enemy(#1).dead ]\nuse(Crouch:165) [ self.round=1 ]\nuse(Predatory Strike:518) [ enemy.aura(Shattered Defenses:542).exists & enemy.type!=9 & enemy.hp>315 ]\nuse(Predatory Strike:518) [ enemy.aura(Shattered Defenses:542).exists & enemy.type=9 & enemy.hp>471 ]\nuse(Falcosaur Swarm!:1773)\nuse(Ion Cannon:209) [ enemy(#3).aura(Shattered Defenses:542).exists ]\nuse(Ion Cannon:209) [ enemy.type!=8 & enemy(#3).hp<=732 ]\nuse(Ion Cannon:209) [ enemy.type=8 & enemy(#3).active ]\nuse(Shock and Awe:646)\nuse(Missile:777)\nchange(next)",
				},
				[116794] = {
					["name"] = "Growing Ectoplasm 2",
					["code"] = "change(#2) [self(#1).dead]\nchange(#3) [self(#2).dead]\nif [enemy(#1).active]\n    ability(919) [!enemy.aura(918).exists]\n    ability(921)\n    ability(364) [enemy.aura(542).exists]\nendif\nability(919) [!enemy.aura(918).exists]\nability(921)\nability(597) [self.aura(823).duration<=1]\nability(598) [self.hp<1000]\nability(525)",
				},
				[161650] = {
					["name"] = "Liz",
					["code"] = "change(#2) [enemy.aura(Flamethrower:502).exists]\nuse(Decoy:334)\nuse(Sticky Grenade:636) [!enemy.aura(Sticky Grenade:637).exists]\nuse(Flamethrower:503)\nuse(Drill Charge:1921)\nuse(Toxic Smoke:640)",
				},
				[173274] = {
					["name"] = "Failed Experiment",
					["code"] = "standby [ enemy.aura(Undead:242).exists ]\nuse(Curse of Doom:218)\nuse(Haunt:652)\nuse(Black Claw:919) [ self.round=1 ]\nuse(Swarm:706)\nuse(Scratch:119)\nchange(next)",
				},
				[71933] = {
					["name"] = "Blingtron 4000",
					["code"] = "if [self(#1).active]\nability(297) [self.round = 1]\nability(118) [self.round = 2]\nability(297) [self.round = 3]\nability(118) [self.round > 3]\nendif\nchange(#2) [self(#1).dead]\nif [self(#2).active]\nability(574) [self.aura(820).duration < 2]\nability(521) [!self.aura(520).exists]\nability(429)\nendif\nchange(#3) [self(#2).dead]\nif [self(#3).active]\nability(#2) [self.round = 1]\nability(#3) [self.round = 2]\nability(#1) [self.round > 2]\nendif",
				},
				[94644] = {
					["name"] = "Dark Gazer",
					["code"] = "use(Chop:943) [round=7]\nchange(#1) [round=5]\nchange(#2) [round=2]\nuse(Blistering Cold:786)\nuse(Chop:943)\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Blinding Poison:1049)\nuse(Barbed Stinger:1369)\nchange(#2)\n\n-- dreamwhelp\nuse(Healing Flame:168) [self.hpp<70]\nuse(Emerald Presence:597) [self.aura(Emerald Presence:823).duration<=1]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Flying:341).exists]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Underground:340).exists]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Underwater:830).exists]\nuse(Emerald Presence:597) [enemy.aura(Dodge:311).exists]\nuse(Emerald Presence:597) [enemy.aura(Silk Cocoon:505).exists]\nuse(Emerald Bite:525)\n\nstandby",
				},
				[145968] = {
					["name"] = "Leper Rat",
					["code"] = "ability(#3) [!enemy.aura(502).exists]\nstandby [enemy.aura(2060).exists] \nstandby [enemy.aura(242).exists]\nability(2067) [enemy.aura(542).exists]\nability(2067) [enemy(2486).active]\nability(163)\nability(179) [enemy.aura(502).exists]\nability(503) [self.ability(503).strong]\nability(#1) \nchange(next)",
				},
				[154925] = {
					["name"] = "Creakclank",
					["code"] = "standby [round=1]\nchange(Boneshard:1963) [round=2]\nuse(Blistering Cold:786)\nuse(Chop:943) [!enemy.aura(Bleeding:491).exists]\nuse(BONESTORM:1762)\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Flock:581)\nchange(Ikky:1532)",
				},
				[116791] = {
					["name"] = "Dreadcoil",
					["code"] = "ability(Touch of the Animus:940)\nability(Drain Blood:1043) [enemy.aura(Plagued Blood:658).exists]\nability(#1)\nchange(next)",
				},
				[116792] = {
					["name"] = "Phyxia",
					["code"] = "if [enemy(#1).active]\n    ability(459) [self.round=1]\n    ability(208) [self.round=2]\n    ability(459) [self.round=3]\n    ability(640)\nendif\nability(640)\nchange(#2) [self(#1).dead]\n\nability(#3) [enemy.hp<618 & enemy.type !~ 3]\nability(#3) [enemy.hp<406 & enemy.type ~ 3]\nability(#2) [!self(#2).aura(820).exists]\nability(#1)",
				},
				[173381] = {
					["name"] = "Ardenweald's Tricksters",
					["code"] = "change(next) [ self(#1).dead & !self(#3).played ]\nuse(Decoy:334)\nuse(Explode:282)\nuse(Supercharge:208)\nuse(Ion Cannon:209)",
				},
				[89130] = {
					["name"] = "Gorefu",
					["code"] = "use(Desatado:459) [round=1]\nuse(Supercarga:208) [round=2]\nuse(Desatado:459) [round=3]",
				},
				[116787] = {
					["name"] = "Deviate Flapper",
					["code"] = "use(#3) [round=1]\nuse(#2) [round=2]\nuse(#1)",
				},
				[87122] = {
					["name"] = "Gargra",
					["code"] = "standby [ enemy.ability(Howl:362).usable ]\nchange(next) [ self(#1).dead & ! self(#3).played ]\nability(Minefield:634)\nability(Explode:282) [ ! enemy.aura(Minefield:635).exists ]\nability(Batter:455)\nability(Shock and Awe:646)\nability(Ion Cannon:209) [ self(#3).active ]",
				},
				[66738] = {
					["name"] = "Courageous Yon",
					["code"] = "if [ enemy(Piqua:1003).active ]\n    if [ !self(#3).played ]\n        use(Sandstorm:453) [ self.round = 1 ]\n        standby [ self.round = 2 ]\n        use(Deflection:490) [ self.round = 3 ]\n        change(#2) [ self.round = 4 ]\n    endif\n    change(#3) [ self(#2).active ]\n    change(Anubisath Idol:1155) [ self(#3).played ]\nendif\nstandby [ enemy.ability(Lift-Off:170).usable ]\nstandby [ enemy.ability(Burrow:159).usable & enemy.aura(Adrenaline:161).exists ]\nuse(Deflection:490) [ enemy(Piqua:1003).aura(Flying:341).exists ]\nuse(Deflection:490) [ enemy(Lapin:1002).aura(Underground:340).exists ]\nuse(Deflection:490) [ enemy(Bleat:1001).aura(Chew:540).exists ]\nuse(Sandstorm:453)\nuse(#1)",
				},
				[154926] = {
					["name"] = "CK-9 Micro-Oppression Unit",
					["code"] = "use(#2) [self(#2).active & self(#3).dead] \nuse(#1) [self(#2).active & self(#3).dead] \nchange(#2) [self(#1).active & self.round=3] \nuse(#2) [self(#1).active] \nuse(#1) [self(#1).active] \nchange(#3) [self(#2).active & self.round=2] \nuse(#3) [self(#2).active] \nchange(#2) [self(#3).dead] \nuse(#2) [self(#3).active & !enemy.aura(Black Claw:918).exists] \nuse(#3) [self(#3).active]",
				},
				[68555] = {
					["name"] = "Ka'wi the Gorger",
					["code"] = "change(#2) [self(#1).dead]\nuse(Garra negra:919) [!enemy.aura(Garra negra:918).exists]\nuse(Bandada:581)\nuse(Grupo de caza:921)\nuse(Saltar:364)",
				},
				[119407] = {
					["name"] = "Cookie's Leftovers",
					["code"] = "standby [ self.aura(926).exists & self.speed.fast ]\nability(334)\nability(779)\nability(115)\nchange(#2)\nability(312) [ enemy.ability(#3).usable ]\nability(574) [ self.aura(820).duration < 2 & self.speed.slow ]\nability(574) [ !self.aura(820).exists ]\nability(504)",
				},
				["Farmer Nishi"] = {
					["name"] = "Farmer Nishi",
					["code"] = "if [enemy(#1).active]\nability(453)\nability(490) [self.round> 2]\nability(406)\nendif\nif [enemy(#2).active]\nstandby [enemy.round <= 3]\nstandby [enemy.round=11]\nstandby [enemy.round= 12]\nability(490) [enemy.round=4]\nability(490) [enemy.round=9]\nability(490) [enemy.round=14]\nability(453) [enemy.round=10]\nability(406)\nendif\nif [enemy(#3).active]\nstandby [enemy.round=2]\nability(490) [enemy.round=3]\nability(406) [enemy.round= 1]\nchange(#2) [self(#1).active]\nability(646)\nability(777) [enemy.round = 6]\nability(209)\nendif",
				},
				[119345] = {
					["name"] = "Klutz's Battle Monkey",
					["code"] = "ability(Ironskin:1758) [ round>2 ]\nability(Predatory Strike:518) [ enemy.aura(Shattered Defenses:542).exists & enemy.hpp>25 ]\nability(#1)\nchange(#2)",
				},
				[71934] = {
					["name"] = "Dr. Ion Goldbloom",
					["code"] = "use(Howl:362) [enemy.aura(Flying:341).exists]\nuse(Surge of Power:593) [enemy.aura(Howl:1725).exists]\nuse(Arcane Explosion:299)\nuse(Conflagrate:179) [enemy(#3).active]\nuse(Flame Breath:501) [!enemy.aura(Flame Breath:500).exists]\nuse(Scorched Earth:172)\nuse(Ion Cannon:209) [enemy(#3).hp<1142]\nuse(#1)\nchange(next)",
				},
				[94645] = {
					["name"] = "Bleakclaw",
					["code"] = "use(Spiritfire Bolt:1066) [round=1]\nchange(#2) [round=2]\nuse(Howl:362) [round=3]\nuse(Surge of Power:593) [round=4]\nuse(Bite:110)\n\n--\nuse(Deflection:490) [enemy.aura(Flying:341).exists]\nuse(Deflection:490) [enemy.aura(Underground:340).exists]\nuse(Deflection:490) [enemy.aura(Underwater:830).exists]\nuse(Sandstorm:453)\nuse(Spiritfire Bolt:1066)\n\n--\nuse(Emerald Presence:597) [!self.aura(Emerald Presence:823).exists]\nuse(Healing Flame:168) [self.hpp<70]\nuse(Emerald Dream:598) [self.hpp<70]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Flying:341).exists]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Underground:340).exists]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Underwater:830).exists]\nuse(Emerald Presence:597) [enemy.aura(Dodge:311).exists]\nuse(Emerald Presence:597) [enemy.aura(Silk Cocoon:505).exists]\nuse(Emerald Bite:525)\nuse(#1)\n\nstandby\nchange(#1)",
				},
				[119408] = {
					["name"] = "\"Captain\" Klutz",
					["code"] = "standby [ enemy.round < 3 ]\nability(218)\nability(652)\nchange(#2)\nability(919) [ !enemy.aura(918).exists ]\nability(581)",
				},
				[154927] = {
					["name"] = "Unit 35",
					["code"] = "use(1717)\nuse(906) [ round = 3 ]\nuse(908)",
				},
				[119342] = {
					["name"] = "Angry Geode",
					["code"] = "ability(Dive:564) [enemy.aura(Stoneskin:435).exists & enemy.ability(Crystal Prison:569).usable]\nability(Nature's Ward:574) [self.hpp<100 & !self.aura(Nature's Ward:820).exists]\nability(#1)\nchange(next)",
				},
				[150911] = {
					["name"] = "Crypt Fiend",
					["code"] = "standby [enemy.aura(Undead:242).exists]\nability(Comeback:253) [enemy.aura(Shattered Defenses:542).exists]\nability(Stampede:163) [self.aura(Chew:540).exists]\nability(Chew:541)\nability(#1)\nchange(next)",
				},
				[66675] = {
					["name"] = "Major Payne",
					["code"] = "change(#2) [!self(#2).played & self(#1).dead]\nchange(#3) [self(#1).dead]\nuse(Extra Plating:392) [enemy.hp.full] \nuse(Make it Rain:985) [enemy.aura(Make it Rain:986).duration < 2] \nuse(Inflation:1002)\nuse(Blood in the Water:423) [enemy.aura(Bleeding:491).exists]\nuse(Rip:803) [!enemy.aura(Bleeding:491).exists]\nuse(#2)\nstandby [self.aura(Stunned:927).exists]",
				},
				[89131] = {
					["name"] = "Gnawface",
					["code"] = "use(Explode:282) [round=3]\nuse(Wind-Up:459)",
				},
				[119409] = {
					["name"] = "Foe Reaper 50",
					["code"] = "ability(418)\nability(564)\nability(118)\nchange(#2)\nability(#1)",
				},
				[142114] = {
					["name"] = "Add More to the Collection",
					["code"] = "change(#2) [ self(#1).dead & !self(#2).played ]\nchange(#3) [ self(#2).played ]\nif [ !enemy(#3).active ]\nuse(Wind-Up:459) [ !self.aura(Wind-Up:458).exists ]\nuse(Wind-Up:459) [ self.aura(Supercharged:207).exists ]\nuse(Supercharge:208)\nuse(Powerball:566)\nendif\nuse(Arcane Storm:589)\nuse(Mana Surge:489)\nuse(Tail Sweep:122)\nstandby",
				},
				[66739] = {
					["name"] = "Wastewalker Shu",
					["code"] = "change(#3) [self(#1).dead & !self(#3).played] \nchange(#2) [self(#3).active] \nability(Explode:282) [ enemy(#3).hp < 560 ] \nability(Evanescence:440) [ self.aura(Whirlpool:512).duration = 1 ] \nability(Evanescence:440) [enemy(#2).active & enemy.round=2] \nability(Evanescence:440) [enemy(#2).active & enemy.round=7] \nability(Wish:273) [enemy(#1).active & enemy.round=7] \nability(Wish:273) [enemy(#2).active & enemy.round=4] \nability(Arcane Blast:421) \nability(Powerball:566)\n-- Script provided by Nikeisha, see comments. Many thanks!",
				},
				[154928] = {
					["name"] = "Unit 6",
					["code"] = "change(#2) [self(#1).dead & !self(#2).played]\nchange(#3) [self(#2).played & self(#1).dead]\n\nability(Blistering Cold:786)\nability(Black Claw:919) [self.round=1]\nability(#1)\nchange(next)",
				},
				[145988] = {
					["name"] = "Pulverizer Bot Mk 6001",
					["code"] = "use(Howl:362)\nuse(Lightning Shield:906)\nstandby",
				},
				[146002] = {
					["name"] = "Gnomeregan Guard Wolf",
					["code"] = "ability(Heat Up:945) [round=1]\nability(Heat Up:945) [enemy.round=2]\nability(Immolation:409) [round=2]\nstandby [enemy.aura(Dodge:2060).exists]\nstandby [enemy.aura(Undead:242).exists]\nability(#3) [enemy(#3).active & self.ability(#3).strong]\nability(Claw:429) [enemy(#2).active]\nability(Frenzy:1965) [!self.aura(Frenzy:739).exists]\nability(#1)\nchange(next)",
				},
				[173129] = {
					["name"] = "Thenia's Loyal Companions",
					["code"] = "standby [ self.aura(Asleep:498).exists ]\nchange(#2) [ enemy.aura(Stunned:927).exists ]\nchange(#3) [ enemy(#3).active ]\nuse(Ethereal:998) [ round=1 ]\nuse(Soulrush:752)\nuse(Arcane Storm:589)\nuse(Mana Surge:489)\nuse(Supercharge:208)\nuse(Ion Cannon:209)\nstandby",
				},
				[66819] = {
					["name"] = "Brok",
					["code"] = "ability(Fire Shield:1754)\nability(Lightning Shield:906)\nability(Arcane Blast:421)\nability(Rampage:124)\nability(Triple Snap:355)\nchange(#3) [self(Tinytron:2078).dead]\nchange(Flayer Youngling:514) [self(#3).active]",
				},
				[146003] = {
					["name"] = "Gnomeregan Guard Tiger",
					["code"] = "if [self(Tiny Snowman:117).active]\nuse(Call Blizzard:206)\nuse(Howling Blast:120)\nuse(Snowball:477)\nchange(next)\nendif\n\nif [self(#2).active]\nuse(#1)\nchange(next)\nendif\n\nif [self(#3).active]\nuse(#1)\nendif",
				},
				[94646] = {
					["name"] = "Vile Blood of Draenor",
					["code"] = "quit [self(#1).active & self.speed.slow & enemy(#1).active & enemy(#2).dead & !enemy(#3).dead]\n\nquit [self(#1).active & self.speed.slow & enemy(#1).active & !enemy(#2).dead & enemy(#3).dead]\n\nquit [self(#1).active & enemy(#1).active & !self(#1).ability(#3).usable]\n\nuse(#3) [self(#1).active & enemy(#1).active]\nuse(#1) [round=2]\n\n-- Turn 3 heal ?\nif [round=3]\nuse(#2) [enemy.aura(Flying:341).exists]\nuse(#2) [enemy.aura(Underground:340).exists]\nuse(#2) [enemy.aura(Underwater:830).exists]\nuse(#2) [enemy.aura(Dodge:311).exists]\nuse(#2) [enemy.aura(Silk Cocoon:505).exists]\nuse(#2) [self.ability(#1).strong]\nuse(#2) [self.hpp<50]\nuse(#1) [enemy.hp>390]\nuse(#2)\nstandby\nendif\n-- end heal turn\n\n\nif [self(#1).active & !enemy(#2).dead & !enemy(#3).dead]\nuse(#1) [self.ability(#3).duration<=1 & self.hpp>50]\nuse(#2)\nif [self.ability(#1).strong]\nuse(#1) [enemy.hp>585]\nstandby\nendif\nuse(#1) [enemy.hp>390]\nstandby\nendif\n\nif [self(#1).active & enemy(#2).dead & !enemy(#3).dead]\nchange(#2) [enemy.hpp<50]\nstandby [enemy.hpp<50]\nuse(#1)\nendif\n\nif [self(#1).active & !enemy(#2).dead & enemy(#3).dead]\nchange(#2) [enemy.hpp<50]\nstandby [enemy.hpp<50]\nuse(#1)\nendif\n\nchange(#3) [self(#2).dead]\nuse(#3) [self(#2).active & enemy(#1).active]\nuse(#2)\nuse(#1)\nstandby\nchange(next)",
				},
				[173257] = {
					["name"] = "Mighty Minions of Maldraxxus",
					["code"] = "if [enemy(#3).active]\nstandby [enemy.ability(Lift-Off:170).usable]\nendif\n\nstandby [self(#1).active & enemy(#2).active]\nchange(#3) [enemy(#3).active & enemy.round=3]\nability(Ion Cannon:209) [enemy.aura(Flying:341).exists]\nability(Curse of Doom:218) [enemy(Bloog:2980).active]\nability(Phase Shift:764) [enemy.aura(Curse of Doom:217).exists]\nability(Supercharge:208) [enemy(Bone Crusher:2981).active]\nability(Ion Cannon:209) [self.aura(Supercharged:207).exists]\nability(Arcane Storm:589)\nability(Mana Surge:489)\nability(#1)\nchange(next)",
				},
				[154929] = {
					["name"] = "Unit 17",
					["code"] = "change(#2) [round=3]\nchange(#3) [self(#2).active]\n\nability(Blistering Cold:786)\nability(Black Claw:919) [self.round=1]\nability(#1)\nchange(next)",
				},
				[146004] = {
					["name"] = "Gnomeregan Guard Mechanostrider",
					["code"] = "ability(Conflagarate:179)\nability(Sons of the Flame:330)\nability(#1)\nchange(next)",
				},
				[146183] = {
					["name"] = "Living Napalm",
					["code"] = "standby [enemy.aura(Dodge:2060).exists]\nstandby [enemy.aura(Undead:242).exists]\nability(Acidic Goo:369) [enemy.hp.full]\nability(Dive:564) [round=2]\nability(Immolate:178) [!enemy.aura(Immolate:177).exists]\nability(Conflagrate:179) [enemy.aura(Immolate:177).exists]\nability(Creeping Ooze:448) [!enemy.aura(Creeping Ooze:781).exists]\nability(Corrosion:447) [enemy.type~4,5]\nability(#1)\nchange(next)",
				},
				[173130] = {
					["name"] = "Micro Defense Force",
					["code"] = "change(next) [ self(#1).dead & !self(#3).played ]\nstandby [ enemy(#3).active & enemy.hpp<25.5 & self.hp<895 ]\nuse(Ice Lance:413) [ round>2 ]\nuse(Ice Tomb:624)\nuse(Call Blizzard:206)",
				},
				[145971] = {
					["name"] = "Cockroach",
					["code"] = "standby [enemy.aura(Dodge:2060).exists]\nstandby [enemy.aura(Undead:242).exists] \nability(Rampage:124)\nability(Leap:364) [enemy(Cockroach:2486).active]\nability(Claw:429) [self.ability(Claw:429).strong]\nability(Ice Tomb:624) \nability(Frost Nova:414) [self.ability(Frost Nova:414).strong]\nability(Unstable Shield:1598)\nability(Burrow:159) [self.round>3]\nability(#1)\nchange(next)",
				},
				[160210] = {
					["name"] = "Tasha Riley",
					["code"] = "if [round<24]\nchange(#2) [enemy.ability(Surge of Power:593).duration=5]\nuse(Glowing Toxin:270) [enemy(#2).aura(Stunned:927).exists]\nuse(Amber Prison:1026) [enemy(#1).active]\nuse(Cocoon Strike:506) [enemy(#2).active & !enemy.ability(Howl:362).usable]\nuse(Glowing Toxin:270) [round>9]\nuse(Ice Tomb:624)\nchange(#1)\nstandby\nendif\n\nuse(Roar of the Dead:2071) [self.round=1]\nuse(Tornado Punch:1052)\nuse(Jab:219)\nuse(Call Blizzard:206) [enemy(#3).active]\nuse(Ice Tomb:624) [enemy.aura(Undead:242).exists]\nuse(Call Blizzard:206) [!weather(Blizzard:205)]\nuse(Ice Lance:413)\nuse(Amber Prison:1026)\nuse(Glowing Toxin:270)\nstandby\nchange(#3)",
				},
				[87124] = {
					["name"] = "Ashlei",
					["code"] = "use(Explode:282) [ enemy(#2).active & enemy.hp.can_explode ]\nuse(Bombing Run:647) [ enemy(#2).active & enemy.hp.full ]\nuse(Breath:115)",
				},
				[146181] = {
					["name"] = "Living Permafrost",
					["code"] = "ability(1087) [self.aura(1086).duration<=1]\nstandby [self.speed.slow & enemy.ability(2239).usable]\nstandby [enemy.aura(2060).exists]\nstandby [enemy.aura(242).exists]\nability(159) [self.ability(159).strong]\nability(429) [self.ability(429).strong]\nability(179) [enemy.aura(502).exists]\nability(503)\nability(#1)\nchange(next)",
				},
				[146005] = {
					["name"] = "Bloated Leper Rat",
					["code"] = "ability(Toxic Skin:1087) [!self.aura(Toxic Skin:1086).exists & self.hp>313]\nability(Whirlpool:513) [!enemy.aura(Whirlpool:512).exists]\nability(#1)\n\nchange(next)",
				},
				[146182] = {
					["name"] = "Living Sludge",
					["code"] = "standby [ self.speed.slow & enemy.ability(Smoke Cloud:2239).usable ]\nstandby [ enemy.aura(Dodge:2060).exists ]\nstandby [ enemy.aura(Undead:242).exists ]\nability(564) [self.aura(2063).duration=1]\nability(564)\nability(934)\nability(745) [enemy.hp>=400]\nability(1343) [enemy.hp>=400]\nability(Lash:394) [enemy.type=5]\nability(#1)\nchange(next)",
				},
				[141479] = {
					["name"] = "Strange Looking Dogs",
					["code"] = "change(#2) [ self(Iron Starlette:1387).dead & !self(#2).played ]\nchange(#3) [ self(Iron Starlette:1387).dead & self(#2).played ]\nuse(Wind-Up:459) [ !self.aura(Wind-Up:458).exists ]\nuse(Supercharge:208) [ !self.aura(Supercharged:207).exists ]\nuse(Powerball:566) [ !self.aura(Speed Boost:831).exists & enemy(Pokey:2332).active ]\nuse(Wind-Up:459)\nuse(Swarm of Flies:232) [ !enemy.aura(Swarm of Flies:231).exists ]\nuse(Bubble:934)\nuse(Tongue Lash:228)",
				},
				[173131] = {
					["name"] = "Cliffs of Bastion",
					["code"] = "change(#3) [ enemy(#3).active ]\nuse(Decoy:334)\nuse(Explode:282)\nuse(Supercharge:208) [ enemy(#1).active ]\nuse(Call Lightning:204)\nuse(Metal Fist:384)\nuse(Howl:362)\nuse(Surge of Power:593)\nchange(next)",
				},
				[146001] = {
					["name"] = "Prototype Annoy-O-Tron",
					["code"] = "standby [round~2,6,8,12]\nability(624) [round~1,7,11]\nability(206) [round~3,9,13]\nability(413) [round~4,5,10]\nability(#1)\nchange(next)",
				},
				[155413] = {
					["name"] = "Postmaster Malown",
					["code"] = "use(Swarm of Flies:232) [enemy(#1).aura(Undead:242).exists]\nuse(Swarm of Flies:232) [round=1]\nuse(Bubble:934) [self.aura(Curse of Doom:217).duration=1]\nuse(Swarm of Flies:232) [!enemy.aura(Swarm of Flies:231).exists]\nuse(Tongue Lash:228)\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Flock:581)\nchange(next) [self.dead]",
				},
				[94647] = {
					["name"] = "Dreadwalker",
					["code"] = "quit [self(#1).active & self.speed.slow & enemy(#1).active & enemy(#2).dead & !enemy(#3).dead]\n\nquit [self(#1).active & self.speed.slow & enemy(#1).active & !enemy(#2).dead & enemy(#3).dead]\n\nquit [self(#1).active & enemy(#1).active & !self(#1).ability(Wind Buffet:1963).usable]\n\nuse(Wind Buffet:1963) [self(#1).active & enemy(#1).active]\nuse(Alpha Strike:504) [round=2]\n\n-- Turn 3 heal ?\nif [round=3]\nuse(Ancient Knowledge:1991) [enemy.aura(Flying:341).exists]\nuse(Ancient Knowledge:1991) [enemy.aura(Underground:340).exists]\nuse(Ancient Knowledge:1991) [enemy.aura(Underwater:830).exists]\nuse(Ancient Knowledge:1991) [enemy.aura(Dodge:311).exists]\nuse(Ancient Knowledge:1991) [enemy.aura(Silk Cocoon:505).exists]\nuse(Ancient Knowledge:1991) [self.ability(#1).strong]\nuse(Ancient Knowledge:1991) [self.hpp<50]\nuse(Alpha Strike:504) [enemy.hp>390]\nuse(Ancient Knowledge:1991)\nstandby\nendif\n-- end heal turn\n\nif [self(#1).active & !enemy(#2).dead & !enemy(#3).dead]\nuse(Alpha Strike:504) [self.ability(#3).duration<=1 & self.hpp>50]\nuse(Ancient Knowledge:1991)\nif [self.ability(Alpha Strike:504).strong]\nuse(Alpha Strike:504) [enemy.hp>585]\nstandby\nendif\nuse(Alpha Strike:504) [enemy.hp>390]\nstandby\nendif\n\nif [self(#1).active & enemy(#2).dead & !enemy(#3).dead]\nchange(#2) [enemy.hpp<50]\nstandby [enemy.hpp<50]\nuse(Alpha Strike:504)\nendif\n\nif [self(#1).active & !enemy(#2).dead & enemy(#3).dead]\nchange(#2) [enemy.hpp<50]\nstandby [enemy.hpp<50]\nuse(Alpha Strike:504)\nendif\n\nchange(#2) [self(#1).dead]\nchange(#3) [self(#2).dead]\nuse(Explode:282) [self(#2).active & enemy(#1).active]\nuse(Immolate:178) [self.round=1 & self(#3).active]\nuse(Conflagrate:179) [self.round=2 & self(#3).active]\nuse(Drill Charge:1921)\nuse(Toxic Smoke:640)\nuse(Burn:113)\nstandby",
				},
				[66734] = {
					["name"] = "Farmer Nishi",
					["code"] = "if [enemy(Siren:997).active]\nability(Cleansing Rain:230) [!weather(Cleansing Rain:229)]\nability(Bubble:934)\nability(Water Jet:118)\nendif\n\nif [enemy(Toothbreaker:996).active]\nchange(#2) [!self(#2).played]\nchange(#3) [!self(#3).played]\nchange(Syd the Squid:1478)\nability(Cleansing Rain:230) [enemy.round=7]\nability(Water Jet:118)\nendif\n\nif [enemy(Brood of Mothallus:995).active]\nability(Bubble:934) [self.aura(Acidic Goo:368).exists]\nability(Water Jet:118)\nendif",
				},
				[141814] = {
					["name"] = "Accidental Dread",
					["code"] = "change(#2) [ enemy(#2).active & !self(#2).played ]\nchange(#3) [ enemy(#2).active ]\nchange(#1) [ !enemy(#2).active ]\nchange(#1) [ self(#3).dead ]\nuse(597) [ self.round = 1 ]\nuse(168) [ enemy(#3).active & self.round = 2 & self.hp < 300]\nuse(312)\nuse(#1)",
				},
				[161656] = {
					["name"] = "Splint",
					["code"] = "standby [round=1]\nability(#2) [!enemy.aura(Creeping Fungus:742).exists]\nability(Haunt:652)\nability(#1)\nchange(next)",
				},
				[161651] = {
					["name"] = "Ralf",
					["code"] = "use(Clean-Up:456)\nuse(Soulrush:752)\nchange(#2) [self(#1).active]\nuse(Magic Sword:1085)\nuse(Toxic Smoke:640) [enemy(Ralf:2817).hp<500]\nuse(Supercharge:208) [self.aura(Wind-Up:458).exists]\nuse(Wind-Up:459)\nchange(#1) [self(#2).dead]",
				},
				[141002] = {
					["name"] = "Sea Creatures Are Weird",
					["code"] = "quit [ enemy(#1).active & !enemy.ability(Sweep:457).usable ]\nchange(#1) [ self(#3).active ]\nchange(#3) [ self(#1).dead ]\nif [ self(#1).active ]\n    ability(Supercharge:208) [ round~2,6 ]\n    ability(Wind-Up:459) [ enemy(#1).active ]\n    ability(Wind-Up:459) [ round>6 & self.aura(Mechanical:244).exists & self.aura(Wind-Up:458).exists ]\n    ability(Powerball:566)\nendif\nability(Explode:282) [ enemy(#3).active & enemy(#3).hp<561 ]\nability(Thunderbolt:779) [ !enemy(#2).dead & enemy(#2).hp<245 ]\nability(Thunderbolt:779) [ enemy(#3).active ]\nability(Breath:115)",
				},
				[142054] = {
					["name"] = "Desert Survivors",
					["code"] = "use(Whirlpool:513)\nuse(Inner Vision:216) [enemy.aura(Whirlpool:512).exists & enemy(#3).active]\nuse(Inner Vision:216) [enemy.aura(Underground:340).exists]\nuse(Inner Vision:216) [enemy.aura(Whirlpool:512).duration=1]\nuse(Punch:111)\nuse(Pounce:535) [enemy(#2).active]\nuse(Supercharge:208)\nuse(Pounce:535)\nchange(next)",
				},
				[155267] = {
					["name"] = "Risen Guard",
					["code"] = "standby [enemy(#2).type=4 & enemy(#1).aura(Undead:242).exists]\nstandby [enemy(#3).type=4 & enemy(#2).aura(Undead:242).exists]\nstandby [enemy(#2).type=2 & enemy(#1).aura(Undead:242).exists]\nstandby [enemy(#3).type=2 & enemy(#2).aura(Undead:242).exists]\nchange(#2) [enemy(#1).aura(Undead:242).exists & enemy(#2).type=6]\nchange(#2) [enemy(#2).aura(Undead:242).exists & enemy(#3).type=6]\n-----------------------\nability(Blinding Poison:1049) [round=1]\nability(Decoy:334) [enemy.round=2]\nability(Thunderbolt:779)\nchange(#1) [self(#2).active & enemy.type=4]\nability(Poison Fang:152) [enemy.is(Plague Whelp:2606) & enemy.round=1]\nability(Blinding Poison:1049) [!enemy(#1).active & !enemy.aura(Undead:242).exists]\nability(Poison Fang:152) [!enemy(#1).active & !enemy.aura(Poisoned:379).exists & enemy.type=6]\nchange(#1) [self(#2).active & enemy.type=4]\nability(#1)\nchange(next)",
				},
				[87125] = {
					["name"] = "Taralune",
					["code"] = "if [enemy(#1).active]\nstandby [round=1]\nability(Supercharge:208) [round=3]\nability(Wind-Up:459)\nendif\n\nability(Arcane Storm:589)\nability(Mana Surge:489)\nchange(#3) [self(#1).dead & !self(#3).played]\nchange(#2) [self(#3).active]\nability(#2)\nability(#1)",
				},
				[66741] = {
					["name"] = "Aki the Chosen",
					["code"] = "change(#2) [self(#1).active & self.dead]\nchange(#3) [enemy(#3).hp<560 & !self(#3).played]\nchange(#2) [self(#3).active]\nuse(Black Claw:919) [enemy(#2).active] \nuse(Leap:364) [self.round>2] \nuse(Bite:110)\nif [weather(Lightning Storm:203)]\n  use(Build Turret:710)\n  use(Repair:278)\nendif \nuse(Build Turret:710) [enemy.ability(Dive:564).usable] \nuse(Metal Fist:384)",
				},
				[150914] = {
					["name"] = "Wandering Phantasm",
					["code"] = "use(Haunt:652) [enemy(#2).active]\nuse(Consume Magic:1231) [round~2]\nuse(Hoof:493)\nuse(Shell Shield:310) [!self.aura(Shell Shield:309).exists]\nuse(Shell Shield:310) [self.aura(Shell Shield:309).duration~1]\nuse(Shell Shield:310) [enemy.aura(Undead:242).exists]\nuse(Slow and Steady:1360)\nuse(Charge:778)\nuse(#3)\nuse(#2)\nuse(#1)\nchange(#2) [enemy.type=2]\nchange(#2) [enemy.type=4]\nchange(#3) [enemy.type=6]",
				},
				[173324] = {
					["name"] = "Eyegor's Special Friends",
					["code"] = "use(Call Lightning:204)\nuse(Haywire:916)\nuse(Fel Imolate:901)\n\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Quills:184) [enemy(#2).active]\nuse(Flock:581) [enemy(#3).active]\n\nuse(Supercharge:208)\nuse(Ion Cannon:209)\n\nchange(next)",
				},
				[140461] = {
					["name"] = "Night Horrors",
					["code"] = "change(next) [ self(#1).dead & !self(#3).played ]\nability(Black Claw:919) [ !enemy.aura(Black Claw:918).exists ]\nability(Black Claw:919) [ enemy(#3).active & self.hp>366 ]\nability(Flock:581)\nability(Make it Rain:985)\nability(#1)",
				},
				[173133] = {
					["name"] = "Mega Bite",
					["code"] = "use(Black Claw:919) [ round=1 ]\nuse(Flock:581)\nuse(Predatory Strike:518)\nchange(next)",
				},
				[160205] = {
					["name"] = "Pixy Whizzle",
					["code"] = "ability(Blistering Cold:786) [!enemy.aura(Blistering Cold:785).exists]\nability(Ironbark:962)",
				},
				[146932] = {
					["name"] = "Door Control Console",
					["code"] = "ability(Acidic Goo:369) [ enemy.hp.full ]\nuse(Dive:564) [round=2] \nuse(Dive:564) [self.aura(Ice Tomb:623).duration=1] \nuse(Dive:564) [self.aura(Sewage Eruption:2063).duration=1] \nuse(Ooze Touch:445) \nchange(next)",
				},
				[94648] = {
					["name"] = "Netherfist",
					["code"] = "use(Wing Buffet:1756) [ round=8 ]\nuse(Glowing Toxin:270) [ round=7 ]\nuse(Explode:282) [ round=6 ]\nchange(#1) [ round=4 ]\nchange(#2) [ round=2 ]\nuse(Blinding Powder:1015)\nuse(Glowing Toxin:270) [ !enemy.aura(Glowing Toxin:271).exists ]\nuse(Wing Buffet:1756) [ self.ability(Wing Buffet:1756).strong ]\nuse(Wild Winds:514)\nchange(#2)\n\n-- dreamwhelp\nuse(Healing Flame:168) [ self.hpp<70 ]\nuse(Emerald Presence:597) [ self.aura(Emerald Presence:823).duration<=1 ]\nuse(Emerald Presence:597) [ self.speed.fast & enemy.aura(Flying:341).exists ]\nuse(Emerald Presence:597) [ self.speed.fast & enemy.aura(Underground:340).exists ]\nuse(Emerald Presence:597) [ self.speed.fast & enemy.aura(Underwater:830).exists ]\nuse(Emerald Presence:597) [ enemy.aura(Dodge:311).exists ]\nuse(Emerald Presence:597) [ enemy.aura(Silk Cocoon:505).exists ]\nuse(Emerald Bite:525)\n\n--Void / Anub\nuse(#3) [ enemy.aura(Flying:341).exists ]\nuse(#3) [ enemy.aura(Underground:340).exists ]\nuse(#3) [ enemy.aura(Underwater:830).exists ]\nuse(#2) [ self(#3).active ]\nuse(#1)\n\nstandby",
				},
				[142151] = {
					["name"] = "You've Never Seen Jammer Upset",
					["code"] = "if [ self(Iron Starlette:1387).active ] \nability(Wind-Up:459) [ round=1 ] \nability(Supercharge:208) [ round=2 ] \nability(Wind-Up:459) [ round=3 ] \nability(Wind-Up:459) [ round=4 ] \nchange(#2) [ round=5 ] \nability(Wind-Up:459) [ round >= 6 ] \nendif \nchange(Iron Starlette:1387) [ self(#2).active ]",
				},
				[160208] = {
					["name"] = "Zuna Skullcrush",
					["code"] = "ability(#1) [round=1]\n\nuse(Apocalypse:519)\n\nchange(#3) [enemy.aura(Apocalypse:682).duration=1]\n\nchange(next) [self(#3).active]\n\nuse(#2) [enemy(#1).ability(Toxic Fumes:2349).usable]\nuse(Sunlight:404)\nuse(Photosynthesis:268) [self.aura(Photosynthesis:267).duration<5]\nuse(Nature's Ward:574) [self.aura(Nature's Ward:820).duration<5]\n\nchange(#3) [enemy(#2).hp<285 & !enemy.aura(Apocalypse:682).exists]\n\nchange(#2) [self(#1).active]\nchange(#1) [self(#2).active]",
				},
				[160206] = {
					["name"] = "Alran Heartshade",
					["code"] = "if [enemy(#1).active]\nability(Apocalypse:519) [round=1]\nchange(#3)\nability(Poison Fang:152) [!enemy.ability(#3).usable]\nability(Sniff Out:1895)\nchange(#2)\nability(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nability(Cauterize:173) [self.hpp<=80]\nability(#1)\nendif\n\nif [enemy(#2).active]\nability(Poison Fang:152) [enemy.round=1]\nchange(#2)\nability(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nability(Hunting Party:921)\nability(Bloodfang:917)\nchange(#3) [self(#2).dead & !enemy.dead]\nability(Scratch:119)\nendif\n\nstandby [self(#3).active & enemy(#3).active]\nchange(#1) [enemy(#3).active]\nability(Cauterize:173) [enemy(#3).active]\nstandby [enemy(#3).active]\nability(Cauterize:173) [self.hpp<=80]\nability(#1)\nstandby [self.aura(Stunned:927).exists]",
				},
				[150917] = {
					["name"] = "Huncher",
					["code"] = "use(Exposed Wounds:305)\nuse(Black Claw:919) [ self.round = 1 ]\nuse(Hunting Party:921)\nstandby",
				},
				[68463] = {
					["name"] = "Burning Pandaren Spirit",
					["code"] = "if [enemy(#3).active & weather(Sandstorm:454).duration>2]\n  change(#2) [!self(#2).played & !self(#2).level.max] \n  change(#3) [!self(#3).played & !self(#3).level.max]\nendif\nchange(#1) [!self(#1).active]\nuse(Deflection:490) [enemy.aura(Flying:341).exists]\nuse(Deflection:490) [enemy.ability(Conflagrate:179).usable]\nuse(Sandstorm:453) [round>1]\nuse(Crush:406)",
				},
				[161658] = {
					["name"] = "Shred",
					["code"] = "ability(Curse of Doom:218)\nability(Fade:1084)\nability(Crouch:165) [self.round=1]\nability(Predatory Strike:518) [enemy.aura(Shattered Defenses:542).exists]\nability(Flame Jet:1041) [enemy.aura(Mechanical:244).exists]\nability(#1)\nchange(next)",
				},
				[140813] = {
					["name"] = "Rogue Azerite",
					["code"] = "ability(Whirlpool:513) [self(Pandaren Water Spirit:868).active]\nability(Dive:564) [self(Pandaren Water Spirit:868).active]\nability(Water Jet:118) [self(Pandaren Water Spirit:868).active]\nchange(#2) [self(Pandaren Water Spirit:868).dead & !self(#3).active]\nchange(#3)\nability(Shell Shield:310) [self(#3).aura(Shell Shield:309).duration <2]\nability(Dive:564)\nability(Absorb:449)",
				},
				[161657] = {
					["name"] = "Ninn Jah",
					["code"] = "ability(Deflection:490) [self.aura(Whirlpool:512).duration=1]\nability(Sandstorm:453)\nability(Crush:406)",
				},
				[161661] = {
					["name"] = "Wilbur",
					["code"] = "ability(Black Claw:919) [round=1]\nability(Flock:581) [round=2]\nability(Explode:282) [enemy.hp.can_explode]\nability(#1)\nchange(next)",
				},
				[161663] = {
					["name"] = "Tempton",
					["code"] = "ability(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nability(Flock:581)",
				},
				[68559] = {
					["name"] = "No-No",
					["code"] = "ability(Crouch:165) [round=1]\nability(Falcosaur Swarm!:1773) [enemy.aura(Beaver Dam:326).exists]\nability(Predatory Strike:518) [enemy.aura(Shattered Defenses:542).exists]\nability(Savage Talon:1370) [enemy.aura(Shattered Defenses:542).exists]\nability(Falcosaur Swarm!:1773)\nchange(next)",
				},
				[150918] = {
					["name"] = "Tommy the Cruel",
					["code"] = "ability(706) [self.round=1]\nability(119) [self.round=4]\nability(119) [self.round=5]\nstandby [self.round=6]",
				},
				[94601] = {
					["name"] = "Felsworn Sentry",
					["code"] = "change(#1) [round=6]\nchange(#2) [round=3]\nuse(Blistering Cold:786)\nuse(Chop:943)\nuse(Black Claw:919) [!enemy(#1).active & !enemy.aura(Black Claw:918).exists]\nuse(Blinding Poison:1049)\nuse(Black Claw:919) [enemy(#1).active]\nuse(Barbed Stinger:1369)\nchange(#2)\n\n-- dreamwhelp\nuse(Healing Flame:168) [self.hpp<70]\nuse(Emerald Presence:597) [self.aura(Emerald Presence:823).duration<=1]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Flying:341).exists]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Underground:340).exists]\nuse(Emerald Presence:597) [self.speed.fast & enemy.aura(Underwater:830).exists]\nuse(Emerald Presence:597) [enemy.aura(Dodge:311).exists]\nuse(Emerald Presence:597) [enemy.aura(Silk Cocoon:505).exists]\nuse(Emerald Bite:525)\n\nstandby",
				},
				[141292] = {
					["name"] = "That's a Big Carcass",
					["code"] = "standby [ enemy(#2).active & enemy.round=1 ]\nability(#2) [ !enemy(#3).active ]\nability(#3) [ enemy.aura(Shattered Defenses:542).exists ]\nability(#1)\nchange(#2)",
				},
				[73626] = {
					["name"] = "Little Tommy Newcomer",
					["code"] = "ability(Call Lightning:204)\nability(Build Turret:710) [self.ability(#1).usable]\nability(Metal Fist:384)\nchange(#1) [round=3 & self.aura(Mechanical:244).exists]\nability(Decoy:334)\nability(#1)\nchange(next)",
				},
				[175781] = {
					["name"] = "Sewer Creeper",
					["code"] = "ability(Black Claw:919) [!enemy(#1).aura(Black Claw:918).exists]\nability(BONESTORM!!:1762) [round=3]\nability(Blistering Cold:786)\nability(Chop:943)\nstandby [self(#2).active]\nstandby [self(#3).active]\nchange(next)",
				},
				[173263] = {
					["name"] = "Extra Pieces",
					["code"] = "quit [ self(#1).dead & !enemy(#1).dead ]\nuse(Toxic Skin:1087) [ round=1 ]\nuse(Swarm:706) [ round=2 ]\nuse(Huge, Sharp Teeth!:849) [ !enemy.aura(Bleeding:491).exists ]\nuse(Dodge:312)\nuse(Stampede:163)\nuse(Supercharge:208)\nuse(Ion Cannon:209)\nchange(next)",
				},
				[85622] = {
					["name"] = "Brutus and Rukus",
					["code"] = "use(Supercharge:208) [round~2]\nuse(Toxic Smoke:640) [round~6]\nuse(Wind-Up:459) [self(#1).active]\nuse(Breath:115) [enemy(#2).hp>560]\nuse(Explode:282) [enemy(#2).hp<560]\nchange(#2)",
				},
				[141046] = {
					["name"] = "Captured Evil",
					["code"] = "ability(Rain Dance:1062)\nability(Squeeze:1572)\nability(Ironskin:1758) \nability(Ancient Blessing:611)\nability(#1)\nchange(next)",
				},
				[66918] = {
					["name"] = "Seeker Zusshi",
					["code"] = "change(#2) [enemy(#3).active & !self(#2).played]\nchange(#1) [self(#2).active]\nchange(#3) [self(#1).active & self.dead]\nif [!enemy(#3).active]\n  use(Shell Shield:310) [enemy.round=1]\n  use(Renewing Mists:511) [enemy.round=2]\nendif\nuse(Snap:356)\nability(Surge of Power:593) [enemy.aura(Howl:1725).exists] \nability(Surge of Power:593) [enemy.hp<=740] \nability(Howl:362) [!enemy.hp.full]\nstandby",
				},
				[68464] = {
					["name"] = "Whispering Pandaren Spirit",
					["code"] = "change(#2) [self(#1).active & self.dead]\nchange(#3) [self(#2).active]\nuse(Ancient Blessing:611)\nuse(Arcane Explosion:299)\nuse(Arcane Storm:589) \nuse(Mana Surge:489) \nstandby",
				},
				[162458] = {
					["name"] = "Retinus the Seeker",
					["code"] = "standby [round=1]\nuse(Blistering Cold:786)\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Flock:581)\nchange(Ikky:1532) [self.aura(Stunned:927).exists]\nchange(Boneshard:1963)",
				},
				[68462] = {
					["name"] = "Flowing Pandaren Spirit",
					["code"] = "change(#2) [enemy(#3).active & !self(#2).played]\nchange(#1) [self(#2).active]\nuse(Ravage:802) [enemy(#2).active & enemy.hp<618]\nuse(Alpha Strike:504) [enemy(#3).hp<385 & self.speed.fast]\nuse(Dodge:312) [self.aura(Whirlpool:512).duration=1]\nuse(Alpha Strike:504)",
				},
				[66733] = {
					["name"] = "Mo'ruk",
					["code"] = "change(#2) [enemy(#2).active]\nability(Explode:282) [enemy(#3).active & enemy.hp.can_explode]\nability(Decoy:334) [enemy.ability(Headbutt:376).duration=2]\nability(Decoy:334) [round=2]\nability(Howl:362)\nability(Surge of Power:593)\nability(#1)\nstandby\nchange(#1)",
				},
				[155414] = {
					["name"] = "Ezra Grimm",
					["code"] = "change(#2) [self.aura(Howl:1725).exists & self(#1).active]\nchange(#1) [self(#2).active & enemy(#3).active & enemy.hpp=100 & enemy.aura(Blinding Poison:1048).exists]\nchange(#2) [self(#3).active & enemy(#3).active]\nchange(#3) [self(#2).active & enemy(#2).active]\nchange(#2) [round=3]\nuse(Blistering Cold:786)\nuse(Chop:943)\nuse(Blinding Poison:1049)\nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nuse(Barbed Stinger:1369)\n--\nuse(Dodge:312) [self.aura(Elementium Bolt:605).exists]\nuse(Tornado Punch:1052) [enemy.hp<335]\nuse(Jab:219)\nchange(#3)",
				},
				[94637] = {
					["name"] = "Corrupted Thundertail",
					["code"] = "quit [self(#1).active & self.speed.slow & enemy(#1).active & enemy(#2).dead & !enemy(#3).dead]\n\nquit [self(#1).active & self.speed.slow & enemy(#1).active & !enemy(#2).dead & enemy(#3).dead]\n\nquit [self(#1).active & enemy(#1).active & !self(#1).ability(#3).usable]\n\nuse(#3) [self(#1).active & enemy(#1).active]\nuse(#1) [round=2]\n\n-- Turn 3 heal ?\nif [round=3]\nuse(#2) [enemy.aura(Flying:341).exists]\nuse(#2) [enemy.aura(Underground:340).exists]\nuse(#2) [enemy.aura(Underwater:830).exists]\nuse(#2) [enemy.aura(Dodge:311).exists]\nuse(#2) [enemy.aura(Silk Cocoon:505).exists]\nuse(#2) [self.ability(#1).strong]\nuse(#2) [self.hpp<50]\nuse(#1) [enemy.hp>390]\nuse(#2)\nstandby\nendif\n-- end heal turn\n\n\nif [self(#1).active & !enemy(#2).dead & !enemy(#3).dead]\nuse(#1) [self.ability(#3).duration<=1 & self.hpp>50]\nuse(#2)\nif [self.ability(#1).strong]\nuse(#1) [enemy.hp>585]\nstandby\nendif\nuse(#1) [enemy.hp>390]\nstandby\nendif\n\nif [self(#1).active & enemy(#2).dead & !enemy(#3).dead]\nchange(#2) [enemy.hpp<50]\nstandby [enemy.hpp<50]\nuse(#1)\nendif\n\nif [self(#1).active & !enemy(#2).dead & enemy(#3).dead]\nchange(#2) [enemy.hpp<50]\nstandby [enemy.hpp<50]\nuse(#1)\nendif\n\nchange(#3) [self(#2).dead]\nuse(#3) [self(#2).active & enemy(#1).active]\nuse(#2)\nuse(#1)\nstandby\nchange(next)",
				},
				[68560] = {
					["name"] = "Greyhoof",
					["code"] = "ability(Wind-Up:459) [round=1]\nability(Supercharge:208) [round=2]\nability(Wind-Up:459) [round=3]\nability(Powerball:566)\nchange(#2) [self(#1).dead]\nability(Explode:282) [enemy.hp<614]\nability(Decoy:334)\nability(Missile:777)",
				},
				[66824] = {
					["name"] = "Obalis",
					["code"] = "use(Decoy:334) [enemy.hp<618]\nuse(Explode:282) [enemy.hp<618]\nuse(Missile:777)\nchange(#2) [!self(#2).played]\nchange(#3)\nuse(Prowl:536)\nstandby [enemy.aura(Silk Cocoon:505).exists]\nstandby [self.aura(Asleep:498).exists]\nuse(Moonfire:595)\nuse(Spirit Claws:974)",
				},
				[139987] = {
					["name"] = "This Little Piggy Has Sharp Tusks",
					["code"] = "change(next) [ self(#1).dead & !self(#3).played ] \nability(#2) [ !enemy.aura(217).exists ] \nability(#3) \nability(#1)",
				},
				[173303] = {
					["name"] = "Ashes Will Fall",
					["code"] = "use(421) [round~1]\nuse(1043)\nuse(421)",
				},
				[94649] = {
					["name"] = "Skrillix",
					["code"] = "standby [round~2,3]\nstandby [enemy.aura(Dodge:311).exists]\nstandby [self.aura(Asleep:498).exists]\n-- \nability(Curse of Doom:218)\nability(Unholy Ascension:321)\n-- \nability(Consume Corpse:665) [enemy(#2).active & enemy.round~1,2,3]\nability(Howl:362) [!self(#2).aura(Undead:242).exists]\n-- \nability(Emerald Dream:598) [self(#3).hpp<60]\nability(Emerald Presence:597) [!self.aura(Emerald Presence:823).exists]\nability(#1)\n-- \nchange(next)",
				},
				[94650] = {
					["name"] = "Defiled Earth",
					["code"] = "use(218)\nuse(652)\nuse(919) [!enemy.aura(918).exists]\nuse(581)\nuse(598) [self.hp<900]\nuse(597) [self.aura(823).duration<=1]\nuse(525)\nchange(#2)\nchange(#3)",
				},
				[140880] = {
					["name"] = "What's the Buzz?",
					["code"] = "ability(Emerald Presence:597) [ !self.aura(Emerald Presence:823).exists ]\nability(Emerald Presence:597) [ self.aura(Emerald Presence:823).duration = 1 ]\nability(Emerald Dream:598) [ self.hp <750 ]\nstandby",
				},
				[154922] = {
					["name"] = "Gnomefeaster",
					["code"] = "ability(Black Claw:919) [!enemy.aura(Black Claw:918).exists]\nability(Flock:581)\nchange(Mechanical Pandaren Dragonling:844)\nability(Breath:115) [self.round=1]\nability(Thunderbolt:779)\nability(Explode:282) (edited)",
				},
				["Growing Ectoplasm 1"] = {
					["name"] = "Growing Ectoplasm 1",
					["code"] = "ability(Creeping Fungus:743) [round=1]\nability(Stampede:163) [round=2]\nability(Corpse Explosion:663)\nability(Peck:112) [enemy(Growing Ectoplasm:1995).active]\n\nif [enemy(Deviate Smallclaw:1989).active]\nability(Haywire:916)\nability(#1)\nendif\n\nif [enemy(Deviate Chomper:1988).active]\nability(Lift-Off:170)\nability(#1)\nendif\n\nif [enemy(Deviate Flapper:1987).active]\nability(#1) [enemy.round=1]\nability(Lift-Off:170)\nability(Haywire:916)\nability(#1)\nendif\n\nchange(next)",
				},
				[87123] = {
					["name"] = "Vesharr",
					["code"] = "ability(Arcane Explosion:299)\nability(Explode:282) [enemy.aura(Mechanical:244).exists]\nability(Thunderbolt:779) [!enemy.aura(Flying Mark:1420).exists]\nability(Breath:115)\nchange(#2)",
				},
				[68465] = {
					["name"] = "Thundering Pandaren Spirit",
					["code"] = "change(#2) [self(#1).active & self.dead]\nuse(Dive:564) [round=1]\nuse(Acidic Goo:369) [!enemy.aura(Acidic Goo:368).exists]\nuse(Ooze Touch:445)\nuse(Explode:282) [enemy(#3).hp<850 & enemy.ability(Stone Rush:621).usable]\nuse(Explode:282) [enemy(#3).hp<618]\nuse(Decoy:334) [enemy.round=2]\nuse(Missile:777)",
				},
				[83837] = {
					["name"] = "Cymre Brightblade",
					["code"] = "change(#3) [self(#2).dead & !self(#3).played]\nchange(#1) [self(#3).played]\nchange(#2) [enemy(#3).active & enemy.aura(Ice Tomb:623).exists]\nchange(#1) [enemy(#3).active]\nchange(#2) [enemy(#2).active]\nuse(Ice Lance:413) [weather(Blizzard:205) & enemy(#3).active]\nuse(Ice Tomb:624) [enemy(#3).active & !self(#3).played]\nuse(Call Blizzard:206)\nuse(Ice Tomb:624)\nuse(Ice Lance:413)\nuse(Murder the Innocent:2223)\nuse(Scorched Earth:172)",
				},
				[87110] = {
					["name"] = "Tarr the Terrible",
					["code"] = "change(#3) [round=4]\nchange(#2) [self(#3).active]\nuse(Haunt:652) [round=1]\nuse(Shadow Slash:210)\nuse(BONESTORM:649) [self.round=1]\nuse(Ancient Blessing:611) [!self.aura(Undead:242).exists]\nuse(Bone Bite:648)\nchange(#2)\nchange(#1)",
				},
				[66822] = {
					["name"] = "Goz Banefury",
					["code"] = "change(#3) [enemy.aura(Dark Rebirth:796).exists]\nchange(#2) [self(#3).dead]\nuse(Bubble:934)\nuse(Mudslide:572) [enemy(Helios:986).active & self.round=2]\nuse(Water Jet:118)\nuse(Bombing Run:647) [enemy(Helios:986).active & enemy.round=2]\nuse(Decoy:334)\nuse(Breath:115)\nstandby [self(Elekk Plushie:1426).active]\nchange(next)",
				},
				[85420] = {
					["name"] = "Carrotus Maximus",
					["code"] = "use(Explode:282) [enemy(Carrotus Maximus:1473).hp<427]\nuse(Wind-Up:459) [round~1,5]\nuse(Powerball:566)",
				},
				[150858] = {
					["name"] = "Blackmane",
					["code"] = "standby [enemy.aura(Undead:242).exists]\nstandby [round=5]\nability(Ironskin:1758)\nstandby [enemy.aura(Dodge:2060).exists]\nability(Predatory Strike:518) [enemy.aura(Shattered Defenses:542).exists & enemy.hpp>5 & self(#1).active]\nability(Predatory Strike:518) [enemy.aura(Shattered Defenses:542).exists & self(#2).active]\nability(Falcosaur Swarm!:1773)\nability(#1)\nchange(next)",
				},
				[68561] = {
					["name"] = "Lucky Yi",
					["code"] = "change(#3) [self(#1).dead & !self(#3).played] \nchange(#2) [self(#3).played] \nuse(Haunt:652) \nuse(Black Claw:919) [!enemy.aura(Black Claw:918).exists] \nuse(Flock:581)",
				},
				["Wastewalker Shu"] = {
					["name"] = "Wastewalker Shu",
					["code"] = "standby [self(#1).active & enemy(#3).hp<618]\nchange(#2) [self(#1).active & self.dead]\nuse(Arcane Blast:421) [enemy.hp<370]\nuse(Evanescence:440) [self.aura(Whirlpool:512).exists]\nuse(Evanescence:440) [enemy(#3).active & enemy.round=2]\nuse(Moonfire:595) [enemy.round=2]\nuse(Arcane Blast:421)\nuse(Explode:282) [enemy(#3).hp<618]\nuse(Flyby:515)",
				},
			},
		},
	},
	["profileKeys"] = {
		["Samedie - Moon Guard"] = "Default",
		["Kaderín - Moon Guard"] = "Default",
		["Estrovel - Wyrmrest Accord"] = "Default",
		["Akikha - Moon Guard"] = "Default",
		["Jaeyun - Twisting Nether"] = "Default",
		["Uddanni - Moon Guard"] = "Default",
		["Dristen - Wyrmrest Accord"] = "Default",
		["Makarí - Moon Guard"] = "Default",
		["Ambroscia - Moon Guard"] = "Default",
		["Kaderiina - Wyrmrest Accord"] = "Default",
		["Bwondazi - Wyrmrest Accord"] = "Default",
		["Alexandrós - Moon Guard"] = "Default",
		["Ellechaldreu - Wyrmrest Accord"] = "Default",
		["Ailily - Moon Guard"] = "Default",
		["Aminara - Wyrmrest Accord"] = "Default",
		["Vanir - Rexxar"] = "Default",
		["Skildi - Moon Guard"] = "Default",
		["Chadakhan - Wyrmrest Accord"] = "Default",
		["Vynmarrin - Wyrmrest Accord"] = "Default",
		["Valluu - Moon Guard"] = "Default",
		["Ilyreas - Moon Guard"] = "Default",
		["Alectrina - Moon Guard"] = "Default",
		["Ivkarad - Moon Guard"] = "Default",
		["Lorrand - Wyrmrest Accord"] = "Default",
		["Alplansande - Twisting Nether"] = "Default",
		["Lucindaea - Wyrmrest Accord"] = "Default",
		["Kethorrum - Moon Guard"] = "Default",
		["Nerediil - Moon Guard"] = "Default",
		["Wudroe - Moon Guard"] = "Default",
		["Agiaga - Moon Guard"] = "Default",
		["Rhakísh - Wyrmrest Accord"] = "Default",
		["Vanír - Moon Guard"] = "Default",
		["Jastne - Moon Guard"] = "Default",
		["Vynmarrin - Moon Guard"] = "Default",
		["Asiphi - Moon Guard"] = "Default",
		["Avekstrasza - Wyrmrest Accord"] = "Default",
		["Tsuneyo - Twisting Nether"] = "Default",
		["Theilix - Moon Guard"] = "Default",
		["Artemeía - Moon Guard"] = "Default",
		["Rhavaniel - Maelstrom"] = "Default",
		["Victoriin - Moon Guard"] = "Default",
		["Rhakkish - Moon Guard"] = "Default",
		["Cherriandris - Wyrmrest Accord"] = "Default",
		["Makari - Rexxar"] = "Default",
		["Kristaar - Moon Guard"] = "Default",
		["Estaavros - Moon Guard"] = "Default",
		["Esza - Wyrmrest Accord"] = "Default",
		["Bekshi - Moon Guard"] = "Default",
		["Oomaku - Wyrmrest Accord"] = "Default",
		["Nimhi - Moon Guard"] = "Default",
		["Valuruna - Twisting Nether"] = "Default",
		["Rhelania - Moon Guard"] = "Default",
		["Thalaea - Moon Guard"] = "Default",
		["Helja - Rexxar"] = "Default",
		["Khessaktahl - Moon Guard"] = "Default",
		["Bekshi - Wyrmrest Accord"] = "Default",
		["Woodrough - Twisting Nether"] = "Default",
		["Irathmor - Moon Guard"] = "Default",
		["Nolanka - Wyrmrest Accord"] = "Default",
		["Izidormi - Wyrmrest Accord"] = "Default",
		["Shaeror - Moon Guard"] = "Default",
		["Kaelystina - Wyrmrest Accord"] = "Default",
		["Lothaan - Wyrmrest Accord"] = "Default",
		["Novriel - Twisting Nether"] = "Default",
		["Vosanz - Wyrmrest Accord"] = "Default",
		["Marloh - Moon Guard"] = "Default",
		["Rhavaniel - Twisting Nether"] = "Default",
		["Xarvak - Moon Guard"] = "Default",
		["Lorivet - Moon Guard"] = "Default",
		["Venthaeus - Moon Guard"] = "Default",
		["Aelyia - Twisting Nether"] = "Default",
		["Sulveríon - Wyrmrest Accord"] = "Default",
		["Nothraxia - Moon Guard"] = "Default",
		["Wødan - Moon Guard"] = "Default",
		["Barreigh - Moon Guard"] = "Default",
		["Habvi - Wyrmrest Accord"] = "Default",
		["Yunglifeng - Twisting Nether"] = "Default",
		["Kehe - Wyrmrest Accord"] = "Default",
		["Chadakhan - Moon Guard"] = "Default",
		["Ellechaldreu - Moon Guard"] = "Default",
		["Midrail - Twisting Nether"] = "Default",
		["Phoenici - Wyrmrest Accord"] = "Default",
		["Mythaea - Rexxar"] = "Default",
		["Reavyr - Moon Guard"] = "Default",
		["Viilhelm - Moon Guard"] = "Default",
		["Thessilya - Moon Guard"] = "Default",
		["Ignisi - Wyrmrest Accord"] = "Default",
		["Siegrund - Moon Guard"] = "Default",
		["Rhythyra - Moon Guard"] = "Default",
		["Thahara - Wyrmrest Accord"] = "Default",
		["Drezdt - Moon Guard"] = "Default",
		["Klondíke - Twisting Nether"] = "Default",
		["Moneygrubber - Wyrmrest Accord"] = "Default",
		["Ravaniil - Moon Guard"] = "Default",
		["Kehe - Moon Guard"] = "Default",
		["Kadariin - Moon Guard"] = "Default",
		["Rellanea - Moon Guard"] = "Default",
		["Meiwuying - Twisting Nether"] = "Default",
		["Savenria - Wyrmrest Accord"] = "Default",
		["Makarigosa - Moon Guard"] = "Default",
		["Sinvaria - Twisting Nether"] = "Default",
		["Perova - Moon Guard"] = "Default",
		["Banksies - Rexxar"] = "Default",
		["Tesaka - Wyrmrest Accord"] = "Default",
		["Ithedrokos - Moon Guard"] = "Default",
		["Grehnm - Moon Guard"] = "Default",
		["Dristun - Moon Guard"] = "Default",
		["Ravaniel - Moon Guard"] = "Default",
		["Jhustn - Moon Guard"] = "Default",
		["Rauldfjr - Moon Guard"] = "Default",
		["Artemeia - Rexxar"] = "Default",
		["Ignisi - Moon Guard"] = "Default",
		["Elesara - Moon Guard"] = "Default",
		["Adepidia - Kirin Tor"] = "Default",
		["Crizzi - Wyrmrest Accord"] = "Default",
		["Jouliana - Moon Guard"] = "Default",
		["Avarias - Moon Guard"] = "Default",
		["Rhakkish - Wyrmrest Accord"] = "Default",
		["Phoenícia - Wyrmrest Accord"] = "Default",
		["Nohmojoru - Wyrmrest Accord"] = "Default",
		["Hellja - Moon Guard"] = "Default",
		["Rhavaniel - Rexxar"] = "Default",
		["Arastrasza - Wyrmrest Accord"] = "Default",
		["Ruperth - Moon Guard"] = "Default",
		["Lilianaea - Moon Guard"] = "Default",
		["Fethnir - Moon Guard"] = "Default",
		["Caizhen - Wyrmrest Accord"] = "Default",
		["Sigrúnd - Moon Guard"] = "Default",
		["Valytiereaux - Moon Guard"] = "Default",
		["Oenoko - Moon Guard"] = "Default",
		["Sumisah - Wyrmrest Accord"] = "Default",
		["Madormi - Wyrmrest Accord"] = "Default",
		["Staavros - Wyrmrest Accord"] = "Default",
		["Vosslorn - Moon Guard"] = "Default",
		["Halinor - Twisting Nether"] = "Default",
		["Jesthir - Wyrmrest Accord"] = "Default",
		["Kanary - Wyrmrest Accord"] = "Default",
		["Honemoros - Moon Guard"] = "Default",
		["Cherriandris - Moon Guard"] = "Default",
		["Fafmir - Moon Guard"] = "Default",
		["Vyrallion - Wyrmrest Accord"] = "Default",
		["Sulfurion - Wyrmrest Accord"] = "Default",
		["Aleksandr - Twisting Nether"] = "Default",
		["Rhelania - Twisting Nether"] = "Default",
		["Lyraale - Moon Guard"] = "Default",
		["Vizea - Wyrmrest Accord"] = "Default",
		["Oenoko - Wyrmrest Accord"] = "Default",
		["Keshindri - Wyrmrest Accord"] = "Default",
		["Renzzak - Twisting Nether"] = "Default",
		["Lysandaer - Moon Guard"] = "Default",
		["Klondíke - Moon Guard"] = "Default",
		["Empereal - Moon Guard"] = "Default",
		["Jenavier - Wyrmrest Accord"] = "Default",
		["Bwonsamedí - Wyrmrest Accord"] = "Default",
		["Saliine - Moon Guard"] = "Default",
		["Relentless - Maelstrom"] = "Default",
		["Sedyna - Moon Guard"] = "Default",
		["Mythaea - Moon Guard"] = "Default",
		["Estrovel - Moon Guard"] = "Default",
		["Enthalria - Wyrmrest Accord"] = "Default",
		["Rallanis - Moon Guard"] = "Default",
		["Kildagosa - Wyrmrest Accord"] = "Default",
		["Wonyi - Moon Guard"] = "Default",
		["Novríel - Moon Guard"] = "Default",
		["Empearal - Wyrmrest Accord"] = "Default",
		["Aevaleyna - Moon Guard"] = "Default",
		["Honnei - Moon Guard"] = "Default",
		["Ithedrokos - Twisting Nether"] = "Default",
		["Cathellah - Moon Guard"] = "Default",
		["Ahanta - Wyrmrest Accord"] = "Default",
		["Yinaryue - Wyrmrest Accord"] = "Default",
		["Sigrune - Twisting Nether"] = "Default",
		["Artemeia - Twisting Nether"] = "Default",
		["Sulverion - Wyrmrest Accord"] = "Default",
		["Lothaan - Moon Guard"] = "Default",
		["Animamule - Moon Guard"] = "Default",
		["Thrakios - Wyrmrest Accord"] = "Default",
		["Krovek - Wyrmrest Accord"] = "Default",
		["Jastne - Wyrmrest Accord"] = "Default",
		["Alvanare - Wyrmrest Accord"] = "Default",
		["Renzzak - Wyrmrest Accord"] = "Default",
		["Rhelanía - Moon Guard"] = "Default",
		["Harmonne - Twisting Nether"] = "Default",
		["Llandrict - Moon Guard"] = "Default",
		["Kaethan - Wyrmrest Accord"] = "Default",
		["Shiruh - Wyrmrest Accord"] = "Default",
		["Jakib - Moon Guard"] = "Default",
		["Dyonaellii - Shadowmoon"] = "Default",
		["Kaelysti - Moon Guard"] = "Default",
		["Sulverion - Twisting Nether"] = "Default",
		["Sígrune - Moon Guard"] = "Default",
		["Iravius - Moon Guard"] = "Default",
		["Salinaa - Twisting Nether"] = "Default",
		["Midrail - Moon Guard"] = "Default",
		["Elynisa - Moon Guard"] = "Default",
		["Habvi - Moon Guard"] = "Default",
		["Silaana - Moon Guard"] = "Default",
		["Shalestra - Wyrmrest Accord"] = "Default",
		["Kanareyka - Moon Guard"] = "Default",
		["Lassette - Moon Guard"] = "Default",
		["Drezdt - Wyrmrest Accord"] = "Default",
		["Lunanstier - Wyrmrest Accord"] = "Default",
		["Katelyn - Twisting Nether"] = "Default",
		["Mythaea - Twisting Nether"] = "Default",
		["Lyraale - Twisting Nether"] = "Default",
		["Marassande - Moon Guard"] = "Default",
		["Shatasia - Moon Guard"] = "Default",
		["Ahanta - Moon Guard"] = "Default",
		["Icialu - Moon Guard"] = "Default",
		["Klavdja - Twisting Nether"] = "Default",
		["Camillei - Moon Guard"] = "Default",
		["Sadoth - Moon Guard"] = "Default",
		["Daniquerinea - Moon Guard"] = "Default",
		["Telos - Blackwater Raiders"] = "Default",
		["Rhelanja - Moon Guard"] = "Default",
		["Kaderin - Twisting Nether"] = "Default",
		["Krovekk - Moon Guard"] = "Default",
		["Yunglifeng - Moon Guard"] = "Default",
		["Faydori - Moon Guard"] = "Default",
		["Paarthos - Moon Guard"] = "Default",
		["Reuvan - Moon Guard"] = "Default",
		["Lorathiel - Moon Guard"] = "Default",
		["Wodan - Twisting Nether"] = "Default",
		["Perristal - Moon Guard"] = "Default",
		["Rhavaníel - Moon Guard"] = "Default",
		["Sidgarda - Moon Guard"] = "Default",
		["Rhavaniel - Moon Guard"] = "Default",
		["Bwonzambí - Wyrmrest Accord"] = "Default",
		["Syndragosa - Wyrmrest Accord"] = "Default",
		["Thelix - Wyrmrest Accord"] = "Default",
		["Hallenor - Moon Guard"] = "Default",
		["Maldyn - Moon Guard"] = "Default",
		["Nothroxia - Twisting Nether"] = "Default",
		["Miphus - Wyrmrest Accord"] = "Default",
		["Feost - Moon Guard"] = "Default",
		["Makarigosa - Twisting Nether"] = "Default",
		["Adoristus - Wyrmrest Accord"] = "Default",
		["Ylena - Wyrmrest Accord"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["settings"] = {
				["hideMinimap"] = true,
				["autoButtonHotKey"] = "SPACE",
			},
			["position"] = {
				["y"] = -185.4091186523438,
				["x"] = 366.7293701171875,
				["point"] = "TOP",
				["scale"] = 1,
			},
			["pluginOrders"] = {
				"Rematch", -- [1]
				"Base", -- [2]
				"FirstEnemy", -- [3]
				"AllInOne", -- [4]
			},
			["minimap"] = {
				["hide"] = true,
			},
		},
	},
}
